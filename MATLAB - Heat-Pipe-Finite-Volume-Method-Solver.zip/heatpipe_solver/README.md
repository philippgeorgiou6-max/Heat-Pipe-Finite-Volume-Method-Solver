# Heat pipe CFD: single evaporator, Faghri & Buchko (1991) model

MATLAB solver with a graphical user interface for a copper–water heat pipe with one evaporator. The physical model is from A. Faghri and M. Buchko, "Experimental and Numerical Analysis of Low-Temperature Heat Pipes With Multiple Heat Sources", *ASME J. Heat Transfer* 113 (1991) 728–733.

The validated default is the paper's pipe (1 m long, o.d. 25.4 mm, i.d. 22.0 mm, two wraps of 50-mesh copper screen, wick thickness 0.712 mm as listed in Table 1). It has one 63.5 mm evaporator at 97 W, an adiabatic transport section, and a 300 mm condenser that removes the input power (paper Eq. 20). This is the paper's Case 1 (Fig. 4).

## Start

```matlab
RUN_ME            % opens the GUI
```

The GUI leads through six steps. "Next step" checks each step before it goes on.

| Step | Content |
|---|---|
| 1 Geometry | Lengths of the unheated sections, evaporator and condenser, plus the three diameters. "Define geometry" applies them and draws the pipe with its regions and dimensions. The transport section takes the remaining length. |
| 2 Boundary conditions | Evaporator: input power, uniform temperature, T(z), convection or q(z). Condenser: remove the input power (paper Eq. 20), power removed, uniform temperature, T(z), convection or q(z). Transport section: adiabatic or convection. Only the fields of the selected type are shown, and the preview plots what the solver will impose. |
| 3 Mesh | Radial cells and spacing for each region, axial cell size, and presets. "Start meshing" builds the mesh and draws it, both in full and as a detail. |
| 4 Materials | Vapor core (water vapor), wick (liquid water plus porous structure; k_eff from Eq. 9 or user-defined) and wall (material presets or custom). By default the water properties follow the operating temperature T_o. Unchecking that box lets you enter fixed values or load water at a chosen temperature. |
| 5 Numerics | Pressure–velocity coupling (SIMPLEC or SIMPLE), convection scheme (hybrid, power law or upwind), wick radial momentum form, start-up, inner flow iterations, the under-relaxation factors, and the convergence criteria: maximum outer iterations and the tolerances for mass, momentum, temperature change, interface mass-flux change, interface closure, energy residual and heat balance. "Reset to defaults" restores the validated settings. |
| 6 Solver & results | Initial temperature and live-plot interval. The buttons are Start simulation, Stop and Save results. The live plots appear inside the GUI. |

**Drawings:** the geometry and mesh views stretch the radial direction, with the vapor core, wick and wall at 50/25/25 % of the height. The tick labels show the true radii.

**Function inputs:** T(z) and q(z) are MATLAB expressions in `z` (axial position [m]), `s` (distance from the zone start [m]) and `L` (zone length [m]). Examples: `85 + 3*sin(pi*s/L)` or `2e4*exp(-((s - L/2)/(0.2*L))^2)`. Temperatures are in °C and heat fluxes in W/m². The unheated end sections are adiabatic.

### Temperature level

The level of the solution is set in one of two ways:
- **Only heat fluxes prescribed** (evaporator power or q(z), condenser flux, adiabatic transport): the operating temperature T_o from step 2 sets the level. The condenser has to remove the input. A prescribed condenser flux that differs from the input is scaled, and a warning is shown.
- **Any temperature or convection BC present:** T_o is solved for, so that everything that evaporates also condenses (zero net mass flow through the interface). The initial temperature from step 6 is its start value. The water properties follow T_o during the run, so the converged solution uses the properties at the converged T_o. With fixed fluid properties (box unchecked in step 4) the entered values are used as they are.

### Boundary conditions beyond the paper

The paper prescribes heat fluxes only (Eq. 20): the input power at the evaporator, removal of the input as a uniform flux at the condenser, and adiabatic walls elsewhere. That is the validated configuration. The other types (uniform or T(z) wall temperature, convection, q(z), a convective transport section, and the solved T_o that comes with them) are extensions. They are checked for convergence and energy balance, but they are not validated against measurements.

A convective transport section cannot be combined with "remove the input power" at the condenser. In that combination the transport section would carry no net heat and the pipe would settle at T_inf, so the GUI rejects it.

## Results (`./heatpipe_results`)

"Save results" first deletes the folder's previous content, so the folder always holds exactly one simulation.

| File | Content |
|---|---|
| `*.pdf` | Geometry, mesh, boundary conditions, temperature field, velocity field, axial temperatures, interface mass flux, pressures, convergence, power in/out, total thermal resistance, and the overview `diagnostics.pdf` |
| `*.txt` | The data of every plot (tab-separated, with `#` header lines), plus `summary.txt`, `geometry.txt`, `mesh.txt`, `boundary_conditions.txt` and `materials.txt` |
| `heatpipe_results.mat` | The complete results structure |

## Scripts (without the GUI)

```matlab
results = runHeatPipeSolver();                                            % paper case
results = runHeatPipeSolver(struct('evaporatorPowers_W',150,'T_o_C',75));
results = runHeatPipeSolver(struct('condenserBCType','convection','condenserH_W_m2K',2000));
results = runHeatPipeSolver([], 'paper100');                              % grid preset
results = runHeatPipeSolver([], 'default', struct('alpha_u',0.5,'tolMass',1e-5,'maxOuterIterations',2000));  % numerics
```

All case inputs are listed in `src/input/inputCleanHeatPipeCase.m`, the numerical settings and convergence criteria in `src/input/inputCleanHeatPipeNumerics.m`. A script run writes the same result folder and, when a display is available, shows live plots and every diagram in its own window.

## Structure

| Folder | Content |
|---|---|
| `HeatPipeGUI.m` | GUI |
| `src/input` | Case, materials and numerical settings |
| `src/mesh` | Block-structured axisymmetric mesh, regions and zones |
| `src/physics`, `src/flow`, `src/numerics` | Solver and physical model |
| `src/output` | Derived quantities, thermal resistance, export of the results |
| `src/plotting` | Diagrams, geometry/mesh/BC drawings and the live monitor |

## Model

- **Vapor core:** compressible, laminar Navier–Stokes (Eqs. 1–4).
- **Wick:** Brinkman–Darcy momentum with inertia (Eqs. 5–9).
- **Wall:** conduction (Eq. 10).
- **Interface:** T = T_sat(p_v) (Eq. 19); the mass flux follows from the heat-flux jump (Eq. 16); no slip (Eq. 13).
- **Geometry:** wick thickness 0.712 mm from Table 1 (vapor core diameter 20.576 mm). Table 1 also lists a 20.5 mm vapor core, which would mean a 0.75 mm wick; `wickThicknessSource = 'diameters'` selects that variant. With 0.712 mm the computed wall temperatures match the paper's numerical curve in Fig. 4 more closely.
- **Properties:** water properties per region at the operating temperature T_o (IAPWS-based correlations); with a solved T_o they follow it during the iteration.
- **Numerics:** staggered-grid finite volume, SIMPLEC coupling, hybrid differencing (defaults; SIMPLE, power law and upwind can be chosen in step 5).
- **Convergence:** all criteria must hold in the same outer iteration, and the residuals re-evaluated on the final fields must pass as well. Default tolerance 1e-6 for every criterion (step 5, or `src/input/inputCleanHeatPipeNumerics.m` for scripts).

Written for MATLAB R2016b or later. The solver and the GUI were also tested in GNU Octave 8.4.

## License

MIT License, see `LICENSE`. The physical model is that of A. Faghri and M. Buchko, *ASME J. Heat Transfer* 113 (1991) 728–733; please cite the paper when you use the model.
