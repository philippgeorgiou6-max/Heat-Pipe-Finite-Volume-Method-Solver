%RUN_ME Open the GUI of the heat-pipe CFD solver.
%
% Single-evaporator heat pipe with the physical model of Faghri & Buchko
% (1991): compressible laminar vapor flow (Eqs. 1-4), Brinkman-Darcy liquid
% flow in the wick (Eqs. 5-9), wall conduction (Eq. 10), interface conditions
% (Eqs. 13-19), staggered-grid SIMPLEC solver.
%
% The GUI leads through geometry, boundary conditions, mesh, materials,
% numerics (coupling, under-relaxation, convergence criteria) and solver;
% results are saved to ./heatpipe_results (replaced on every save).
%
% Without the GUI (scripts, parameter studies):
%   results = runHeatPipeSolver();                                         % paper case
%   results = runHeatPipeSolver(struct('evaporatorPowers_W',150,'T_o_C',75));
%   results = runHeatPipeSolver(struct('condenserBCType','convection','condenserH_W_m2K',2000));
% See src/input/inputCleanHeatPipeCase.m for all inputs.

rootDir = fileparts(mfilename('fullpath'));
addpath(genpath(fullfile(rootDir,'src')));
addpath(rootDir);
HeatPipeGUI();
