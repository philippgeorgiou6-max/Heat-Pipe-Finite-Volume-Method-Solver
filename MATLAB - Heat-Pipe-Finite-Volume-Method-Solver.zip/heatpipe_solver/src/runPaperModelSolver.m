function results = runPaperModelSolver(caseData,mat,num,mesh)
%RUNPAPERMODELSOLVER Full conjugate heat-pipe model of Faghri & Buchko (1991).
%
% Unknowns: T in vapor, wick and wall (one matrix); w, v, p in the vapor core
% (compressible laminar Navier-Stokes, Eqs. 1-3, ideal gas); w, v, p_l in the
% wick (Brinkman-Darcy with inertia, Eqs. 5-6, intrinsic velocity).
% Coupling at r = a: T = T_sat(p_v(z,a)) (Eq. 19) with p_v extrapolated to
% r = a, m'' from the heat-flux jump (Eq. 16), vapor and liquid radial
% velocities from m'' (mass continuity; vapor density at r = a), no slip for
% w (Eq. 13).
%
% Outer iteration:
%   (1) interface velocities from m''          (applyVelocityBCs)
%   (2) num.innerFlowIterations SIMPLE(C) cycles in the vapor and in the wick
%   (3) pressure anchoring; vapor density from p = rho R T
%   (4) energy with convection, pressure work and dissipation; T_i(z) from Eq. 19
%   (5) m'' from Eq. 16, global closure, under-relaxation
% Converged when every convergence criterion holds in the same outer iteration
% (tolerances in num, see inputCleanHeatPipeNumerics) and the residuals
% re-evaluated on the final fields pass as well (evaluateFinalResiduals).
%
% Fluid properties: with mat.fluidPropertiesFollowT_o (default) the water
% properties belong to the operating temperature T_o. When T_o is solved for
% (temperature or convection BCs) they are re-evaluated whenever T_o changes,
% at the start of each outer iteration (updateFluidProperties), so the
% converged solution uses the properties at the converged T_o.

tStart = tic;
Nz = mesh.Nz;
bc = buildOuterThermalBC(mesh,caseData,mat);
A_int = mesh.A_interface;
followT = isfield(mat,'fluidPropertiesFollowT_o') && mat.fluidPropertiesFollowT_o;
if followT && caseData.T_o_K ~= mat.T_eval_K
    mat = updateFluidProperties(mat, caseData.T_o_K);   % water at the (start value of) T_o
end

% ---------------------------------------------------------------- start-up
fields = initializeCleanFields(mesh,caseData,mat);
T_o = caseData.T_o_K;
[fields,iface,m,T_o] = solveEnergyWithInterface(mesh,fields,caseData,mat,num,bc,T_o,zeros(1,Nz));
usePaperStartup = strcmpi(num.startup,'paperOuterFlux');
if usePaperStartup
    mdot = outerFluxMassFlux(bc,m.hfg,A_int);
else
    mdot = m.mdot;
end

vapor = buildFlowSubdomain(mesh,caseData,mat,'vapor');
wick  = buildFlowSubdomain(mesh,caseData,mat,'wick');
switch lower(num.wickRadialMomentumForm)
    case 'vector',  wick.includeVr2 = true;    % mu*(lap(v) - v/r^2), as in Eq. (25)
    case 'printed', wick.includeVr2 = false;   % Eq. (6) exactly as printed
    otherwise, error('num.wickRadialMomentumForm must be ''vector'' or ''printed''.');
end
vapor.rho = iface.p_o./(mat.vapor.R*fields.T(mesh.rowsVapor,:));
[~,jWet] = min(abs(mesh.z_centers - caseData.liquidPressureReference_z));
[~,jRef] = min(abs(mesh.z_centers - caseData.pressureReferencePoint_z));

H = initHistory();
converged = false;
stoppedByUser = false;
tolMdot = 1e-6;
if isfield(num,'tolMdotChange') && ~isempty(num.tolMdotChange), tolMdot = num.tolMdotChange; end
for it = 1:num.maxOuterIterations
    if followT && T_o ~= mat.T_eval_K
        % solved T_o: water properties at the current operating temperature
        mat = updateFluidProperties(mat, T_o);
        [fields,vapor,wick] = applyFluidProperties(fields,mesh,caseData,mat,vapor,wick);
    end
    massScale = max(sum(max(mdot,0)), realmin);
    % vapor density at r = a from the interface state (ideal gas at p_v(z,a), T_i)
    vapor.rhoInterface = iface.pAbs./(mat.vapor.R*iface.Ti);
    [vapor,wick] = applyVelocityBCs(vapor,wick,mdot,A_int);
    for k = 1:num.innerFlowIterations
        [vapor,rv] = simpleIteration(vapor,num,num.alpha_u,massScale);
        [wick,rw]  = simpleIteration(wick,num,num.alpha_u_wick,massScale);
        if k == 1, rv1 = rv; rw1 = rw; end
    end

    % Pressure anchoring (gauge relative to p_o) and liquid wet-point reference,
    % both on the interface pressures p_v(z,a) and p_l(z,a).
    pVi = vaporInterfacePressure(vapor);
    if strcmpi(caseData.pressureReference,'point')
        vapor.p = vapor.p - pVi(jRef);
    else
        vapor.p = vapor.p - sum(pVi.*A_int)/sum(A_int);
    end
    pVi = vaporInterfacePressure(vapor);
    pLi = liquidInterfacePressure(wick);
    wick.p = wick.p - pLi(jWet) + pVi(jWet);
    vapor.rho = (iface.p_o + vapor.p)./(mat.vapor.R*fields.T(mesh.rowsVapor,:));

    % Energy with the current flow field.
    fields = flowIntoEnergyFields(fields,mesh,vapor,wick);
    Told = fields.T;
    [fields,iface,m,T_o] = solveEnergyWithInterface(mesh,fields,caseData,mat,num,bc,T_o,pVi);
    if usePaperStartup && it <= num.startupIterations
        target = outerFluxMassFlux(bc,m.hfg,A_int);
    else
        target = m.mdot;
    end
    mdotChange = max(abs(target - mdot))/max(max(abs(target)), realmin);
    mdot = num.alpha_mdot*target + (1 - num.alpha_mdot)*mdot;

    heat = computeCleanHeatRates(mesh,fields,bc,m);
    dT = max(abs(fields.T(:) - Told(:)));
    H = appendHistory(H,it,rv1,rw1,dT,mdotChange,heat,m,iface);
    if runMonitor(mesh,caseData,mat,num,bc,T_o,fields,iface,m,heat,vapor,wick,H,it)  % post-processing only: records Q_in/Q_out/R, live plots
        stoppedByUser = true;   % stop requested (GUI stop button)
        break;
    end

    % Flow residuals rv1/rw1 are the initial residuals of this outer iteration:
    % the incoming fields measured against the updated interface velocities,
    % density and temperatures, so they include the outer coupling. With
    % prescribed outer fluxes (paper Eq. 20) Qin - Qout is fixed by the input
    % and says nothing about the solution; the energy balance of the solution
    % is the interface closure (net heat into r = a over the latent heat) and,
    % after the loop, the energy residual re-evaluated on the final fields.
    momMax = max([rv1.momW rv1.momV rw1.momW rw1.momV]);
    boundaryOK = bc.levelFixedByAnchor || abs(heat.energyImbalance) <= num.tolEnergy;
    conv = rv1.mass <= num.tolMass && rw1.mass <= num.tolMass && momMax <= num.tolMomentum && ...
           dT <= num.tolTemperature_K && boundaryOK && m.relImbalance <= num.tolInterfaceClosure && ...
           mdotChange <= tolMdot && (~usePaperStartup || it > num.startupIterations);
    if num.verbose && (it == 1 || mod(it,num.printEvery) == 0 || conv)
        fprintf(['it %4d | mass v %.1e w %.1e | mom v %.1e/%.1e w %.1e/%.1e | dT %.1e K | dm %.1e | closure %.1e | ', ...
                 'Ti %.4f-%.4f C | Q %.3f/%.3f W\n'], it, rv1.mass, rw1.mass, rv1.momW, rv1.momV, ...
                 rw1.momW, rw1.momV, dT, mdotChange, m.relImbalance, min(iface.Ti)-273.15, max(iface.Ti)-273.15, heat.Qin, heat.Qout);
    end
    if conv
        converged = true;
        break;
    end
end
if stoppedByUser
    warning('runPaperModelSolver: stopped by the user after %d outer iterations (not converged).', it);
elseif ~converged
    warning('runPaperModelSolver: not converged after %d outer iterations.', num.maxOuterIterations);
end

% Residuals of every discrete equation re-evaluated on the returned fields.
F = evaluateFinalResiduals(mesh,fields,caseData,mat,num,bc,T_o,vapor,wick,m,iface);
F.maxDeltaT = dT;
F.mdotChange = mdotChange;
F.boundaryEnergyImbalance = heat.energyImbalance;   % (Qin - Qout)/Qin of the outer BCs; input bookkeeping for flux BCs
F.lastIteration = struct('massVapor',rv1.mass,'massWick',rw1.mass,'momVapor',[rv1.momW rv1.momV], ...
    'momWick',[rw1.momW rw1.momV]);
F.passed = F.massVapor <= num.tolMass && F.massWick <= num.tolMass && ...
    max([F.momVapor F.momWick]) <= num.tolMomentum && F.energy <= num.tolEnergyResidual && ...
    F.interfaceClosure <= num.tolInterfaceClosure;
if F.interfaceClosure > num.tolInterfaceClosure
    warning(['runPaperModelSolver: the global correction of the Eq. (16) mass flux is %.2e of the ', ...
             'evaporation rate (tolerance num.tolInterfaceClosure = %.1e).'], F.interfaceClosure, num.tolInterfaceClosure);
end
if converged && ~F.passed
    warning(['runPaperModelSolver: a residual re-evaluated on the final fields exceeds its tolerance ', ...
             '(mass %.1e/%.1e, momentum %.1e, energy %.1e, closure %.1e); the run is marked not converged.'], ...
             F.massVapor, F.massWick, max([F.momVapor F.momWick]), F.energy, F.interfaceClosure);
    converged = false;
end
if num.verbose
    fprintf(['Final fields: mass v %.1e w %.1e | mom v %.1e/%.1e w %.1e/%.1e | energy %.1e | closure %.1e | ', ...
             'T_i check %.1e K\n'], F.massVapor, F.massWick, F.momVapor, F.momWick, F.energy, F.interfaceClosure, F.interfaceTi_K);
    if ~bc.levelFixedByAnchor
        if followT
            fprintf('Solved T_o = %.4f degC; water properties evaluated at %.4f degC\n', T_o - 273.15, mat.T_eval_K - 273.15);
        else
            fprintf('Solved T_o = %.4f degC; fluid properties fixed (evaluated at %.4f degC)\n', T_o - 273.15, mat.T_eval_K - 273.15);
        end
    end
end

results.modelLevel = 'paper';
results.caseData = caseData; results.mat = mat; results.num = num; results.mesh = mesh;
results.bc = bc; results.T_o = T_o;
results.fields = fields; results.iface = iface; results.mdot = m; results.heat = heat;
results.vapor = vapor; results.wick = wick;
results.mdotApplied = mdot;
results.history = H;
results.converged = converged;
results.stoppedByUser = stoppedByUser;
results.iterations = it;
results.finalResiduals = F;
results.pVaporGauge = vaporInterfacePressure(vapor);
results.pLiquidGauge = liquidInterfacePressure(wick);
results.wallTime_s = toc(tStart);
end

% ========================================================================
function [fields,vapor,wick] = applyFluidProperties(fields,mesh,caseData,mat,vapor,wick)
% Copy re-evaluated fluid properties into the energy fields and the flow sub-domains.
fields = updateCleanProperties(fields,mesh,caseData,mat);   % k_v, k_eff, c_p of the convected phase
vapor.mu = mat.vapor.mu;
wick.mu = mat.liquid.mu;
wick.darcy = mat.wick.darcyCoefficient;
wick.rho(:) = mat.liquid.rho;
end

function mdot = outerFluxMassFlux(bc,hfg,A_int) %#ok<INUSD>
% Paper start-up: the interface heat flux equals the local outer-wall heat flux.
Q = bc.q.*bc.Aout;
mdot = Q./hfg;
mdot = mdot - sum(mdot)*A_int/sum(A_int);
end

function H = initHistory()
f = {'iter','massVapor','massWick','momVaporW','momVaporV','momWickW','momWickV','maxDeltaT', ...
     'mdotChange','energyImbalance','interfaceClosure','TiMin','TiMax','totalEvaporation'};
for k = 1:numel(f), H.(f{k}) = []; end
end

function H = appendHistory(H,it,rv,rw,dT,dm,heat,m,iface)
H.iter(end+1,1) = it;
H.massVapor(end+1,1) = rv.mass;   H.massWick(end+1,1) = rw.mass;
H.momVaporW(end+1,1) = rv.momW;   H.momVaporV(end+1,1) = rv.momV;
H.momWickW(end+1,1) = rw.momW;    H.momWickV(end+1,1) = rw.momV;
H.maxDeltaT(end+1,1) = dT;        H.mdotChange(end+1,1) = dm;
H.energyImbalance(end+1,1) = heat.energyImbalance;
H.interfaceClosure(end+1,1) = m.relImbalance;
H.TiMin(end+1,1) = min(iface.Ti); H.TiMax(end+1,1) = max(iface.Ti);
H.totalEvaporation(end+1,1) = m.totalEvaporation;
end
