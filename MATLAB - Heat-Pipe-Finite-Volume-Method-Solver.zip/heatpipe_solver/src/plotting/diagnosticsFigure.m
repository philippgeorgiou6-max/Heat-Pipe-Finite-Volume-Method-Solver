function fig = diagnosticsFigure()
%DIAGNOSTICSFIGURE Handle of the diagnostics window (reused if already open).
tag = 'heatpipeDiagnostics';
fig = findobj(0, 'Type', 'figure', 'Tag', tag);
if isempty(fig)
    fig = figure('Name', 'Heat pipe diagnostics', 'Tag', tag, 'Color', 'w', ...
                 'Position', [30 40 1600 1000], 'NumberTitle', 'off');
else
    fig = fig(1);
end
end
