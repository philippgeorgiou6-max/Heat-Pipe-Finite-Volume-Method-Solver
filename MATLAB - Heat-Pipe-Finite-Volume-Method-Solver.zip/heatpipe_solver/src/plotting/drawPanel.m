function drawPanel(name, results, fig, label)
%DRAWPANEL Draw one result panel into the current axes of figure FIG.
%
%   Panels: 'temperatureField', 'velocityField', 'axialTemperatures',
%   'pressures', 'massFlux', 'convergence', 'powerBalance',
%   'thermalResistance'. Used by the diagnostics window (all panels) and by
%   the end-of-run figures (one panel per window).
if nargin < 4, label = ''; end
switch name
    case 'temperatureField',  temperatureField(results);
    case 'velocityField',     velocityField(results, fig);
    case 'axialTemperatures', axialTemperatures(results);
    case 'pressures',         pressures(results);
    case 'massFlux',          massFlux(results);
    case 'convergence',       convergence(results, label);
    case 'powerBalance',      powerBalance(results);
    case 'thermalResistance', thermalResistance(results);
    otherwise
        error('drawPanel: unknown panel "%s".', name);
end
end

% ========================================================================
function col = panelColors()
col.heat  = [0.85 0.20 0.10];   % evaporator / heat input
col.cond  = [0.10 0.40 0.90];   % condenser / heat output
col.vapor = [0.55 0.55 0.55];
col.total = [0.30 0.30 0.30];
end

function cols = plotColumns(mesh)
% axial columns used for contour plots (at most ~120)
step = max(1, floor(mesh.Nz/120));
cols = 1:step:mesh.Nz;
end

% ---- temperature field (filled, no contour lines) ------------------------
function temperatureField(results)
mesh = results.mesh; c = results.caseData;
cols = plotColumns(mesh);
contourf(mesh.Zc(:,cols), 1e3*mesh.Rc(:,cols), results.fields.T(:,cols)-273.15, 40, 'LineStyle', 'none');
colorbar; xlabel('z [m]'); ylabel('r [mm]'); title('Temperature [degC]');
xlim([0 c.L_total]); ylim([0 1e3*c.R_outer]);
end

% ---- velocity field: vapor core + wick, with arrows ------------------------
function velocityField(results, fig)
P = results.profiles; c = results.caseData; mesh = results.mesh;
z = P.z; cols = plotColumns(mesh);
ax = gca;
rv = results.vapor.rc(:)'; rw = results.wick.rc(:)';
spdV = P.vaporSpeed;
spdWraw = sqrt(P.wickW.^2 + P.wickV.^2);           % wick intrinsic speed
% Display factor for the wick: chosen so that the wick peak equals the vapor
% peak, i.e. both fields are shown on the same scale (recomputed every redraw).
if max(spdV(:)) > 0 && max(spdWraw(:)) > 0
    wickScale = max(spdV(:))/max(spdWraw(:));
else
    wickScale = 1;
end
spdW = wickScale*spdWraw;
umax = max([spdV(:); spdW(:); realmin]);
[Zv,Rv] = meshgrid(z(cols), 1e3*rv);
[Zw,Rw] = meshgrid(z(cols), 1e3*rw);
lev = linspace(0, umax, 41);
contourf(Zv, Rv, spdV(:,cols), lev, 'LineStyle', 'none'); hold on;
contourf(Zw, Rw, spdW(:,cols), lev, 'LineStyle', 'none');
caxis([0 umax]); colorbar;
plot([0 c.L_total], 1e3*c.R_vapor*[1 1], 'w--', 'LineWidth', 1.0);   % interface r = a
xlim([0 c.L_total]); ylim([0 1e3*c.R_wick]);
xlabel('z [m]'); ylabel('r [mm]');
% Radial exaggeration of the arrows (display only, colours stay |u|): the
% largest radial vapor velocity is drawn as long as the largest axial one,
% which makes the blowing/suction at r = a and the circulation visible.
if max(abs(P.vaporV(:))) > 0 && max(abs(P.vaporW(:))) > 0
    radialScale = max(abs(P.vaporW(:)))/max(abs(P.vaporV(:)));
else
    radialScale = 1;
end
title(sprintf('Velocity |u| [m/s]: vapor max %.3f, wick max %.2e (shown x%.0f); arrows: radial x%.0f', ...
    max(spdV(:)), max(spdWraw(:)), wickScale, radialScale));
% arrows on a uniform grid: 6 rows in the vapor core, 1 row at mid-wick
nzA = 20;
zA = linspace(0, c.L_total, nzA + 2); zA = zA(2:end-1);
rAv = linspace(0, c.R_vapor, 8); rAv = rAv(2:end-1);
rAw = 0.5*(c.R_vapor + c.R_wick);
[ZAv,RAv] = meshgrid(zA, rAv);
[ZAw,RAw] = meshgrid(zA, rAw);
ZA = [ZAv; ZAw]; RA = [RAv; RAw];
WA = [interp2(z, rv, P.vaporW, ZAv, RAv, 'linear', 0); ...
      wickScale*interp2(z, rw, P.wickW, ZAw, RAw, 'linear', 0)];
VA = radialScale*[interp2(z, rv, P.vaporV, ZAv, RAv, 'linear', 0); ...
                  wickScale*interp2(z, rw, P.wickV, ZAw, RAw, 'linear', 0)];
amax = max([hypot(WA(:), VA(:)); realmin]);        % longest drawn arrow
drawArrows(ax, fig, ZA, 1e3*RA, WA, VA, amax, 0.7*(zA(2) - zA(1)));
hold off;
end

% ---- axial temperatures: outer wall and axis ------------------------------
function axialTemperatures(results)
P = results.profiles; c = results.caseData; col = panelColors();
hold on; box on; grid on;
h1 = plot(P.z, P.T_outerWall_K-273.15, 'b-', 'LineWidth', 1.4);
h2 = plot(P.z, P.T_centerline_K-273.15, 'r--', 'LineWidth', 1.3);
xlim([0 c.L_total]);
yl = ylim; ybar = yl(1) + 0.04*(yl(2)-yl(1));
h3 = plot(c.heaterSegments_m(1,:), [ybar ybar], '-', 'Color', col.heat, 'LineWidth', 5);   % evaporator
h4 = plot([c.condenserStart c.condenserEnd], [ybar ybar], '-', 'Color', col.cond, 'LineWidth', 5);   % condenser
xlabel('z [m]'); ylabel('T [degC]');
namedLegend([h1 h2 h3 h4], {'outer wall (r = c)','axis (r = 0)','evaporator','condenser'}, 'northeast');
title(sprintf('Axial temperatures, peak wall %.2f degC', max(P.T_outerWall_K)-273.15));
hold off;
end

% ---- pressures --------------------------------------------------------------
function pressures(results)
P = results.profiles;
h = plot(P.z, P.pVapor_Pa - P.p_o, 'r-', P.z, P.pLiquid_Pa - P.p_o, 'b-', 'LineWidth', 1.3); grid on;
xlabel('z [m]'); ylabel('p - p_o [Pa]'); namedLegend(h, {'vapor (r = a)','liquid (r = a)'}, 'southeast');
title(sprintf('Pressures, vapor dp = %.3f Pa', P.vaporDp_Pa));
end

% ---- interface mass flux --------------------------------------------------
function massFlux(results)
P = results.profiles;
plot(P.z, P.mpp, 'k-', 'LineWidth', 1.3); grid on;
xlabel('z [m]'); ylabel('m'''' [kg/m^2 s], + = evaporation'); title('Interface mass flux (Eq. 16)');
end

% ---- convergence -----------------------------------------------------------
function convergence(results, label)
H = results.history;
clip = @(x) min(max(x,1e-16),1e2);
h = semilogy(H.iter, clip(H.massVapor), 'r-', H.iter, clip(H.massWick), 'b-', ...
         H.iter, clip(max(H.momVaporW,H.momVaporV)), 'm-', H.iter, clip(H.maxDeltaT), 'k-', 'LineWidth', 1.2);
grid on; xlabel('outer iteration'); ylabel('residual'); ylim([1e-16 1e2]); set(gca,'YTick',10.^(-16:4:0));
namedLegend(h, {'mass vapor','mass wick','mom. vapor','max dT [K]'}, 'northeast');
title('Convergence');
if ~isempty(label)
    text(0.04, 0.06, compactStatus(results, label), 'Units', 'normalized', 'HorizontalAlignment', 'left', ...
         'VerticalAlignment', 'bottom', 'Interpreter', 'none');
end
end

% ---- power in / out vs. iteration -----------------------------------------
function powerBalance(results)
col = panelColors();
[it, Qin, Qout] = monitorSeries(results);
mk = 'none'; if numel(it) == 1, mk = 'o'; end
hold on; box on; grid on;
h1 = plot(it, Qin,  '-',  'Color', col.heat, 'LineWidth', 2.4, 'Marker', mk);
h2 = plot(it, Qout, '--', 'Color', col.cond, 'LineWidth', 1.6, 'Marker', mk);
Qmax = max([Qin(:); Qout(:); 1e-12]);
xlim([0 max(it(end), 1)]); ylim([0 1.3*Qmax]);
xlabel('outer iteration'); ylabel('power [W]');
namedLegend([h1 h2], {sprintf('Q_{in} = %.2f W', Qin(end)), sprintf('Q_{out} = %.2f W', Qout(end))}, 'southeast');
text(0.5, 0.93, sprintf('(Q_{in} - Q_{out})/Q_{in} = %.1e', (Qin(end) - Qout(end))/max(abs(Qin(end)), 1e-12)), ...
     'Units', 'normalized', 'HorizontalAlignment', 'center', 'VerticalAlignment', 'middle');
title('Power in / out');
hold off;
end

% ---- total thermal resistance vs. iteration ---------------------------------
function thermalResistance(results)
% R_total = (mean outer-wall T over the evaporator - mean outer-wall T over
% the condenser)/Q (computeThermalResistance; the split into evaporator,
% vapor and condenser resistances is written to RUN_SUMMARY.txt).
col = panelColors();
[it, ~, ~, R] = monitorSeries(results);
mk = 'none'; if numel(it) == 1, mk = 'o'; end
plot(it, R, '-', 'Color', col.total, 'LineWidth', 1.8, 'Marker', mk); grid on; box on;
xlim([0 max(it(end), 1)]);
Rf = R(isfinite(R));
if ~isempty(Rf) && max(Rf) > 0
    ylim([min([Rf(:); 0]) 1.4*max(Rf)]);   % axis from zero: shows the size of the changes honestly
end
xlabel('outer iteration'); ylabel('R_{total} [K/W]');
title('Total thermal resistance R = \DeltaT/Q');
text(0.5, 0.92, sprintf('R = %.5f K/W', R(end)), ...
     'Units', 'normalized', 'HorizontalAlignment', 'center', 'VerticalAlignment', 'middle');
text(0.5, 0.83, '\DeltaT = T_{wall,evap} - T_{wall,cond}', ...
     'Units', 'normalized', 'HorizontalAlignment', 'center', 'VerticalAlignment', 'middle');
end

function txt = compactStatus(results, label)
% short run status for the convergence panel
it = results.history.iter(end);
if strncmp(label, 'live', 4)
    txt = sprintf('live, iteration %d', it);
elseif isfield(results, 'stoppedByUser') && results.stoppedByUser
    txt = sprintf('stopped at iteration %d', it);
elseif isfield(results, 'converged') && results.converged
    txt = sprintf('converged, %d iterations', it);
else
    txt = sprintf('not converged, %d iterations', it);
end
end

function [it, Qin, Qout, R] = monitorSeries(results)
% Per-iteration history recorded by runMonitor. Without a history (solver
% called directly), the current state is shown as a single point.
if isfield(results,'monitor') && ~isempty(results.monitor) && ~isempty(results.monitor.iter)
    M = results.monitor;
    it = M.iter; Qin = M.Qin_W; Qout = M.Qout_W; R = M.Rtotal_KW;
else
    it = results.iterations; Qin = results.heat.Qin; Qout = results.heat.Qout;
    R = results.profiles.R_total_KW;
end
end

% ========================================================================
function drawArrows(ax, fig, X, Y, U, V, umax, Lmax)
% Arrows with filled tips, built in screen (pixel) coordinates so that the
% length is proportional to |(U,V)| and the direction and tip shape are true
% on screen, however strongly the axes stretch r against z.
% Lmax: on-screen length of the longest arrow, expressed in x-data units.
pos = axesPixelSize(ax, fig);
xl = xlim(ax); yl = ylim(ax);
sx = pos(1)/diff(xl); sy = pos(2)/diff(yl);        % pixels per data unit
s = Lmax*sx/umax;                                   % pixels per (m/s)
dx = s*U(:); dy = s*V(:);                           % arrow vectors in pixels
len = hypot(dx, dy);
keep = len > 1.0;                                   % skip arrows shorter than 1 pixel
x0 = X(keep)*sx; y0 = Y(keep)*sy; dx = dx(keep); dy = dy(keep); len = len(keep);
ex = dx./len; ey = dy./len;                         % unit direction
hl = min(0.35*len, 9); hw = 0.45*hl;                % tip length and half-width [px]
xt = x0 + dx; yt = y0 + dy;                         % tip point
xb = xt - hl.*ex; yb = yt - hl.*ey;                 % tip base centre
n = numel(x0);
shaftX = [x0, xb, nan(n,1)]'/sx; shaftY = [y0, yb, nan(n,1)]'/sy;
plot(ax, shaftX(:), shaftY(:), 'k-', 'LineWidth', 1.2);
tipX = [xt, xb - hw.*ey, xb + hw.*ey]'/sx;
tipY = [yt, yb + hw.*ex, yb - hw.*ex]'/sy;
if n > 0
    patch(tipX, tipY, 'k', 'EdgeColor', 'k', 'Parent', ax);
end
end

function wh = axesPixelSize(ax, fig)
% Width and height of the axes in pixels (plot box, without labels).
oldA = get(ax,'Units'); oldF = get(fig,'Units');
set(ax,'Units','pixels'); set(fig,'Units','pixels');
p = get(ax,'Position');
set(ax,'Units',oldA); set(fig,'Units',oldF);
wh = max(p(3:4), 1);
end
