function [y, ticks, tickLabels] = stretchRadius(r, caseData)
%STRETCHRADIUS Display coordinate for the radially stretched geometry/mesh views.
%   The radial direction is stretched piecewise so that every region is
%   visible: vapor core [0, a] -> [0, 0.5], wick [a, b] -> [0.5, 0.75],
%   wall [b, c] -> [0.75, 1]. Tick marks show the true radii in mm.
a = caseData.R_vapor; b = caseData.R_wick; c = caseData.R_outer;
y = interp1([0 a b c], [0 0.5 0.75 1], r, 'linear', 'extrap');
ticks = [0 0.5 0.75 1];
tickLabels = {'0', sprintf('%.2f', 1e3*a), sprintf('%.2f', 1e3*b), sprintf('%.2f', 1e3*c)};
end
