function drawZoneStrip(ax, caseData, y0, y1, withLengths, zRange_mm)
%DRAWZONESTRIP Coloured strip of the axial zones (in mm) between y0 and y1,
%   optionally labelled with the zone lengths; clipped to zRange_mm.
if nargin < 5, withLengths = true; end
if nargin < 6 || isempty(zRange_mm), zRange_mm = [0 1e3*caseData.L_total]; end
col = geometryColors();
mm = 1e3;
zones = {0,                         caseData.heaterSegments_m(1,1), 'unheated',   col.unheated;
         caseData.heaterSegments_m(1,1), caseData.heaterSegments_m(1,2), 'evaporator', col.evap;
         caseData.transportStart,   caseData.transportEnd,   'transport',  col.transport;
         caseData.condenserStart,   caseData.condenserEnd,   'condenser',  col.cond;
         caseData.condenserEnd,     caseData.L_total,        'unheated',   col.unheated};
L = mm*caseData.L_total;
for k = 1:size(zones,1)
    za = max(mm*zones{k,1}, zRange_mm(1)); zb = min(mm*zones{k,2}, zRange_mm(2));
    if zb - za <= 0, continue; end
    patch([za zb zb za], [y0 y0 y1 y1], zones{k,4}, 'EdgeColor', [0.3 0.3 0.3], 'Parent', ax);
    if withLengths
        txt = sprintf('%s %.1f mm', zones{k,3}, zb - za);
        if zb - za > 0.12*L
            text(0.5*(za+zb), 0.5*(y0+y1), txt, 'Parent', ax, 'HorizontalAlignment', 'center', ...
                 'VerticalAlignment', 'middle', 'FontWeight', 'bold', 'Color', textColor(zones{k,4}));
        else
            % short zone: label above the strip, alternating heights
            yl = y1 + 0.05 + 0.07*mod(k,2);
            plot(ax, 0.5*(za+zb)*[1 1], [y1 yl-0.01], '-', 'Color', [0.3 0.3 0.3]);
            text(0.5*(za+zb), yl, txt, 'Parent', ax, 'HorizontalAlignment', alignFor(0.5*(za+zb), L), ...
                 'VerticalAlignment', 'bottom', 'FontSize', 8);
        end
    end
end
end

function h = alignFor(x, L)
if x < 0.1*L, h = 'left'; elseif x > 0.9*L, h = 'right'; else, h = 'center'; end
end

function c = textColor(bg)
if mean(bg) < 0.55, c = 'w'; else, c = 'k'; end
end
