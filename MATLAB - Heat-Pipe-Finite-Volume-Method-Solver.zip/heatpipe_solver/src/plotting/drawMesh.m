function drawMesh(ax, mesh, caseData, zRange_mm)
%DRAWMESH Mesh lines over the regions, radially stretched (see stretchRadius).
%   zRange_mm : optional axial range to show [mm] (detail view)
fig = ancestor(ax, 'figure');
set(fig, 'CurrentAxes', ax);
cla(ax, 'reset'); hold(ax, 'on');
mm = 1e3;
L = mm*caseData.L_total;
if nargin < 4 || isempty(zRange_mm), zRange_mm = [0 L]; end
col = geometryColors();
z0 = zRange_mm(1); z1 = zRange_mm(2);
fills = {0, 0.5, col.vapor; 0.5, 0.75, col.wick; 0.75, 1.0, col.wall};
for k = 1:3
    patch([z0 z1 z1 z0], [fills{k,1} fills{k,1} fills{k,2} fills{k,2}], fills{k,3}, ...
          'EdgeColor', 'none', 'Parent', ax);
end
zn = mm*mesh.z_nodes(:)';
zn = zn(zn >= z0 - 1e-9 & zn <= z1 + 1e-9);                                   % only the shown faces
rn = stretchRadius(mesh.r_nodes(:)', caseData);
nz = numel(zn); nr = numel(rn);
X = [zn; zn; nan(1,nz)];  Y = [zeros(1,nz); ones(1,nz); nan(1,nz)];
plot(ax, X(:), Y(:), '-', 'Color', [0.25 0.25 0.25], 'LineWidth', 0.4);          % axial faces
X = [z0*ones(1,nr); z1*ones(1,nr); nan(1,nr)]; Y = [rn; rn; nan(1,nr)];
plot(ax, X(:), Y(:), '-', 'Color', [0.25 0.25 0.25], 'LineWidth', 0.4);          % radial faces
plot(ax, [z0 z1], stretchRadius(caseData.R_vapor, caseData)*[1 1], '-', 'Color', [0 0 0], 'LineWidth', 1.4);
plot(ax, [z0 z1], stretchRadius(caseData.R_wick,  caseData)*[1 1], '-', 'Color', [0 0 0], 'LineWidth', 1.4);
drawZoneStrip(ax, caseData, 1.03, 1.13, false, zRange_mm);
set(ax, 'XLim', zRange_mm, 'YLim', [0 1.16], 'Layer', 'top', 'Box', 'on');
[~, ticks, labels] = stretchRadius(0, caseData);
set(ax, 'YTick', ticks, 'YTickLabel', labels);
xlabel(ax, 'z [mm]'); ylabel(ax, 'r [mm]  (stretched)');
hold(ax, 'off');
end
