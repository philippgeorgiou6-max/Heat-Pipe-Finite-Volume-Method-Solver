function setupHeadlessGraphics()
%SETUPHEADLESSGRAPHICS Make figures work without a display (Octave: gnuplot toolkit).
if isOctave()
    if isempty(getenv('DISPLAY'))
        try
            graphics_toolkit('gnuplot');
        catch
        end
        set(0,'defaultfigurevisible','off');
    end
end
end
