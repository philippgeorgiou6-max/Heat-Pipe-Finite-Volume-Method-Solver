function col = geometryColors()
%GEOMETRYCOLORS Colours of the regions and zones in the geometry/mesh views.
col.vapor     = [0.82 0.91 1.00];
col.wick      = [0.95 0.86 0.62];
col.wall      = [0.72 0.45 0.28];
col.evap      = [0.85 0.20 0.10];
col.cond      = [0.10 0.40 0.90];
col.transport = [0.80 0.80 0.80];
col.unheated  = [0.95 0.95 0.95];
end
