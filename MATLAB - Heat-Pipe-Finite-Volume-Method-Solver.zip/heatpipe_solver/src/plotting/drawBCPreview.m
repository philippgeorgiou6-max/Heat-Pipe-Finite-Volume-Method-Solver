function info = drawBCPreview(axQ, axT, caseData)
%DRAWBCPREVIEW Imposed outer-wall boundary conditions along the pipe.
%   axQ : prescribed heat flux [W/m^2] (+ into the pipe) of the flux zones
%   axT : prescribed wall temperature or ambient temperature T_inf [degC] of
%         the temperature and convection zones
%   The BCs are built with the solver's own buildOuterThermalBC on a fine
%   preview grid, so the preview shows exactly what the solver will impose.
%   info : heat input/removal of the flux zones, flux-only flag, condenser
%          scale factor and a warning text (if any)
num = struct('NvaporR', 1, 'NwickR', 1, 'NwallR', 1, ...
             'axialMaxCellSize_m', caseData.L_total/1000, 'axialCellsTotal', [], ...
             'axialMinCellsPerSegment', 4, 'gridPreset', 'preview', 'verbose', false);
num.radialSpacing = {'uniform','uniform','uniform'};
mesh = tagCleanRegionsAndBoundaries(createCleanMesh(caseData, num), caseData);
matP.wall.k = caseData.wallConductivity_W_mK;
lastwarn('');
bc = buildOuterThermalBC(mesh, caseData, matP);
info.warning = lastwarn;
qA = bc.q.*bc.Aout;
info.Qin_W = sum(qA(qA > 0));
info.Qout_W = -sum(qA(qA < 0));
info.fluxOnly = bc.levelFixedByAnchor;
info.condenserScale = bc.condenserScale;

z = 1e3*mesh.z_centers;
zoneMasks = {mesh.heaterIndex > 0, mesh.zone == 4, mesh.isCondenser, mesh.zone == 1 | mesh.zone == 6};
zoneNames = {'evaporator', 'transport', 'condenser', 'end sections'};
zoneTypes = {bc.evaporatorType, bc.transportType, bc.condenserType, 'adiabatic'};
col = geometryColors();
zoneColors = {col.evap, [0.45 0.45 0.45], col.cond, [0.65 0.65 0.65]};
convH = [caseData.evaporatorH_W_m2K, caseData.transportH_W_m2K, caseData.condenserH_W_m2K, NaN];
L = 1e3*caseData.L_total;
bounds = 1e3*[caseData.heaterSegments_m(1,:), caseData.condenserStart, caseData.condenserEnd];

% ---- heat flux of the flux zones
fig = ancestor(axQ, 'figure');
set(fig, 'CurrentAxes', axQ); cla(axQ, 'reset'); removeLegend(axQ); hold(axQ, 'on'); grid(axQ, 'on'); box(axQ, 'on');
hQ = []; lQ = {};
for k = 1:4
    m = zoneMasks{k} & bc.robinG == 0;
    if any(m)
        hQ(end+1) = plot(axQ, z(m), bc.q(m), '.', 'Color', zoneColors{k}, 'MarkerSize', 8); %#ok<AGROW>
        lQ{end+1} = sprintf('%s (%s)', zoneNames{k}, typeLabel(zoneTypes{k})); %#ok<AGROW>
    end
end
plot(axQ, [0 L], [0 0], 'k-', 'LineWidth', 0.5);
zoneLines(axQ, bounds);
xlim(axQ, [0 L]);
ylabel(axQ, 'heat flux q [W/m^2]  (+ into the pipe)');
if info.Qin_W == 0 && info.Qout_W == 0
    title(axQ, 'Prescribed heat flux: none (adiabatic sections only)');
else
    title(axQ, sprintf('Prescribed heat flux: input %.2f W, removal %.2f W', info.Qin_W, abs(info.Qout_W)));
end
if ~isempty(hQ), namedLegend(hQ, lQ, 'northeast'); end
hold(axQ, 'off');

% ---- temperature / ambient temperature of the other zones
set(fig, 'CurrentAxes', axT); cla(axT, 'reset'); removeLegend(axT); hold(axT, 'on'); grid(axT, 'on'); box(axT, 'on');
hT = []; lT = {};
for k = 1:3
    m = zoneMasks{k} & bc.robinG > 0;
    if ~any(m), continue; end
    if strcmp(zoneTypes{k}, 'convection')
        hT(end+1) = plot(axT, z(m), bc.robinT(m) - 273.15, '--', 'Color', zoneColors{k}, 'LineWidth', 1.6); %#ok<AGROW>
        lT{end+1} = sprintf('%s: T_{inf}, h = %g W/m^2K', zoneNames{k}, convH(k)); %#ok<AGROW>
    else
        hT(end+1) = plot(axT, z(m), bc.robinT(m) - 273.15, '-', 'Color', zoneColors{k}, 'LineWidth', 2); %#ok<AGROW>
        lT{end+1} = sprintf('%s: wall temperature', zoneNames{k}); %#ok<AGROW>
    end
end
zoneLines(axT, bounds);
xlim(axT, [0 L]);
xlabel(axT, 'z [mm]'); ylabel(axT, 'T [degC]');
if isempty(hT)
    set(axT, 'YTick', []);
    text(0.5*L, 0.5, sprintf('No temperature or convection BC: the level is set by T_o = %.2f degC', ...
         caseData.T_o_K - 273.15), 'Parent', axT, 'HorizontalAlignment', 'center');
    ylim(axT, [0 1]);
    title(axT, 'Prescribed temperatures');
else
    namedLegend(hT, lT, 'north');
    title(axT, 'Prescribed wall temperatures (solid) and ambient temperatures of convection BCs (dashed)');
end
hold(axT, 'off');
end

function removeLegend(ax)
try
    legend(ax, 'off');
catch
    % no legend present (Octave raises an error in this case)
end
end

function zoneLines(ax, bounds)
yl = get(ax, 'YLim');
for b = bounds
    plot(ax, [b b], yl, ':', 'Color', [0.5 0.5 0.5]);
end
set(ax, 'YLim', yl);
end

function s = typeLabel(t)
switch t
    case 'power',                    s = 'input power';
    case 'heatFluxFunction',         s = 'q(z)';
    case 'paperEq20UniformHeatFlux', s = 'removes the input, Eq. 20';
    case 'heatFlux',                 s = 'uniform flux';
    case 'adiabatic',                s = 'adiabatic';
    otherwise,                       s = t;
end
end
