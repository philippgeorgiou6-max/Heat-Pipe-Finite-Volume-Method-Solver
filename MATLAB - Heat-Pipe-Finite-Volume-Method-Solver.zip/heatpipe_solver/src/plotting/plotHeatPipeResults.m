function figs = plotHeatPipeResults(results)
%PLOTHEATPIPERESULTS End-of-run windows: the diagnostics window with the final
%   state (the live window of the run is reused if it is still open) and every
%   result diagram in its own window.
%   figs.diagnostics : handle of the diagnostics window
%   figs.separate    : struct array (name, file, handle) of the single windows
label = finalLabel(results);
figs.diagnostics = diagnosticsFigure();
plotDiagnostics(results, figs.diagnostics, label);
panels = resultPanels();
scr = get(0, 'ScreenSize');
figs.separate = struct('name', {}, 'file', {}, 'handle', {});
for k = 1:size(panels,1)
    sz = panels{k,3};
    left = 40 + 30*(k-1);                                   % cascade the windows
    bottom = max(40, scr(4) - sz(2) - 90 - 30*(k-1));
    f = figure('Name', panels{k,4}, 'NumberTitle', 'off', 'Color', 'w', 'Position', [left bottom sz]);
    drawPanel(panels{k,1}, results, f, label);
    figs.separate(k).name = panels{k,1};
    figs.separate(k).file = panels{k,2};
    figs.separate(k).handle = f;
end
end
