function namedLegend(h, labels, location)
%NAMEDLEGEND Legend with explicit handles and names (never "data1", "data2", ...).
%   Objects added to the axes later are not added to the legend (AutoUpdate off).
for k = 1:numel(h)
    set(h(k), 'DisplayName', labels{k});
end
try
    legend(h, labels, 'Location', location, 'AutoUpdate', 'off');
catch
    legend(h, labels, 'Location', location);   % releases without AutoUpdate
end
end
