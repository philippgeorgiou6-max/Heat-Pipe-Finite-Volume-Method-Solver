function label = finalLabel(results)
%FINALLABEL Short status text of a finished run.
if isfield(results,'stoppedByUser') && results.stoppedByUser
    label = sprintf('stopped by the user after %d iterations (not converged)', results.iterations);
elseif results.converged
    label = sprintf('final: %d iterations, converged', results.iterations);
else
    label = sprintf('final: %d iterations, NOT converged', results.iterations);
end
end
