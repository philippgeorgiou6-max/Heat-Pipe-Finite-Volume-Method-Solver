function panels = resultPanels()
%RESULTPANELS Result diagrams: panel name, file name, figure size [px], title.
panels = {'temperatureField',  'temperature_field',   [1100 420], 'Temperature field';
          'velocityField',     'velocity_field',      [1100 440], 'Velocity field';
          'axialTemperatures', 'axial_temperatures',  [900 480],  'Axial temperatures';
          'massFlux',          'interface_mass_flux', [900 480],  'Interface mass flux';
          'pressures',         'pressures',           [900 480],  'Pressures';
          'convergence',       'convergence',         [760 520],  'Convergence';
          'powerBalance',      'power_in_out',        [760 480],  'Power in / out';
          'thermalResistance', 'thermal_resistance',  [760 480],  'Total thermal resistance'};
end
