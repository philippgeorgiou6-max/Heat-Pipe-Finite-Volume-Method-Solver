function out = runMonitor(varargin)
%RUNMONITOR Post-processing monitor of the outer iteration.
%
%   stop = runMonitor(mesh,caseData,mat,num,bc,T_o,fields,iface,m,heat,vapor,wick,H,it)
%       Called by runPaperModelSolver after every outer iteration. Records the
%       heat input and output and the total thermal resistance of the current
%       iterate and updates the live plots every num.livePlotEvery iterations:
%         - num.liveCallback(results, label) if it is set (GUI), otherwise
%         - the diagnostics window (if num.livePlots is set and a display exists).
%       Returns true when a stop was requested (num.stopRequestFcn, GUI stop
%       button). Only reads the solver state; the solver numerics are unaffected.
%
%   M = runMonitor('get')
%       History of the last run: M.iter, M.Qin_W, M.Qout_W, M.Rtotal_KW.
persistent hist
out = false;
if nargin == 1
    out = hist;
    return;
end
[mesh,caseData,mat,num,bc,T_o,fields,iface,m,heat,vapor,wick,H,it] = varargin{:};
if it == 1 || isempty(hist)                       % new run
    hist = struct('iter', zeros(0,1), 'Qin_W', zeros(0,1), 'Qout_W', zeros(0,1), 'Rtotal_KW', zeros(0,1));
end
Rth = computeThermalResistance(mesh, caseData, outerWallTemperature(mesh, bc, mat, fields.T), fields.T(1,:), heat.Qevap_W);
hist.iter(end+1,1)      = it;
hist.Qin_W(end+1,1)     = heat.Qin;
hist.Qout_W(end+1,1)    = heat.Qout;
hist.Rtotal_KW(end+1,1) = Rth.total;

% ---- live plots
hasCallback = isfield(num,'liveCallback') && ~isempty(num.liveCallback);
due = num.livePlots && mod(it, num.livePlotEvery) == 0;
if due && (hasCallback || canShowFigures())
    r.caseData = caseData; r.mat = mat; r.num = num; r.mesh = mesh; r.bc = bc; r.T_o = T_o;
    r.fields = fields; r.iface = iface; r.mdot = m; r.heat = heat;
    r.vapor = vapor; r.wick = wick; r.history = H; r.iterations = it; r.monitor = hist;
    r.converged = false;
    r.pVaporGauge = vaporInterfacePressure(vapor);
    r.pLiquidGauge = liquidInterfacePressure(wick);
    r.profiles = computeDerivedProfiles(r);
    label = sprintf('live: iteration %d', it);
    if hasCallback
        num.liveCallback(r, label);
    else
        fig = diagnosticsFigure();
        plotDiagnostics(r, fig, label);
        drawnow;
    end
end

% ---- stop request (GUI)
if isfield(num,'stopRequestFcn') && ~isempty(num.stopRequestFcn)
    out = logical(num.stopRequestFcn());
end
end
