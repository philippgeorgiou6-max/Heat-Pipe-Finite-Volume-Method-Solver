function tf = canShowFigures()
%CANSHOWFIGURES True when figures can be shown on screen (no batch/headless run).
if isOctave()
    tf = ~isempty(getenv('DISPLAY')) || ispc() || ismac();
else
    tf = usejava('desktop') || (usejava('awt') && feature('ShowFigureWindows'));
end
end
