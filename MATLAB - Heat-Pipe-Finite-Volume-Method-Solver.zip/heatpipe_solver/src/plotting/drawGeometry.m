function drawGeometry(ax, caseData)
%DRAWGEOMETRY Half section (axis to outer wall) of the heat pipe with regions,
%   axial zones and dimensions. The radial direction is stretched (see
%   stretchRadius) so that the wick and the wall are visible.
fig = ancestor(ax, 'figure');
set(fig, 'CurrentAxes', ax);
cla(ax, 'reset'); hold(ax, 'on');
L = 1e3*caseData.L_total;
col = geometryColors();
a = caseData.R_vapor; b = caseData.R_wick; c = caseData.R_outer;

% ---- radial regions
regionPatch(ax, 0, L, 0, 0.5, col.vapor);
regionPatch(ax, 0, L, 0.5, 0.75, col.wick);
regionPatch(ax, 0, L, 0.75, 1.0, col.wall);
plot(ax, [0 L], [0 0], '-.', 'Color', [0.35 0.35 0.35], 'LineWidth', 1);
text(0.5*L, 0.25, sprintf('Vapor core   (radius a = %.2f mm)', 1e3*a), 'Parent', ax, ...
     'HorizontalAlignment', 'center', 'FontWeight', 'bold');
text(0.5*L, 0.625, sprintf('Wick   (thickness %.2f mm, outer radius b = %.2f mm)', 1e3*(b-a), 1e3*b), 'Parent', ax, ...
     'HorizontalAlignment', 'center');
text(0.5*L, 0.875, sprintf('Wall   (thickness %.2f mm, outer radius c = %.2f mm)', 1e3*(c-b), 1e3*c), 'Parent', ax, ...
     'HorizontalAlignment', 'center', 'Color', 'w', 'FontWeight', 'bold');
text(0.01*L, 0.04, 'axis r = 0', 'Parent', ax, 'Color', [0.35 0.35 0.35], 'VerticalAlignment', 'bottom');

% ---- axial zones (strip above the wall) with lengths
drawZoneStrip(ax, caseData, 1.03, 1.15, true);

set(ax, 'XLim', [0 L], 'YLim', [0 1.36], 'Layer', 'top', 'Box', 'on');
[~, ticks, labels] = stretchRadius(0, caseData);
set(ax, 'YTick', ticks, 'YTickLabel', labels);
xlabel(ax, 'z [mm]'); ylabel(ax, 'r [mm]  (stretched)');
title(ax, sprintf('Geometry: length %.1f mm, outer diameter %.2f mm  (radial direction stretched, not to scale)', ...
    L, 2e3*c));
hold(ax, 'off');
end

function regionPatch(ax, x0, x1, y0, y1, color)
patch([x0 x1 x1 x0], [y0 y0 y1 y1], color, 'EdgeColor', [0.3 0.3 0.3], 'Parent', ax);
end
