function plotDiagnostics(results, container, label)
%PLOTDIAGNOSTICS Draw all result panels into a figure or a uipanel.
%
%   temperature field          | axial temperatures (outer wall, axis)
%   velocity field (with wick) | interface mass flux
%   pressures | convergence    | power in/out  | total thermal resistance  (both vs. iteration)
%
%   container : figure (diagnostics window) or uipanel (GUI live-plot panel)
if nargin < 3, label = ''; end
fig = ancestor(container, 'figure');
set(0, 'CurrentFigure', fig);
if strcmp(get(container,'Type'), 'figure')
    clf(container);
    set(container, 'Name', strtrim(sprintf('Heat pipe diagnostics  %s', label)));
else
    delete(allchild(container));
end
layout = {'temperatureField',  1, 1, 2;      % panel, row, column, column span
          'axialTemperatures', 1, 3, 2;
          'velocityField',     2, 1, 2;
          'massFlux',          2, 3, 2;
          'pressures',         3, 1, 1;
          'convergence',       3, 2, 1;
          'powerBalance',      3, 3, 1;
          'thermalResistance', 3, 4, 1};
for k = 1:size(layout,1)
    ax = axes('Parent', container, 'Units', 'normalized', ...
              'Position', gridPosition(layout{k,2}, layout{k,3}, layout{k,4}));
    set(fig, 'CurrentAxes', ax);
    drawPanel(layout{k,1}, results, fig, label);
end
end

function pos = gridPosition(row, col, span)
% 3 x 4 grid in normalized units of the container
left = 0.055; right = 0.02; bottom = 0.065; top = 0.045;
gapX = 0.065; gapY = 0.10;
colW = (1 - left - right - 3*gapX)/4;
rowH = (1 - bottom - top - 2*gapY)/3;
x = left + (col-1)*(colW + gapX);
y = bottom + (3-row)*(rowH + gapY);
pos = [x, y, span*colW + (span-1)*gapX, rowH];
end
