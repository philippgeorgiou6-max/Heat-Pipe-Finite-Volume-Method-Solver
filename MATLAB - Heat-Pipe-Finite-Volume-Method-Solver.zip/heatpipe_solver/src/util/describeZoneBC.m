function s = describeZoneBC(caseData, zone)
%DESCRIBEZONEBC One-line description of the outer-wall BC of a zone.
%   zone: 'evaporator', 'transport' or 'condenser'
C = @(TK) TK - 273.15;
switch lower(zone)
    case 'evaporator'
        switch normalizeOuterBCType(caseData.evaporatorBCType)
            case 'power',               s = sprintf('input power %.2f W (uniform heat flux)', caseData.evaporatorPowers_W);
            case 'temperature',         s = sprintf('uniform wall temperature %.2f degC', C(caseData.evaporatorTemperature_K));
            case 'temperatureFunction', s = sprintf('wall temperature T(z) = %s degC', caseData.evaporatorTemperatureFunction);
            case 'convection',          s = sprintf('convection, h = %.1f W/m2K, T_inf = %.2f degC', caseData.evaporatorH_W_m2K, C(caseData.evaporatorTinf_K));
            case 'heatFluxFunction',    s = sprintf('heat flux q(z) = %s W/m2 (into the pipe)', caseData.evaporatorHeatFluxFunction);
            otherwise,                  s = caseData.evaporatorBCType;
        end
    case 'transport'
        switch normalizeOuterBCType(caseData.transportBCType)
            case 'adiabatic',  s = 'adiabatic';
            case 'convection', s = sprintf('convection, h = %.1f W/m2K, T_inf = %.2f degC', caseData.transportH_W_m2K, C(caseData.transportTinf_K));
            otherwise,         s = caseData.transportBCType;
        end
    case 'condenser'
        switch normalizeOuterBCType(caseData.condenserBCType)
            case 'paperEq20UniformHeatFlux', s = 'removes the evaporator input as uniform heat flux (paper Eq. 20)';
            case 'power'
                if isfinite(caseData.totalHeatOutput_W)
                    s = sprintf('removed power %.2f W (uniform heat flux)', caseData.totalHeatOutput_W);
                else
                    s = 'removed power = evaporator input (uniform heat flux)';
                end
            case 'heatFlux',            s = sprintf('uniform removal flux %.1f W/m2', caseData.condenserHeatFlux_W_m2);
            case 'temperature',         s = sprintf('uniform wall temperature %.2f degC', C(caseData.condenserWallTemperature_K));
            case 'temperatureFunction', s = sprintf('wall temperature T(z) = %s degC', caseData.condenserTemperatureFunction);
            case 'convection',          s = sprintf('convection, h = %.1f W/m2K, T_inf = %.2f degC', caseData.condenserH_W_m2K, C(caseData.condenserTinf_K));
            case 'heatFluxFunction',    s = sprintf('removal flux q(z) = %s W/m2', caseData.condenserHeatFluxFunction);
            otherwise,                  s = caseData.condenserBCType;
        end
    otherwise
        error('describeZoneBC: unknown zone "%s".', zone);
end
end
