function printCleanConfiguration(caseData,mat,num,mesh)
%PRINTCLEANCONFIGURATION Start-up summary.
fprintf('\n%s\n', caseData.name);
fprintf('  Model                : Faghri & Buchko (1991) conjugate model (%s, %s scheme)\n', num.pressureVelocityCoupling, num.convectionScheme);
fprintf('  Radii a/b/c          : %.3f / %.3f / %.3f mm (wick %.3f mm, %s), L_T = %.3f m\n', 1e3*caseData.R_vapor, ...
    1e3*caseData.R_wick, 1e3*caseData.R_outer, 1e3*(caseData.R_wick - caseData.R_vapor), caseData.wickThicknessSource, caseData.L_total);
fprintf('  Evaporator           : [%.4f %.4f] m, %s\n', caseData.heaterSegments_m(1,:), describeZoneBC(caseData,'evaporator'));
fprintf('  Transport            : [%.4f %.4f] m, %s\n', caseData.transportStart, caseData.transportEnd, describeZoneBC(caseData,'transport'));
fprintf('  Condenser            : [%.3f %.3f] m, %s\n', caseData.condenserStart, caseData.condenserEnd, describeZoneBC(caseData,'condenser'));
if isFluxOnlyBC(caseData)
    fprintf('  Operating anchor     : T_o = %.2f degC (%s), reference %s\n', caseData.T_o_K-273.15, caseData.T_o_source, caseData.pressureReference);
else
    fprintf('  Operating temperature: solved for (start value %.2f degC)\n', caseData.T_o_K-273.15);
end
fprintf('  Wick                 : eps %.4f, K %.3e m2, r_c %.3e m, k_eff %.4f W/mK\n', mat.wick.porosity, mat.wick.permeability_m2, mat.wick.capillaryRadius_m, mat.wick.k_eff);
if isfield(mat,'fluidPropertiesFollowT_o') && mat.fluidPropertiesFollowT_o
    fprintf('  Fluid properties     : water at T_o (%.2f degC now; follow T_o when it is solved for)\n', mat.T_eval_K-273.15);
else
    fprintf('  Fluid properties     : fixed, user-defined (evaluated at %.2f degC)\n', mat.T_eval_K-273.15);
end
fprintf('  Wall                 : %s, k = %.1f W/mK\n', mat.wall.name, mat.wall.k);
fprintf('  Grid                 : %s, %d axial x (%d + %d + %d)\n\n', mesh.gridPreset, mesh.Nz, mesh.Nv, mesh.Nw, mesh.Ns);
end
