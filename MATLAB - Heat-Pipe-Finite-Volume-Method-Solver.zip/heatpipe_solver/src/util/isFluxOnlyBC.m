function tf = isFluxOnlyBC(caseData)
%ISFLUXONLYBC True if every outer-wall zone has a prescribed heat flux.
%   Then the temperature level is set by the operating temperature T_o
%   (Eq. 19 anchor); otherwise T_o is solved for.
e = normalizeOuterBCType(caseData.evaporatorBCType);
c = normalizeOuterBCType(caseData.condenserBCType);
t = normalizeOuterBCType(caseData.transportBCType);
tf = any(strcmp(e, {'power','heatFluxFunction'})) && ...
     any(strcmp(c, {'paperEq20UniformHeatFlux','power','heatFlux','heatFluxFunction'})) && ...
     strcmp(t, 'adiabatic');
end
