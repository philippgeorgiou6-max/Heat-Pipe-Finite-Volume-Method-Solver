function tf = isOctave()
%ISOCTAVE True when running under GNU Octave.
tf = exist('OCTAVE_VERSION','builtin') ~= 0;
end
