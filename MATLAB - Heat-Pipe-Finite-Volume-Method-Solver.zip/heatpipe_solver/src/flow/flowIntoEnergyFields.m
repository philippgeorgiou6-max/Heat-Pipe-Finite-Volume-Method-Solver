function fields = flowIntoEnergyFields(fields,mesh,vapor,wick)
%FLOWINTOENERGYFIELDS Pass the flow solution to the energy equation.
%
% Global face mass flows (continuity flows rho*eps*V*A, superficial in the
% wick) and the vapor pressure-work + viscous-dissipation sources of paper
% Eq. (4). The interface face r = a is taken from the vapor side; the wick
% side carries the same mass flow (interface mass continuity).
mv = computeSubdomainMassFlows(vapor);
mw = computeSubdomainMassFlows(wick);
Fr = zeros(mesh.Nr+1,mesh.Nz);
Fz = zeros(mesh.Nr,mesh.Nz+1);
rv = mesh.rowsVapor; rw = mesh.rowsWick;
Fr(rv(1):rv(end)+1,:) = mv.Fr;
Fr(rw(1)+1:rw(end)+1,:) = mw.Fr(2:end,:);
Fz(rv,:) = mv.Fz;
Fz(rw,:) = mw.Fz;
fields.Fr = Fr; fields.Fz = Fz;
Sc = zeros(mesh.Nr,mesh.Nz);
Sc(rv,:) = computeVaporEnergySources(vapor);
fields.Sc = Sc;
fields.pAbs = [];
end
