function [vapor,wick] = applyVelocityBCs(vapor,wick,mdot,A_interface)
%APPLYVELOCITYBCS Interface blowing/suction from the phase-change mass flux.
%
% Paper Eq. (16) gives v(z,a) = -m''/rho_v on the vapor side, with rho_v the
% vapor density at r = a (vapor.rhoInterface, ideal gas at p_v(z,a) and
% T_i(z)); the same density is used for the interface face mass flux, so the
% mass flux through r = a is exactly -m''. Mass continuity across the
% interface gives rho_l*eps*v_l(z,a) = -m'' on the liquid side (v_l
% intrinsic). m'' > 0 (evaporation) means flow toward the axis.
% Axis, wick-wall face and end caps keep v = 0 and w = 0 (Eqs. 11-15, 17).
mpp = mdot./A_interface;
if isfield(vapor,'rhoInterface') && ~isempty(vapor.rhoInterface)
    rhoI = vapor.rhoInterface;
else
    rhoI = vapor.rho(end,:);
end
vapor.vOuter = -mpp./rhoI;
vapor.vInner = zeros(1,vapor.nz);
vapor.v(1,:) = 0;  vapor.v(end,:) = vapor.vOuter;
wick.vInner = -mpp./(wick.rho(1,:)*wick.porosity);
wick.vOuter = zeros(1,wick.nz);
wick.v(1,:) = wick.vInner;  wick.v(end,:) = 0;
vapor.w(:,1) = 0; vapor.w(:,end) = 0;
wick.w(:,1) = 0;  wick.w(:,end) = 0;
end
