function p = vaporInterfacePressure(vapor)
%VAPORINTERFACEPRESSURE Gauge vapor pressure p_v(z,a) at the interface (1 x Nz).
%
% Linear extrapolation from the two vapor cell centres next to r = a to the
% interface itself, so paper Eq. (19) receives the pressure at r = a. Also
% used for the pressure anchoring, the liquid wet-point reference and the
% capillary diagnostic.
nr = vapor.nr;
if nr < 2
    p = vapor.p(end,:);
    return;
end
a = vapor.rf(end); r1 = vapor.rc(end); r2 = vapor.rc(end-1);
p = vapor.p(end,:) + (vapor.p(end,:) - vapor.p(end-1,:))*(a - r1)/(r1 - r2);
end
