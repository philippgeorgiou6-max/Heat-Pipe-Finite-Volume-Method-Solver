function [sub,res] = simpleIteration(sub,num,alphaU,massScale)
%SIMPLEITERATION One SIMPLE / SIMPLEC iteration on a staggered sub-domain.
%
% 1. momentum-convecting face mass flows from the current velocities
% 2. axial momentum (w*) and radial momentum (v*) with the current pressure
% 3. pressure correction, velocity and pressure update
% res.mass   : sum|cell mass imbalance| before the correction / massScale
% res.momW/V : sum|momentum residual| / sum|a_P u| before the solve
nr = sub.nr; nz = sub.nz;
scheme = num.convectionScheme;
mf = computeSubdomainMassFlows(sub);
div = [];
if sub.compressibleViscous
    div = cellDivergence(sub);
end
simplec = ~strcmpi(num.pressureVelocityCoupling,'SIMPLE');

[A,b,cw] = assembleStaggeredMomentumW(sub,mf,div,alphaU,scheme);
sub.w(:,2:nz) = reshape(A\b, nr, nz-1);
if simplec
    sub.dW(:,2:nz) = cw.area./(cw.aP - cw.sumNb);
else
    sub.dW(:,2:nz) = cw.area./cw.aP;
end

[A,b,cv] = assembleStaggeredMomentumV(sub,mf,div,alphaU,scheme);
if nr > 1
    sub.v(2:nr,:) = reshape(A\b, nr-1, nz);
    if simplec
        sub.dV(2:nr,:) = cv.area./(cv.aP - cv.sumNb);
    else
        sub.dV(2:nr,:) = cv.area./cv.aP;
    end
end

[sub,massAbs] = solvePressureCorrection(sub,num.alpha_p);
res.mass = massAbs/max(massScale, realmin);
res.massAbs = massAbs;
res.momW = cw.residualAbs/max(cw.residualNorm, realmin);
res.momV = cv.residualAbs/max(cv.residualNorm, realmin);
end
