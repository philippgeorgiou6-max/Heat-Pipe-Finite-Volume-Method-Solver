function Sc = computeVaporEnergySources(sub)
%COMPUTEVAPORENERGYSOURCES Pressure work and viscous dissipation, paper Eq. (4).
%   S = (w dp/dz + v dp/dr + mu*Phi) * vol            [W per cell]
%   Phi = 2[(dv/dr)^2 + (v/r)^2 + (dw/dz)^2 + 1/2 (dv/dz + dw/dr)^2 - 1/3 (div V)^2]
%
% dv/dr, dw/dz and div V are exact cell-centred differences of face values.
% The remaining derivatives use three-point formulas that are second order on
% non-uniform grids. At the boundaries they use the paper's boundary
% conditions where one applies:
%   axis r = 0      : symmetry, dw/dr = dp/dr = 0 (Eq. 15)
%   interface r = a : no slip, w = 0 (Eq. 13)
%   end caps        : no slip, v = 0 at z = 0 and z = L_T (Eqs. 11, 12)
% and a one-sided three-point formula otherwise (pressure at r = a and at the
% end caps).
nr = sub.nr; nz = sub.nz;
w = sub.w; v = sub.v; p = sub.p;
wc = 0.5*(w(:,1:nz) + w(:,2:nz+1));
vc = 0.5*(v(1:nr,:) + v(2:nr+1,:));
rc = sub.rc(:)'; zc = sub.zc(:)';
axisInner = isfield(sub,'innerBC') && strcmpi(sub.innerBC,'axis');
noSlipOuter = isfield(sub,'outerBC') && strcmpi(sub.outerBC,'interface');
rLo = sub.rf(1); rHi = sub.rf(end); zLo = sub.zf(1); zHi = sub.zf(end);
if axisInner, rLoType = 'symmetry'; else, rLoType = 'none'; end
if noSlipOuter, wHiType = 'zero'; else, wHiType = 'none'; end

dpdz = derivative1(p, zc, 2, 'none', zLo, 'none', zHi);
dpdr = derivative1(p, rc, 1, rLoType, rLo, 'none', rHi);
dvdr = (v(2:nr+1,:) - v(1:nr,:))./repmat(sub.dr(:),1,nz);
vr = vc./repmat(rc(:),1,nz);
dwdz = (w(:,2:nz+1) - w(:,1:nz))./repmat(sub.dz,nr,1);
dwdr = derivative1(wc, rc, 1, rLoType, rLo, wHiType, rHi);
dvdz = derivative1(vc, zc, 2, 'zero', zLo, 'zero', zHi);
div = cellDivergence(sub);
Phi = 2*(dvdr.^2 + vr.^2 + dwdz.^2) + (dvdz + dwdr).^2 - (2/3)*div.^2;
Sc = (wc.*dpdz + vc.*dpdr + sub.mu*Phi).*sub.vol;
end

% ========================================================================
function g = derivative1(f, x, dim, loType, xLo, hiType, xHi)
% First derivative of a cell-centred field along dimension dim (1 = r, 2 = z).
% Interior: three-point Lagrange formula (second order on non-uniform grids).
% Ends: 'none' one-sided three-point; 'zero' quadratic through the boundary
% value 0 at xLo/xHi; 'symmetry' even function about x = xLo (axis).
x = x(:)'; n = numel(x);
if dim == 1, f = f.'; end
g = zeros(size(f));
if n >= 3
    h1 = x(2:n-1) - x(1:n-2); h2 = x(3:n) - x(2:n-1);
    g(:,2:n-1) = -f(:,1:n-2).*(h2./(h1.*(h1 + h2))) + f(:,2:n-1).*((h2 - h1)./(h1.*h2)) + ...
                  f(:,3:n).*(h1./(h2.*(h1 + h2)));
    g(:,1) = endDerivative(f(:,1), f(:,2), f(:,3), x(1), x(2), x(3), loType, xLo);
    g(:,n) = endDerivative(f(:,n), f(:,n-1), f(:,n-2), x(n), x(n-1), x(n-2), hiType, xHi);
elseif n == 2
    g(:,1) = (f(:,2) - f(:,1))/(x(2) - x(1));
    g(:,2) = g(:,1);
end
if dim == 1, g = g.'; end
end

function d = endDerivative(f0, f1, f2, x0, x1, x2, type, xb)
% derivative at the end centre x0; x1, x2 are the next centres inward
switch type
    case 'zero'        % quadratic through (xb,0), (x0,f0), (x1,f1)
        d = f0*(2*x0 - xb - x1)/((x0 - xb)*(x0 - x1)) + f1*(x0 - xb)/((x1 - xb)*(x1 - x0));
    case 'symmetry'    % f = c0 + c2 (x - xb)^2 through (x0,f0), (x1,f1)
        s0 = x0 - xb; s1 = x1 - xb;
        d = 2*s0*(f1 - f0)/(s1^2 - s0^2);
    otherwise          % one-sided quadratic through (x0,f0), (x1,f1), (x2,f2)
        d = f0*(2*x0 - x1 - x2)/((x0 - x1)*(x0 - x2)) + f1*(x0 - x2)/((x1 - x0)*(x1 - x2)) + ...
            f2*(x0 - x1)/((x2 - x0)*(x2 - x1));
end
end
