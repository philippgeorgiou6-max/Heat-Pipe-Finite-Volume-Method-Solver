function [A,b,co] = assembleStaggeredMomentumW(sub,mf,div,alpha,scheme)
%ASSEMBLESTAGGEREDMOMENTUMW Axial momentum on staggered w control volumes.
%
% Unknowns: w(i,J), i = 1..nr, J = 2..nz (interior axial faces); w = 0 on the
% end caps J = 1, nz+1 (Eqs. 11, 12). Radial boundaries: no slip w = 0 at the
% interface r = a and at r = b (Eqs. 13, 14); symmetry at the axis (Eq. 15,
% zero face area).
%
% Vapor (paper Eq. 2, compressible, constant mu):
%   div(rho V w) = -dp/dz + mu*lap(w) + (1/3) mu d(div V)/dz
% Wick (paper Eq. 5, intrinsic velocity):
%   div(rho_l V w) = -dp/dz + mu*lap(w) - (mu eps/K) w
% Patankar coefficients with the hybrid / power-law A(|P|) function; the
% continuity residual is dropped from a_P (standard SIMPLE practice).

nr = sub.nr; nz = sub.nz; mu = sub.mu;
nu = nz - 1;                                  % number of interior faces per row
if nu < 1, error('assembleStaggeredMomentumW: need at least 2 axial cells.'); end
J = 2:nz;
dzE = sub.dz(J); dzW = sub.dz(J-1);
dzw = 0.5*(dzE + dzW);
Aew = sub.Az;                                 % nr x 1
An = 2*pi*sub.rf(2:nr+1)'*dzw;                % nr x nu
As = 2*pi*sub.rf(1:nr)'*dzw;
distN = [sub.rc(2:nr) - sub.rc(1:nr-1), sub.rf(nr+1) - sub.rc(nr)]';
distS = [sub.rc(1) - sub.rf(1), sub.rc(2:nr) - sub.rc(1:nr-1)]';
vol = Aew*dzw;

De = mu*Aew./dzE;  Dw = mu*Aew./dzW;          % nr x nu (implicit expansion)
Dn = mu*An./distN; Ds = mu*As./distS;
Fe = 0.5*(mf.FzM(:,J) + mf.FzM(:,J+1));
Fw = 0.5*(mf.FzM(:,J-1) + mf.FzM(:,J));
Fn = 0.5*(mf.FrM(2:nr+1,J-1) + mf.FrM(2:nr+1,J));
Fs = 0.5*(mf.FrM(1:nr,J-1) + mf.FrM(1:nr,J));
aE = De.*schemeA(Fe,De,scheme) + max(-Fe,0);
aW = Dw.*schemeA(Fw,Dw,scheme) + max( Fw,0);
aN = Dn.*schemeA(Fn,Dn,scheme) + max(-Fn,0);
aS = Ds.*schemeA(Fs,Ds,scheme) + max( Fs,0);
if strcmp(sub.innerBC,'axis')
    aS(1,:) = 0;                              % symmetry, zero area
end
aP0 = aE + aW + aN + aS + sub.darcy*vol;

pW = sub.p(:,J-1); pE = sub.p(:,J);
b0 = (pW - pE).*repmat(Aew,1,nu);
if sub.compressibleViscous && ~isempty(div)
    b0 = b0 + (mu/3)*(div(:,J) - div(:,J-1)).*repmat(Aew,1,nu);
end

wOld = sub.w(:,J);
% neighbour values (boundary w = 0)
wE = sub.w(:,J+1); wW = sub.w(:,J-1);
wN = [sub.w(2:nr,J); zeros(1,nu)];
wS = [zeros(1,nu); sub.w(1:nr-1,J)];
r = aP0.*wOld - (aE.*wE + aW.*wW + aN.*wN + aS.*wS) - b0;
co.residualAbs = sum(abs(r(:)));
co.residualNorm = max([sum(abs(aP0(:).*wOld(:))), co.residualAbs, realmin]);  % residual <= 1 for a field at rest

aP = aP0/alpha;
b = b0 + (1-alpha)*aP.*wOld;

idx = reshape(1:nr*nu, nr, nu);
I = {idx(:)}; Jx = {idx(:)}; V = {aP(:)};
if nu > 1
    P = idx(:,1:nu-1); Q = idx(:,2:nu);
    I{end+1} = P(:); Jx{end+1} = Q(:); V{end+1} = -reshape(aE(:,1:nu-1),[],1);
    I{end+1} = Q(:); Jx{end+1} = P(:); V{end+1} = -reshape(aW(:,2:nu),[],1);
end
if nr > 1
    P = idx(1:nr-1,:); Q = idx(2:nr,:);
    I{end+1} = P(:); Jx{end+1} = Q(:); V{end+1} = -reshape(aN(1:nr-1,:),[],1);
    I{end+1} = Q(:); Jx{end+1} = P(:); V{end+1} = -reshape(aS(2:nr,:),[],1);
end
A = sparse(vertcat(I{:}), vertcat(Jx{:}), vertcat(V{:}), nr*nu, nr*nu);
b = b(:);
co.aP = aP; co.sumNb = aE + aW + aN + aS;
co.area = repmat(Aew,1,nu);
end

function As = schemeA(C,D,scheme)
As = zeros(size(C));
pos = D > 0;
Pe = abs(C(pos))./D(pos);
switch lower(scheme)
    case 'hybrid',   As(pos) = max(0, 1 - 0.5*Pe);
    case 'powerlaw', As(pos) = max(0, 1 - 0.1*Pe).^5;
    case 'upwind',   As(pos) = 1;
    otherwise, error('Unknown convection scheme "%s".', scheme);
end
end
