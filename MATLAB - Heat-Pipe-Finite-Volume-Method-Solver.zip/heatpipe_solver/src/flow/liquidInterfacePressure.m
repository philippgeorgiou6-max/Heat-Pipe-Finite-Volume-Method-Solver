function p = liquidInterfacePressure(wick)
%LIQUIDINTERFACEPRESSURE Gauge liquid pressure p_l(z,a) at the interface (1 x Nz).
%
% Linear extrapolation from the two wick cell centres next to r = a to the
% interface itself. Used for the liquid wet-point reference and the
% capillary diagnostic p_v(z,a) - p_l(z,a).
nr = wick.nr;
if nr < 2
    p = wick.p(1,:);
    return;
end
a = wick.rf(1); r1 = wick.rc(1); r2 = wick.rc(2);
p = wick.p(1,:) - (wick.p(2,:) - wick.p(1,:))*(r1 - a)/(r2 - r1);
end
