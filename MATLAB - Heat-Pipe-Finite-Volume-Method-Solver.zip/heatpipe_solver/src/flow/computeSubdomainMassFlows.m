function mf = computeSubdomainMassFlows(sub)
%COMPUTESUBDOMAINMASSFLOWS Face mass flows of a staggered sub-domain.
%
% FzM, FrM : momentum-convecting mass flows rho*V*A (intrinsic V); the paper's
%            wick momentum Eqs. (5)-(6) convect with rho_l*V (no porosity).
% Fz,  Fr  : continuity / energy mass flows rho*eps*V*A (eps = 1 in the vapor).
% Boundary faces use the density of the adjacent cell.
nr = sub.nr; nz = sub.nz;
rhoZ = zeros(nr,nz+1);
rhoZ(:,2:nz) = 0.5*(sub.rho(:,1:nz-1) + sub.rho(:,2:nz));
rhoZ(:,1) = sub.rho(:,1); rhoZ(:,nz+1) = sub.rho(:,nz);
rhoR = zeros(nr+1,nz);
if nr > 1
    rhoR(2:nr,:) = 0.5*(sub.rho(1:nr-1,:) + sub.rho(2:nr,:));
end
rhoR(1,:) = sub.rho(1,:); rhoR(nr+1,:) = sub.rho(nr,:);
if isfield(sub,'rhoInterface') && ~isempty(sub.rhoInterface) && isfield(sub,'outerBC') && strcmp(sub.outerBC,'interface')
    rhoR(nr+1,:) = sub.rhoInterface;     % vapor at r = a: rho_v(z,a) = p_v(z,a)/(R T_i)
end
mf.rhoZ = rhoZ; mf.rhoR = rhoR;
mf.FzM = rhoZ.*sub.w.*repmat(sub.Az,1,nz+1);
mf.FrM = rhoR.*sub.v.*sub.Ar;
mf.Fz = sub.porosity*mf.FzM;
mf.Fr = sub.porosity*mf.FrM;
% half-row axial mass flows used by the radial-momentum control volumes
upperA = pi*(sub.rf(2:end).^2 - sub.rc.^2)';
lowerA = pi*(sub.rc.^2 - sub.rf(1:end-1).^2)';
mf.FzUpper = rhoZ.*sub.w.*repmat(upperA,1,nz+1);
mf.FzLower = rhoZ.*sub.w.*repmat(lowerA,1,nz+1);
end
