function [sub,massAbs] = solvePressureCorrection(sub,alphaP)
%SOLVEPRESSURECORRECTION SIMPLE/SIMPLEC pressure correction for one sub-domain.
%
% Continuity, paper Eq. (1) (vapor) and Eq. (26) / div(rho_l eps V) = 0 (wick):
%   sum_faces eps*rho*V.n*A = 0 in every cell.
% p' equation: sum_nb c_nb (p'_P - p'_nb) = -(mass imbalance), with
% c = eps*rho_face*d*A. Prescribed-velocity boundaries (axis, interface,
% walls, end caps) do not couple. The domain is closed, so p' is fixed in one
% reference cell. Velocities are corrected with d*(p'_P - p'_nb) and the
% pressure with alphaP*p'.
% massAbs = sum |cell mass imbalance| before the correction [kg/s].

nr = sub.nr; nz = sub.nz; ep = sub.porosity;
mf = computeSubdomainMassFlows(sub);
net = (mf.Fz(:,2:nz+1) - mf.Fz(:,1:nz)) + (mf.Fr(2:nr+1,:) - mf.Fr(1:nr,:));
massAbs = sum(abs(net(:)));
bP = -net;

idx = reshape(1:nr*nz, nr, nz);
aP = zeros(nr,nz);
I = {}; J = {}; V = {};
if nz > 1
    cZ = ep*mf.rhoZ(:,2:nz).*sub.dW(:,2:nz).*repmat(sub.Az,1,nz-1);   % faces between j and j+1
    aP(:,1:nz-1) = aP(:,1:nz-1) + cZ;
    aP(:,2:nz)   = aP(:,2:nz)   + cZ;
    P = idx(:,1:nz-1); Q = idx(:,2:nz);
    I{end+1} = P(:); J{end+1} = Q(:); V{end+1} = -cZ(:);
    I{end+1} = Q(:); J{end+1} = P(:); V{end+1} = -cZ(:);
end
if nr > 1
    cR = ep*mf.rhoR(2:nr,:).*sub.dV(2:nr,:).*sub.Ar(2:nr,:);          % faces between i and i+1
    aP(1:nr-1,:) = aP(1:nr-1,:) + cR;
    aP(2:nr,:)   = aP(2:nr,:)   + cR;
    P = idx(1:nr-1,:); Q = idx(2:nr,:);
    I{end+1} = P(:); J{end+1} = Q(:); V{end+1} = -cR(:);
    I{end+1} = Q(:); J{end+1} = P(:); V{end+1} = -cR(:);
end
A = sparse([idx(:); vertcat(I{:})], [idx(:); vertcat(J{:})], [aP(:); vertcat(V{:})], nr*nz, nr*nz);
b = bP(:);
ref = idx(sub.pRefCell(1), sub.pRefCell(2));
A(ref,:) = 0; A(ref,ref) = 1; b(ref) = 0;
pc = reshape(A\b, nr, nz);

if nz > 1
    sub.w(:,2:nz) = sub.w(:,2:nz) + sub.dW(:,2:nz).*(pc(:,1:nz-1) - pc(:,2:nz));
end
if nr > 1
    sub.v(2:nr,:) = sub.v(2:nr,:) + sub.dV(2:nr,:).*(pc(1:nr-1,:) - pc(2:nr,:));
end
sub.p = sub.p + alphaP*pc;
end
