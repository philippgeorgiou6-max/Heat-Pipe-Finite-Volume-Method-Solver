function [A,b,co] = assembleStaggeredMomentumV(sub,mf,div,alpha,scheme)
%ASSEMBLESTAGGEREDMOMENTUMV Radial momentum on staggered v control volumes.
%
% Unknowns: v(I,j), I = 2..nr (interior radial faces), j = 1..nz. Boundary
% faces carry prescribed v: axis v = 0 (Eq. 15), interface v from Eq. (16),
% wick-wall face v = 0 (Eq. 17). End caps: no slip v = 0 (Eqs. 11, 12).
%
% Vapor (paper Eq. 3): div(rho V v) = -dp/dr + mu*(lap(v) - v/r^2) + (1/3) mu d(div V)/dr
% Wick  (paper Eq. 6 in the axisymmetric form of the vector Eq. 25; the -v/r^2
%        term missing from the printed Eq. 6 can be dropped with sub.includeVr2 = false):
%                      div(rho_l V v) = -dp/dr + mu*(lap(v) - v/r^2) - (mu eps/K) v

nr = sub.nr; nz = sub.nz; mu = sub.mu;
nu = nr - 1;
if nu < 1
    A = sparse(0,0); b = zeros(0,1);
    co.aP = zeros(0,nz); co.sumNb = zeros(0,nz); co.area = zeros(0,nz);
    co.residualAbs = 0; co.residualNorm = 0;
    return;
end
I = 2:nr;
rcS = sub.rc(I-1)'; rcN = sub.rc(I)'; rfI = sub.rf(I)';
Aew = pi*(rcN.^2 - rcS.^2);                    % nu x 1
An = 2*pi*rcN*sub.dz;  As = 2*pi*rcS*sub.dz;   % nu x nz
distN = sub.dr(I)'; distS = sub.dr(I-1)';
zc = sub.zc; zf = sub.zf;
distE = [zc(2:nz) - zc(1:nz-1), zf(nz+1) - zc(nz)];
distW = [zc(1) - zf(1), zc(2:nz) - zc(1:nz-1)];
vol = Aew*sub.dz;
% Pressure-gradient coefficient of the control volume [r_cS, r_cN]:
% -dp/dr * vol with dp/dr = (p_N - p_S)/(r_cN - r_cS), i.e. vol/(r_cN - r_cS)
% = pi*(r_cN + r_cS)*dz. It equals the face area 2*pi*r_f*dz on a uniform
% grid and keeps the pressure term consistent with the Darcy and v/r^2 terms
% (which use vol) on the cosine-spaced wick grid.
Ap = vol./(rcN - rcS);

Dn = mu*An./distN; Ds = mu*As./distS;
De = mu*Aew./distE; Dw = mu*Aew./distW;
Fn = 0.5*(mf.FrM(I,:) + mf.FrM(I+1,:));
Fs = 0.5*(mf.FrM(I-1,:) + mf.FrM(I,:));
Fe = mf.FzUpper(I-1,2:nz+1) + mf.FzLower(I,2:nz+1);
Fw = mf.FzUpper(I-1,1:nz)   + mf.FzLower(I,1:nz);
aN = Dn.*schemeA(Fn,Dn,scheme) + max(-Fn,0);
aS = Ds.*schemeA(Fs,Ds,scheme) + max( Fs,0);
aE = De.*schemeA(Fe,De,scheme) + max(-Fe,0);
aW = Dw.*schemeA(Fw,Dw,scheme) + max( Fw,0);
vr2 = mu*vol./rfI.^2;                          % -mu*v/r^2 (implicit)
if isfield(sub,'includeVr2') && ~sub.includeVr2
    vr2 = 0*vr2;                               % literal printed Eq. (6)
end
aP0 = aN + aS + aE + aW + vr2 + sub.darcy*vol;

b0 = (sub.p(I-1,:) - sub.p(I,:)).*Ap;
if sub.compressibleViscous && ~isempty(div)
    b0 = b0 + (mu/3)*(div(I,:) - div(I-1,:)).*Ap;
end
% prescribed boundary-face velocities enter through the neighbour coefficients
bBound = zeros(nu,nz);
bBound(end,:) = bBound(end,:) + aN(end,:).*sub.v(nr+1,:);
bBound(1,:)   = bBound(1,:)   + aS(1,:).*sub.v(1,:);

vOld = sub.v(I,:);
vN = sub.v(I+1,:); vS = sub.v(I-1,:);         % includes boundary faces
vE = [sub.v(I,2:nz), zeros(nu,1)];
vW = [zeros(nu,1), sub.v(I,1:nz-1)];
r = aP0.*vOld - (aN.*vN + aS.*vS + aE.*vE + aW.*vW) - b0;
co.residualAbs = sum(abs(r(:)));
co.residualNorm = max([sum(abs(aP0(:).*vOld(:))), co.residualAbs, realmin]);  % residual <= 1 for a field at rest

aP = aP0/alpha;
b = b0 + bBound + (1-alpha)*aP.*vOld;

idx = reshape(1:nu*nz, nu, nz);
Ii = {idx(:)}; Jj = {idx(:)}; V = {aP(:)};
if nu > 1
    P = idx(1:nu-1,:); Q = idx(2:nu,:);
    Ii{end+1} = P(:); Jj{end+1} = Q(:); V{end+1} = -reshape(aN(1:nu-1,:),[],1);
    Ii{end+1} = Q(:); Jj{end+1} = P(:); V{end+1} = -reshape(aS(2:nu,:),[],1);
end
if nz > 1
    P = idx(:,1:nz-1); Q = idx(:,2:nz);
    Ii{end+1} = P(:); Jj{end+1} = Q(:); V{end+1} = -reshape(aE(:,1:nz-1),[],1);
    Ii{end+1} = Q(:); Jj{end+1} = P(:); V{end+1} = -reshape(aW(:,2:nz),[],1);
end
A = sparse(vertcat(Ii{:}), vertcat(Jj{:}), vertcat(V{:}), nu*nz, nu*nz);
b = b(:);
co.aP = aP; co.sumNb = aN + aS + aE + aW;
co.area = Ap;     % pressure coefficient, used for the SIMPLE(C) d-coefficients
end

function As = schemeA(C,D,scheme)
As = zeros(size(C));
pos = D > 0;
Pe = abs(C(pos))./D(pos);
switch lower(scheme)
    case 'hybrid',   As(pos) = max(0, 1 - 0.5*Pe);
    case 'powerlaw', As(pos) = max(0, 1 - 0.1*Pe).^5;
    case 'upwind',   As(pos) = 1;
    otherwise, error('Unknown convection scheme "%s".', scheme);
end
end
