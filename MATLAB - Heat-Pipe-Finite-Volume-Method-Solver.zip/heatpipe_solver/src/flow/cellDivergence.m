function div = cellDivergence(sub)
%CELLDIVERGENCE Finite-volume div(V) in each scalar cell of a sub-domain.
%   div = [ 2*pi*dz*(r_n v_n - r_s v_s) + Az*(w_e - w_w) ] / vol
nr = sub.nr; nz = sub.nz;
fluxR = repmat(sub.rf(:),1,nz).*sub.v;                       % r*v on radial faces
div = (2*pi*repmat(sub.dz,nr,1).*(fluxR(2:nr+1,:) - fluxR(1:nr,:)) + ...
       repmat(sub.Az,1,nz).*(sub.w(:,2:nz+1) - sub.w(:,1:nz))) ./ sub.vol;
end
