function sub = buildFlowSubdomain(mesh,caseData,mat,which)
%BUILDFLOWSUBDOMAIN Staggered-grid sub-domain for the vapor core or the wick.
%
% Scalar cells (p, rho) coincide with the global mesh cells of the region.
% Axial velocity w lives on axial faces (nr x (nz+1)), radial velocity v on
% radial faces ((nr+1) x nz). Boundary conditions (paper Eqs. 11-17):
%   both : w = v = 0 at z = 0 and z = L_T                (Eqs. 11, 12)
%   vapor: axis r = 0 -> v = 0, dw/dr = 0                 (Eq. 15)
%          r = a      -> w = 0 (no slip), v = v_v(z,a)    (Eqs. 13, 16)
%   wick : r = a      -> w = 0, rho_l*eps*v_l = -m''      (Eqs. 13, 16)
%          r = b      -> w = 0, v = 0                     (Eqs. 14, 17)

switch lower(which)
    case 'vapor'
        rows = mesh.rowsVapor;
        sub.name = 'vapor';
        sub.innerBC = 'axis'; sub.outerBC = 'interface';
        sub.mu = mat.vapor.mu;
        sub.porosity = 1.0;
        sub.darcy = 0.0;                    % no porous drag
        sub.compressibleViscous = true;     % (1/3) mu grad(div V) terms of Eqs. (2)-(3)
        rho0 = mat.vapor.rho_o;
    case 'wick'
        rows = mesh.rowsWick;
        sub.name = 'wick';
        sub.innerBC = 'interface'; sub.outerBC = 'wall';
        sub.mu = mat.liquid.mu;
        sub.porosity = mat.wick.porosity;
        sub.darcy = mat.wick.darcyCoefficient;   % mu*eps/K, Eqs. (5)-(6)
        sub.compressibleViscous = false;
        rho0 = mat.liquid.rho;
    otherwise
        error('buildFlowSubdomain: unknown sub-domain "%s".', which);
end
sub.rows = rows;
sub.nr = numel(rows); sub.nz = mesh.Nz;
sub.rf = mesh.r_nodes(rows(1):rows(end)+1);
sub.rc = mesh.r_centers(rows);
sub.dr = mesh.dr(rows);
sub.zf = mesh.z_nodes; sub.zc = mesh.z_centers; sub.dz = mesh.dz;
sub.Az = pi*(sub.rf(2:end).^2 - sub.rf(1:end-1).^2)';   % nr x 1
sub.vol = sub.Az*sub.dz;
sub.Ar = 2*pi*sub.rf(:)*sub.dz;                           % (nr+1) x nz
sub.rho = rho0*ones(sub.nr,sub.nz);
% Vapor density at the interface face r = a, rho_v(z,a) = p_v(z,a)/(R T_i(z))
% (set by the coupled solver). It is used both for the interface velocity
% v(z,a) = -m''/rho_v(z,a) and for the face mass flux, so the mass flux
% through r = a is exactly -m''. Empty -> density of the adjacent cell.
sub.rhoInterface = [];
% Radial viscous term: mu*(lap(v) - v/r^2), the radial component of the vector
% Laplacian (vapor Eq. 3 and wick Eq. 25). The printed wick Eq. (6) omits
% -v/r^2; num.wickRadialMomentumForm = 'printed' reproduces it literally.
sub.includeVr2 = true;
sub.w = zeros(sub.nr,sub.nz+1);
sub.v = zeros(sub.nr+1,sub.nz);
sub.p = zeros(sub.nr,sub.nz);       % gauge pressure
sub.vInner = zeros(1,sub.nz);       % prescribed v on the inner radial boundary
sub.vOuter = zeros(1,sub.nz);       % prescribed v on the outer radial boundary
sub.pRefCell = [1 1];               % pressure-correction reference cell
sub.dW = zeros(sub.nr,sub.nz+1);
sub.dV = zeros(sub.nr+1,sub.nz);
end
