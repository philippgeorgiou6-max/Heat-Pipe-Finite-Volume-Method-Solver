function P = computeDerivedProfiles(results)
%COMPUTEDERIVEDPROFILES Axial profiles and summary values for output/validation.
mesh = results.mesh; T = results.fields.T; bc = results.bc; mat = results.mat;
iface = results.iface;
z = mesh.z_centers;
P.z = z;
% outer wall surface temperature at r = c (face value from the boundary condition)
P.T_outerWall_K = outerWallTemperature(mesh, bc, mat, T);
P.T_interface_K = iface.Ti;
P.T_centerline_K = T(1,:);
P.T_wallWick_K = T(mesh.iWickWallRow,:);
P.p_o = iface.p_o;
P.pVapor_Pa  = iface.p_o + results.pVaporGauge;
P.pLiquid_Pa = iface.p_o + results.pLiquidGauge;
P.capillaryDp_Pa = P.pVapor_Pa - P.pLiquid_Pa;
P.mpp = results.mdot.mpp;
mv = computeSubdomainMassFlows(results.vapor);
mw = computeSubdomainMassFlows(results.wick);
P.M_vapor = sum(0.5*(mv.Fz(:,1:end-1) + mv.Fz(:,2:end)),1);
P.M_liquid = sum(0.5*(mw.Fz(:,1:end-1) + mw.Fz(:,2:end)),1);
P.wMaxVapor = max(abs(results.vapor.w(:)));
% cell-centred vapor and wick velocity fields (from the staggered faces)
P.vaporW = 0.5*(results.vapor.w(:,1:end-1) + results.vapor.w(:,2:end));
P.vaporV = 0.5*(results.vapor.v(1:end-1,:) + results.vapor.v(2:end,:));
P.vaporSpeed = sqrt(P.vaporW.^2 + P.vaporV.^2);
P.wickW = 0.5*(results.wick.w(:,1:end-1) + results.wick.w(:,2:end));
P.wickV = 0.5*(results.wick.v(1:end-1,:) + results.wick.v(2:end,:));
% evaporator-centre wall-vapor temperature difference (paper Fig. 3 definition)
seg = results.caseData.heaterSegments_m;
P.heaterCentre_z = mean(seg,2)';
P.dTwallVapor_K = zeros(1,size(seg,1));
for k = 1:size(seg,1)
    P.dTwallVapor_K(k) = interp1(z, P.T_outerWall_K - P.T_centerline_K, P.heaterCentre_z(k), 'linear');
end
[P.peakWall_K, jp] = max(P.T_outerWall_K); P.peakWall_z = z(jp);
P.condenserWallMean_K = mean(P.T_outerWall_K(mesh.isCondenser));
P.transportWallMean_K = mean(P.T_outerWall_K(mesh.zone == 4));
P.vaporMean_K = mean(P.T_centerline_K);
P.vaporRange_K = max(P.T_centerline_K) - min(P.T_centerline_K);
P.vaporDp_Pa = max(P.pVapor_Pa) - min(P.pVapor_Pa);
P.liquidDp_Pa = max(P.pLiquid_Pa) - min(P.pLiquid_Pa);
P.capillaryLimitDp_Pa = 2*mat.liquid.surfaceTension_N_m*cosd(mat.liquid.contactAngle_deg)/mat.wick.capillaryRadius_m;
P.capillaryRatio = max(P.capillaryDp_Pa)/P.capillaryLimitDp_Pa;
P.totalEvaporation = results.mdot.totalEvaporation;
% Thermal resistances R = dT/Q (see computeThermalResistance)
Qev = [];
if isfield(results,'heat') && isfield(results.heat,'Qevap_W'), Qev = results.heat.Qevap_W; end
Rth = computeThermalResistance(mesh, results.caseData, P.T_outerWall_K, P.T_centerline_K, Qev);
P.TwallEvap_K = Rth.TwallEvap_K;   P.TwallCond_K = Rth.TwallCond_K;
P.TvaporEvap_K = Rth.TvaporEvap_K; P.TvaporCond_K = Rth.TvaporCond_K;
P.R_evap_KW = Rth.evap; P.R_vapor_KW = Rth.vapor; P.R_cond_KW = Rth.cond; P.R_total_KW = Rth.total;
P.UmeanMaxVapor = max(abs(P.M_vapor))/(mat.vapor.rho_o*pi*results.caseData.R_vapor^2);
P.Re_axial_max = 2*max(abs(P.M_vapor))/(pi*results.caseData.R_vapor*mat.vapor.mu);
P.Re_radial_max = max(abs(P.mpp))*results.caseData.R_vapor/mat.vapor.mu;
end
