function Tw = outerWallTemperature(mesh, bc, mat, T)
%OUTERWALLTEMPERATURE Outer-wall surface temperature at r = c [K], per axial column.
%   Face value from the last wall cell and the outer boundary condition
%   (imposed heat flux, or Robin/Dirichlet conductance).
drH = bc.drHalfOuter;
qRobin = zeros(1, mesh.Nz);
isR = bc.robinG > 0;
qRobin(isR) = bc.robinG(isR).*(bc.robinT(isR) - T(end,isR))./bc.Aout(isR);
Tw = T(end,:) + (bc.q + qRobin)*drH/mat.wall.k;
end
