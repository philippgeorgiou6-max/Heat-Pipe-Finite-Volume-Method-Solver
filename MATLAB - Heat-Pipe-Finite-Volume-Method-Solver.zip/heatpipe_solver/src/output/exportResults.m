function exportResults(results, folder)
%EXPORTRESULTS Write all results of a run into one folder.
%
%   exportResults(results)          -> ./heatpipe_results
%   exportResults(results, folder)
%
% The previous content of the folder is deleted first, so the folder always
% holds exactly one simulation.
%   *.pdf : geometry, mesh, boundary conditions, every result diagram and the
%           diagnostics overview
%   *.txt : the data of every diagram, summary, geometry, mesh, boundary
%           conditions and materials (tab-separated, '#' header lines)
%   heatpipe_results.mat : the complete results structure
if nargin < 2 || isempty(folder), folder = fullfile(pwd, 'heatpipe_results'); end
clearResultsFolder(folder);
results = stripCallbacks(results);
setupHeadlessGraphics();

writeTextFiles(results, folder);
writePdfFiles(results, folder);
save(fullfile(folder, 'heatpipe_results.mat'), 'results');
end

% ========================================================================
function clearResultsFolder(folder)
if ~exist(folder, 'dir')
    mkdir(folder);
    return;
end
if ~isempty(dir(fullfile(folder, '*.m')))
    error('exportResults: %s contains MATLAB files and is not cleared. Choose a results folder.', folder);
end
d = dir(folder);
for k = 1:numel(d)
    if any(strcmp(d(k).name, {'.', '..'})), continue; end
    p = fullfile(folder, d(k).name);
    if d(k).isdir
        rmdir(p, 's');
    else
        delete(p);
    end
end
end

function results = stripCallbacks(results)
% function handles of the GUI are not stored with the results
for f = {'liveCallback', 'stopRequestFcn'}
    if isfield(results.num, f{1}), results.num = rmfield(results.num, f{1}); end
end
end

% ========================================================================
function writeTextFiles(r, folder)
c = r.caseData; mesh = r.mesh; P = r.profiles; bc = r.bc; mat = r.mat;
mm = 1e3; C = @(T) T - 273.15;
status = finalLabel(r);

writeCleanRunSummary(r, fullfile(folder, 'summary.txt'));

% ---- geometry
names = {'total length', 'unheated start section', 'evaporator', 'transport section', 'condenser', ...
         'unheated end section', 'evaporator start', 'condenser start', 'outer diameter (wall)', ...
         'inner diameter (wall) = wick outer diameter', 'vapor core diameter', 'wall thickness', 'wick thickness'};
vals = mm*[c.L_total, c.L_unheatedStart, c.heaterLength, c.L_transport, c.L_cond, c.L_unheatedEnd, ...
           c.heaterSegments_m(1,1), c.condenserStart, 2*c.R_outer, 2*c.R_wick, 2*c.R_vapor, c.t_wall, c.t_wick];
writeNameValue(fullfile(folder, 'geometry.txt'), 'Geometry [mm]', names, vals, repmat({'mm'}, size(names)));

% ---- mesh
fid = fopen(fullfile(folder, 'mesh.txt'), 'w');
fprintf(fid, '# Mesh: %d axial x (%d vapor + %d wick + %d wall) = %d cells\n', mesh.Nz, mesh.Nv, mesh.Nw, mesh.Ns, mesh.Ncells);
fprintf(fid, '# dz %.4g - %.4g mm, dr %.4g - %.4g mm\n', mm*mesh.minDz, mm*mesh.maxDz, mm*mesh.minDr, mm*mesh.maxDr);
fprintf(fid, '# radial nodes r [mm] (%d)\n', numel(mesh.r_nodes));
fprintf(fid, '%.10g\n', mm*mesh.r_nodes);
fprintf(fid, '\n# axial nodes z [mm] (%d)\n', numel(mesh.z_nodes));
fprintf(fid, '%.10g\n', mm*mesh.z_nodes);
fclose(fid);

% ---- boundary conditions per axial column, with the result
Twall = outerWallTemperature(mesh, bc, mat, r.fields.T);
qA = bc.q.*bc.Aout; robin = bc.robinG.*(bc.robinT - r.fields.T(mesh.Nr,:));
Tref = C(bc.robinT); Tref(bc.robinG == 0) = NaN;
qflux = bc.q; qflux(bc.robinG > 0) = NaN;
writeTextTable(fullfile(folder, 'boundary_conditions.txt'), ...
    {['Outer-wall boundary conditions per axial column. ', status], ...
     ['evaporator: ' describeZoneBC(c,'evaporator')], ['transport: ' describeZoneBC(c,'transport')], ...
     ['condenser: ' describeZoneBC(c,'condenser')], 'unheated end sections: adiabatic', ...
     'zone: 1 unheated start, 2 evaporator, 4 transport, 5 condenser, 6 unheated end', ...
     'q: prescribed flux (+ into the pipe, NaN for temperature/convection columns); T_ref: prescribed wall T or T_inf; G: conductance to T_ref'}, ...
    {'z_mm', 'zone', 'q_W_m2', 'T_ref_C', 'G_W_K', 'T_wall_C', 'heat_into_pipe_W'}, ...
    [mm*mesh.z_centers(:), mesh.zone(:), qflux(:), Tref(:), bc.robinG(:), C(Twall(:)), qA(:) + robin(:)]);

% ---- materials
names = {'vapor dynamic viscosity', 'vapor thermal conductivity', 'vapor specific heat', 'vapor gas constant', ...
         'vapor density at T_o', 'latent heat h_fg (water, at T_eval)', 'liquid density', 'liquid dynamic viscosity', ...
         'liquid thermal conductivity', 'liquid specific heat', 'surface tension', 'wick porosity', ...
         'wick permeability', 'wick solid conductivity', 'wick effective conductivity', 'wick capillary radius', ...
         'wall thermal conductivity', 'wall density', 'wall specific heat', 'property evaluation temperature'};
vals = [mat.vapor.mu, mat.vapor.k, mat.vapor.cp, mat.vapor.R, mat.vapor.rho_o, mat.phase.hfg, mat.liquid.rho, ...
        mat.liquid.mu, mat.liquid.k, mat.liquid.cp, mat.liquid.surfaceTension_N_m, mat.wick.porosity, ...
        mat.wick.permeability_m2, mat.wick.k_s, mat.wick.k_eff, mat.wick.capillaryRadius_m, mat.wall.k, ...
        mat.wall.rho, mat.wall.cp, C(mat.T_eval_K)];
units = {'Pa s', 'W/m K', 'J/kg K', 'J/kg K', 'kg/m3', 'J/kg', 'kg/m3', 'Pa s', 'W/m K', 'J/kg K', 'N/m', '-', ...
         'm2', 'W/m K', 'W/m K', 'm', 'W/m K', 'kg/m3', 'J/kg K', 'degC'};
writeNameValue(fullfile(folder, 'materials.txt'), 'Material properties', names, vals, units);

% ---- temperature field (matrix: first row z, first column r)
T = C(r.fields.T);
fid = fopen(fullfile(folder, 'temperature_field.txt'), 'w');
fprintf(fid, '# Temperature field [degC] at the cell centres. %s\n', status);
fprintf(fid, '# First row: z [m] of the columns; first column: r [mm] of the rows (vapor core, wick, wall)\n');
fprintf(fid, ['r_mm\\z_m' repmat('\t%.10g', 1, mesh.Nz) '\n'], mesh.z_centers);
for i = 1:mesh.Nr
    fprintf(fid, ['%.10g' repmat('\t%.10g', 1, mesh.Nz) '\n'], mm*mesh.r_centers(i), T(i,:));
end
fclose(fid);

% ---- velocity field (vapor and wick cell centres)
[Zv, Rv] = meshgrid(P.z, r.vapor.rc(:)); [Zw, Rw] = meshgrid(P.z, r.wick.rc(:));
spdW = sqrt(P.wickW.^2 + P.wickV.^2);
data = [ones(numel(Zv),1), mm*Rv(:), Zv(:), P.vaporW(:), P.vaporV(:), P.vaporSpeed(:); ...
        2*ones(numel(Zw),1), mm*Rw(:), Zw(:), P.wickW(:), P.wickV(:), spdW(:)];
writeTextTable(fullfile(folder, 'velocity_field.txt'), ...
    {['Velocity field at the cell centres (wick: intrinsic liquid velocity, true values, not scaled). ' status], ...
     'region: 1 vapor core, 2 wick; w axial, v radial velocity'}, ...
    {'region', 'r_mm', 'z_m', 'w_m_s', 'v_m_s', 'speed_m_s'}, data);

% ---- axial profiles
writeTextTable(fullfile(folder, 'axial_temperatures.txt'), {['Axial temperatures. ' status]}, ...
    {'z_m', 'T_outer_wall_C', 'T_axis_C', 'T_interface_C', 'T_wick_wall_C'}, ...
    [P.z(:), C(P.T_outerWall_K(:)), C(P.T_centerline_K(:)), C(P.T_interface_K(:)), C(P.T_wallWick_K(:))]);
writeTextTable(fullfile(folder, 'interface_mass_flux.txt'), ...
    {['Interface mass flux (Eq. 16), + = evaporation. ' status]}, {'z_m', 'mdot_kg_m2s'}, [P.z(:), P.mpp(:)]);
writeTextTable(fullfile(folder, 'pressures.txt'), ...
    {sprintf('Pressures at r = a relative to p_o = %.4f Pa. %s', P.p_o, status)}, ...
    {'z_m', 'p_vapor_minus_p_o_Pa', 'p_liquid_minus_p_o_Pa', 'p_vapor_minus_p_liquid_Pa'}, ...
    [P.z(:), P.pVapor_Pa(:) - P.p_o, P.pLiquid_Pa(:) - P.p_o, P.capillaryDp_Pa(:)]);

% ---- iteration histories
H = r.history;
writeTextTable(fullfile(folder, 'convergence.txt'), {['Residuals per outer iteration. ' status]}, ...
    {'iteration', 'mass_vapor', 'mass_wick', 'momentum_vapor_w', 'momentum_vapor_v', 'momentum_wick_w', ...
     'momentum_wick_v', 'max_dT_K', 'mdot_change', 'interface_closure'}, ...
    [H.iter, H.massVapor, H.massWick, H.momVaporW, H.momVaporV, H.momWickW, H.momWickV, H.maxDeltaT, ...
     H.mdotChange, H.interfaceClosure]);
M = monitorHistory(r);
writeTextTable(fullfile(folder, 'power_in_out.txt'), {['Heat input and output per outer iteration. ' status]}, ...
    {'iteration', 'Q_in_W', 'Q_out_W'}, [M.iter, M.Qin_W, M.Qout_W]);
writeTextTable(fullfile(folder, 'thermal_resistance.txt'), ...
    {['Total thermal resistance R = (T_wall,evap - T_wall,cond)/Q_evap per outer iteration. ' status], ...
     sprintf('final: evaporator %.6g, vapor %.6g, condenser %.6g, total %.6g K/W', ...
             P.R_evap_KW, P.R_vapor_KW, P.R_cond_KW, P.R_total_KW)}, ...
    {'iteration', 'R_total_K_W'}, [M.iter, M.Rtotal_KW]);
end

function M = monitorHistory(r)
if isfield(r, 'monitor') && ~isempty(r.monitor) && ~isempty(r.monitor.iter)
    M = r.monitor;
else
    M = struct('iter', r.iterations, 'Qin_W', r.heat.Qin, 'Qout_W', r.heat.Qout, 'Rtotal_KW', r.profiles.R_total_KW);
end
end

function writeNameValue(file, title, names, vals, units)
fid = fopen(file, 'w');
fprintf(fid, '# %s\nquantity\tvalue\tunit\n', title);
for k = 1:numel(names)
    fprintf(fid, '%s\t%.10g\t%s\n', names{k}, vals(k), units{k});
end
fclose(fid);
end

% ========================================================================
function writePdfFiles(r, folder)
label = finalLabel(r);
c = r.caseData;

f = newFigure([1200 460]);
drawGeometry(axes('Parent', f, 'Position', [0.06 0.12 0.92 0.78]), c);
savePdfClose(f, fullfile(folder, 'geometry.pdf'));

f = newFigure([1200 760]);
ax1 = axes('Parent', f, 'Position', [0.06 0.58 0.92 0.36]);
ax2 = axes('Parent', f, 'Position', [0.06 0.08 0.92 0.36]);
drawMesh(ax1, r.mesh, c);
title(ax1, sprintf('Mesh: %d axial x (%d vapor + %d wick + %d wall) = %d cells  (radial direction stretched)', ...
    r.mesh.Nz, r.mesh.Nv, r.mesh.Nw, r.mesh.Ns, r.mesh.Ncells));
zEnd = min(1e3*c.L_total, 1e3*c.heaterSegments_m(1,2) + 40);
drawMesh(ax2, r.mesh, c, [0 zEnd]);
title(ax2, sprintf('Detail: z = 0 - %.0f mm', zEnd));
savePdfClose(f, fullfile(folder, 'mesh.pdf'));

f = newFigure([1200 700]);
drawBCPreview(axes('Parent', f, 'Position', [0.08 0.58 0.88 0.36]), ...
              axes('Parent', f, 'Position', [0.08 0.09 0.88 0.36]), c);
savePdfClose(f, fullfile(folder, 'boundary_conditions.pdf'));

panels = resultPanels();
for k = 1:size(panels, 1)
    f = newFigure(panels{k,3});
    axes('Parent', f);
    drawPanel(panels{k,1}, r, f, label);
    savePdfClose(f, fullfile(folder, [panels{k,2} '.pdf']));
end

f = newFigure([1600 1000]);
plotDiagnostics(r, f, label);
savePdfClose(f, fullfile(folder, 'diagnostics.pdf'));
end

function f = newFigure(sz)
f = figure('Visible', 'off', 'Color', 'w', 'Position', [50 50 sz]);
end

function savePdfClose(f, file)
savePdf(f, file);
close(f);
end
