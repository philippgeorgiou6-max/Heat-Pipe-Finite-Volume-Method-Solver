function R = computeThermalResistance(mesh, caseData, Twall, Taxis, Q)
%COMPUTETHERMALRESISTANCE Thermal resistances R = dT/Q of the heat pipe [K/W].
%   Twall : outer-wall temperature at r = c, Taxis : vapor temperature at
%   r = 0 (per axial column). Temperatures are length-weighted means over the
%   evaporator and the condenser; Q = heat put in through the evaporator
%   [W] (default: the prescribed evaporator power).
%     R.evap  = (Twall(evap) - Taxis(evap))/Q    wall, wick, interface
%     R.vapor = (Taxis(evap) - Taxis(cond))/Q    vapor flow
%     R.cond  = (Taxis(cond) - Twall(cond))/Q    interface, wick, wall
%     R.total = (Twall(evap) - Twall(cond))/Q
isE = mesh.heaterIndex > 0; isC = mesh.isCondenser; dz = mesh.dz;
zmean = @(T, mask) sum(T(mask).*dz(mask))/sum(dz(mask));
R.TwallEvap_K  = zmean(Twall, isE);
R.TwallCond_K  = zmean(Twall, isC);
R.TvaporEvap_K = zmean(Taxis, isE);
R.TvaporCond_K = zmean(Taxis, isC);
if nargin < 5 || isempty(Q), Q = caseData.totalHeatInput_W; end
if isfinite(Q) && Q > 0
    R.evap  = (R.TwallEvap_K - R.TvaporEvap_K)/Q;
    R.vapor = (R.TvaporEvap_K - R.TvaporCond_K)/Q;
    R.cond  = (R.TvaporCond_K - R.TwallCond_K)/Q;
    R.total = (R.TwallEvap_K - R.TwallCond_K)/Q;
else
    R.evap = NaN; R.vapor = NaN; R.cond = NaN; R.total = NaN;
end
end
