function writeCleanRunSummary(results, file)
%WRITECLEANRUNSUMMARY Text summary of a run (default: <resultsFolder>/summary.txt).
if nargin < 2 || isempty(file)
    folder = results.num.resultsFolder;
    if ~exist(folder,'dir'), mkdir(folder); end
    file = fullfile(folder,'summary.txt');
end
fid = fopen(file,'w');
if fid < 0, warning('Could not write %s', file); return; end
c = results.caseData; m = results.mat; P = results.profiles; h = results.heat;
fprintf(fid,'Heat-pipe solver run summary\n============================\n');
fprintf(fid,'Paper  : %s\n', c.paperReference);
fprintf(fid,'Case   : %s\n', c.name);
fprintf(fid,'Model  : Faghri & Buchko (1991) conjugate model   Grid: %s, %d axial x (%d vapor + %d wick + %d wall)\n', ...
    results.mesh.gridPreset, results.mesh.Nz, results.mesh.Nv, results.mesh.Nw, results.mesh.Ns);
fprintf(fid,'Evaporator [%.4f %.4f] m: %s\n', c.heaterSegments_m(1,:), describeZoneBC(c,'evaporator'));
fprintf(fid,'Transport  [%.4f %.4f] m: %s\n', c.transportStart, c.transportEnd, describeZoneBC(c,'transport'));
fprintf(fid,'Condenser  [%.4f %.4f] m: %s\n', c.condenserStart, c.condenserEnd, describeZoneBC(c,'condenser'));
if isfield(results.bc,'condenserScale') && results.bc.condenserScale ~= 1
    fprintf(fid,'  (flux-only BCs: condenser flux scaled by %.6g to remove the input)\n', results.bc.condenserScale);
end
if results.bc.levelFixedByAnchor
    fprintf(fid,'T_o = %.3f degC (%s, sets the temperature level); p_o = %.2f Pa\n', results.T_o-273.15, c.T_o_source, P.p_o);
else
    fprintf(fid,'T_o = %.3f degC (solved; start value %.2f degC); p_o = %.2f Pa\n', results.T_o-273.15, c.T_o_K-273.15, P.p_o);
end
fprintf(fid,'Converged: %d after %d iterations (%.1f s)%s\n', results.converged, results.iterations, getfieldOr(results,'wallTime_s',NaN), ...
    stoppedNote(results));
if isfield(results,'finalResiduals')
    r = results.finalResiduals;
    fprintf(fid,['Residuals re-evaluated on the final fields: mass vapor %.2e, wick %.2e; momentum vapor %.2e/%.2e, ', ...
        'wick %.2e/%.2e; energy %.2e; interface closure %.2e\n'], ...
        r.massVapor, r.massWick, r.momVapor, r.momWick, r.energy, r.interfaceClosure);
    fprintf(fid,'Last outer iteration: max dT %.2e K; mdot change %.2e\n', r.maxDeltaT, r.mdotChange);
end
fprintf(fid,'\nEnergy: Qin %.6f W, Qout %.6f W ((Qin - Qout)/Qin = %.2e); latent evaporation / Qin = %.5f\n', ...
    h.Qin, h.Qout, h.energyImbalance, h.latentToInputRatio);
fprintf(fid,'Zones: evaporator in %.4f W, condenser out %.4f W, transport loss %.4f W\n', h.Qevap_W, h.Qcond_W, h.Qtransport_W);
fprintf(fid,'Temperatures [degC]: peak outer wall %.3f at z = %.4f m; transport wall %.3f; condenser wall %.3f\n', ...
    P.peakWall_K-273.15, P.peakWall_z, P.transportWallMean_K-273.15, P.condenserWallMean_K-273.15);
fprintf(fid,'Vapor (centreline) mean %.4f degC, range %.2e K; interface T range %.2e K\n', P.vaporMean_K-273.15, P.vaporRange_K, ...
    max(P.T_interface_K)-min(P.T_interface_K));
fprintf(fid,'dT_wall-vapor at the evaporator centre [K]: %.3f\n', P.dTwallVapor_K);
fprintf(fid,['Thermal resistance [K/W]: evaporator %.5f, vapor %.3e, condenser %.5f, total %.5f ', ...
    '(mean wall evap/cond %.3f/%.3f degC, mean vapor evap/cond %.4f/%.4f degC)\n'], ...
    P.R_evap_KW, P.R_vapor_KW, P.R_cond_KW, P.R_total_KW, P.TwallEvap_K-273.15, P.TwallCond_K-273.15, ...
    P.TvaporEvap_K-273.15, P.TvaporCond_K-273.15);
fprintf(fid,'Vapor: max |w| %.4f m/s, Re_axial %.0f, Re_radial %.1f, dp_v %.4f Pa\n', P.wMaxVapor, P.Re_axial_max, P.Re_radial_max, P.vaporDp_Pa);
fprintf(fid,'Liquid: dp_l %.2f Pa; max capillary dp %.2f Pa vs 2 sigma/r_c = %.1f Pa (ratio %.3f)\n', P.liquidDp_Pa, ...
    max(P.capillaryDp_Pa), P.capillaryLimitDp_Pa, P.capillaryRatio);
if isfield(m,'fluidPropertiesFollowT_o') && m.fluidPropertiesFollowT_o
    how = 'water properties following T_o';
else
    how = 'fluid properties fixed by the user';
end
fprintf(fid,'\nMaterials (%s, evaluated at %.2f degC): rho_l %.2f, mu_l %.4e, k_l %.4f, cp_l %.1f, h_fg %.5e, mu_v %.4e, k_v %.4f, cp_v %.1f\n', ...
    how, m.T_eval_K-273.15, m.liquid.rho, m.liquid.mu, m.liquid.k, m.liquid.cp, m.phase.hfg, m.vapor.mu, m.vapor.k, m.vapor.cp);
fprintf(fid,'Wick: eps %.4f, K %.4e m2, r_c %.4e m, k_eff %.4f W/mK; wall k %.1f W/mK\n', m.wick.porosity, ...
    m.wick.permeability_m2, m.wick.capillaryRadius_m, m.wick.k_eff, m.wall.k);
fclose(fid);
end

function s = stoppedNote(results)
s = '';
if isfield(results,'stoppedByUser') && results.stoppedByUser, s = ', stopped by the user'; end
end

function v = getfieldOr(s,f,d)
if isfield(s,f), v = s.(f); else, v = d; end
end
