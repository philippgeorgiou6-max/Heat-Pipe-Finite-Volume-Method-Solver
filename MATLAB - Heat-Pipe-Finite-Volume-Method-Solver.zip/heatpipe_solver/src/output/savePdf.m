function savePdf(fig, file)
%SAVEPDF Save a figure as a PDF page of the same size as the figure.
oldUnits = get(fig, 'Units');
set(fig, 'Units', 'centimeters');
pos = get(fig, 'Position');
set(fig, 'Units', oldUnits);
set(fig, 'PaperUnits', 'centimeters', 'PaperSize', pos(3:4), ...
         'PaperPositionMode', 'manual', 'PaperPosition', [0 0 pos(3:4)]);
if isOctave()
    print(fig, file, '-dpdf');
else
    print(fig, file, '-dpdf', '-painters');   % vector output
end
end
