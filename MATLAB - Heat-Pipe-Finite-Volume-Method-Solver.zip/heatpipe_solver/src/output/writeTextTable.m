function writeTextTable(file, headerLines, columnNames, data)
%WRITETEXTTABLE Tab-separated text table with '#' header lines.
%   headerLines : cell array of comment lines (written with a leading '# ')
%   columnNames : cell array of column names
%   data        : numeric matrix (one column per name)
fid = fopen(file, 'w');
if fid < 0, error('Cannot write %s', file); end
for k = 1:numel(headerLines)
    fprintf(fid, '# %s\n', headerLines{k});
end
fprintf(fid, '%s\n', strjoin(columnNames, sprintf('\t')));
fmt = [strjoin(repmat({'%.10g'}, 1, size(data,2)), '\t') '\n'];
fprintf(fid, fmt, data.');
fclose(fid);
end
