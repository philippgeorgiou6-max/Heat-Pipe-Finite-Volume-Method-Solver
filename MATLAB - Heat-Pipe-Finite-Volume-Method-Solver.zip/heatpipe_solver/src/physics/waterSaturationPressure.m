function p_sat = waterSaturationPressure(T)
%WATERSATURATIONPRESSURE Saturation pressure of water from temperature.
T_triple = 273.16;
T_crit   = 647.096;
p_crit   = 22.064e6;
if any(~isfinite(T(:)))
    error('Temperature input to waterSaturationPressure must be finite.');
end
if any(T(:) < T_triple) || any(T(:) >= T_crit)
    error('Temperature input to waterSaturationPressure must satisfy %.2f K <= T < %.3f K.',T_triple,T_crit);
end
theta = 1.0 - T ./ T_crit;
a1 = -7.85951783;
a2 =  1.84408259;
a3 = -11.7866497;
a4 =  22.6807411;
a5 = -15.9618719;
a6 =  1.80122502;
ln_p_ratio = (T_crit ./ T) .* (a1 .* theta + a2 .* theta.^1.5 + a3 .* theta.^3.0 + ...
    a4 .* theta.^3.5 + a5 .* theta.^4.0 + a6 .* theta.^7.5);
p_sat = p_crit .* exp(ln_p_ratio);
end
