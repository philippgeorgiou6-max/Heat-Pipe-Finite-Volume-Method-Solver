function iface = computeCleanInterfaceState(mesh,fields,caseData,mat,T_o,pGaugeInterface)
%COMPUTECLEANINTERFACESTATE Local interface temperature T_i(z), paper Eq. (19).
%
%   T_i(z) = 1 / ( 1/T_o - (R/h_fg) ln(p_v(z,a)/p_o) ),  p_o = p_sat(T_o)
%
% pGaugeInterface (1 x Nz) is the gauge vapor pressure next to the interface,
% extrapolated from the solved vapor field to r = a (zeros for the pure
% conduction start-up). The absolute level is
% fixed by the operating-state anchor:
%   'meanInterface': area-weighted mean of p_v(z,a) = p_o (default)
%   'point'        : p_v(z_ref,a) = p_o
% Half-cell conductances Gv, Gw connect the adjacent vapor / wick cells to the
% Dirichlet interface face.

if nargin < 6 || isempty(pGaugeInterface), pGaugeInterface = zeros(1,mesh.Nz); end
iv = mesh.Nv; iw = mesh.Nv + 1;
a = caseData.R_vapor;
A = mesh.A_interface;
iface.iv = iv; iface.iw = iw; iface.A = A;
iface.dv = a - mesh.r_centers(iv);
iface.dw = mesh.r_centers(iw) - a;
iface.Gv = fields.k(iv,:).*A/iface.dv;
iface.Gw = fields.k(iw,:).*A/iface.dw;

wo = waterThermoProperties(T_o);
iface.T_o = T_o;
iface.p_o = waterSaturationPressure(T_o);
iface.hfg_o = wo.phase.hfg;
iface.R = mat.vapor.R;

switch lower(caseData.pressureReference)
    case 'meaninterface'
        ref = sum(pGaugeInterface.*A)/sum(A);
    case 'point'
        [~,jr] = min(abs(mesh.z_centers - caseData.pressureReferencePoint_z));
        ref = pGaugeInterface(jr);
    otherwise
        error('Unknown pressureReference "%s".', caseData.pressureReference);
end
iface.pShift = ref;
iface.pAbs = iface.p_o + pGaugeInterface - ref;
iface.Ti = interfaceTemperatureEq19(iface.pAbs, T_o, iface.p_o, iface.hfg_o, iface.R);
end
