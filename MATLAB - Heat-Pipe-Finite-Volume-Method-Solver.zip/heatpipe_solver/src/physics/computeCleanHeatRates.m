function heat = computeCleanHeatRates(mesh,fields,bc,m)
%COMPUTECLEANHEATRATES Boundary heat rates and global balances.
%
% energyImbalance = (Qin - Qout)/Qin of the outer boundary. With prescribed
% fluxes on every outer face (paper Eq. 20) it is fixed by the input and is
% not a test of the solution; it only becomes one with convective or
% temperature condenser BCs. The energy balance of the solution itself is
% m.relImbalance (net heat into the interface over the latent heat) and the
% re-evaluated energy residual (evaluateFinalResiduals).
T = fields.T;
qA = bc.q.*bc.Aout;                                  % flux columns, + = into domain
robin = bc.robinG.*(bc.robinT - T(mesh.Nr,:));       % Robin/Dirichlet columns
heat.Qin  = sum(qA(qA > 0)) + sum(robin(robin > 0));
heat.Qout = -sum(qA(qA < 0)) - sum(robin(robin < 0));
heat.energyImbalance = (heat.Qin - heat.Qout)/max(abs(heat.Qin),1e-12);
% net heat per zone of the outer wall
net = qA + robin;                                    % into the domain, per column
heat.Qevap_W = sum(net(mesh.heaterIndex > 0));       % into the pipe through the evaporator
heat.Qcond_W = -sum(net(mesh.isCondenser));          % out of the pipe through the condenser
heat.Qtransport_W = -sum(net(mesh.zone == 4));       % lost through the transport section
if nargin >= 4 && ~isempty(m)
    heat.latentEvaporation_W = m.latentEvaporation_W;
    heat.latentToInputRatio = m.latentEvaporation_W/max(heat.Qin,1e-12);
    heat.netHeatToInterface_W = m.netHeatToInterface;
end
end
