function m = computeInterfaceMassFlux(mesh,T,iface)
%COMPUTEINTERFACEMASSFLUX Phase-change mass flux from paper Eq. (16).
%
%   v(z,a) = [ -k_eff dT_l/dr|_a + k_v dT_v/dr|_a ] / (rho_v h_fg)
%   m''(z) = -rho_v v(z,a) = (q_wick->i + q_vapor->i) / (A h_fg(T_i))
% with the conductive fluxes evaluated by the half-cell conductances to the
% Dirichlet interface temperature T_i(z). m'' > 0 is evaporation.
% The closed vapor and liquid domains require sum(m''A) = 0; the tiny
% discrete imbalance is removed by a uniform (area-weighted) correction and
% reported in m.relImbalance.

iv = iface.iv; iw = iface.iw; A = iface.A;
m.qVapor = iface.Gv.*(T(iv,:) - iface.Ti);
m.qWick  = iface.Gw.*(T(iw,:) - iface.Ti);
wp = waterThermoProperties(iface.Ti);
m.hfg = wp.phase.hfg;
raw = (m.qVapor + m.qWick)./m.hfg;
m.netRaw = sum(raw);
m.totalEvaporationRaw = sum(max(raw,0));
m.relImbalance = abs(m.netRaw)/max(m.totalEvaporationRaw, realmin);
m.mdotRaw = raw;
m.mdot = raw - m.netRaw*A/sum(A);
m.mpp = m.mdot./A;
m.totalEvaporation = sum(max(m.mdot,0));
m.totalCondensation = -sum(min(m.mdot,0));
m.netHeatToInterface = sum(m.qVapor + m.qWick);
m.latentEvaporation_W = sum(max(m.mdot,0).*m.hfg);
end
