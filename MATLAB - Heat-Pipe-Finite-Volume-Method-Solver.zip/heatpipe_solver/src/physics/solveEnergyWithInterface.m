function [fields,iface,m,T_o] = solveEnergyWithInterface(mesh,fields,caseData,mat,num,bc,T_o,pGaugeInterface)
%SOLVEENERGYWITHINTERFACE Energy solve with the Eq. (19) interface and Eq. (16) mass flux.
%
% For flux-only outer BCs (paper Eq. 20) the temperature level is fixed by the
% anchor T_o. With temperature or convection BCs T_o is unknown and is found
% so that the net Eq. (16) mass flow through the interface is zero: in the
% closed vapor space everything that evaporates must condense. The balance is
% taken on mass, sum((q_v + q_w)/h_fg(T_i)) = 0, not on heat: h_fg varies
% along the interface with T_i, so zero net heat would leave a net mass flow
% of order (dh_fg/dT)*dT_i/h_fg, which the interface-closure criterion
% (num.tolInterfaceClosure) rejects. net(T_o) is close to linear, so a secant
% update converges in a few solves; the first step is the fixed-point
% estimate net/sum(G/h_fg).

maxLevelIter = 1;
if ~bc.levelFixedByAnchor, maxLevelIter = 60; end
T_oPrev = NaN; netPrev = NaN;
for it = 1:maxLevelIter
    iface = computeCleanInterfaceState(mesh,fields,caseData,mat,T_o,pGaugeInterface);
    [A,b] = assembleCleanEnergyEquation(mesh,fields,iface,bc,num);
    if isfield(num,'stopOnNonFinite') && num.stopOnNonFinite
        checkFiniteLinearSystem(A,b,'energy equation');
    end
    T = reshape(A\b, mesh.Nr, mesh.Nz);
    assertFiniteField(T,'temperature');
    if bc.levelFixedByAnchor
        break;
    end
    wp = waterThermoProperties(iface.Ti);            % h_fg(T_i), as in Eq. (16)
    net = sum((iface.Gv.*(T(iface.iv,:) - iface.Ti) + iface.Gw.*(T(iface.iw,:) - iface.Ti))./wp.phase.hfg);  % [kg/s]
    dTo = net/sum((iface.Gv + iface.Gw)./wp.phase.hfg);   % fixed-point estimate
    if it > 1
        slope = (net - netPrev)/(T_o - T_oPrev);     % d(net)/dT_o, negative
        if isfinite(slope) && slope < 0
            dTo = -net/slope;                        % secant step
        end
    end
    dTo = max(min(dTo, 50), -50);                    % at most 50 K per step
    T_oPrev = T_o; netPrev = net;
    T_o = T_o + dTo;
    if abs(dTo) < 1e-9
        break;
    end
end
fields.T = T;
m = computeInterfaceMassFlux(mesh,T,iface);
end
