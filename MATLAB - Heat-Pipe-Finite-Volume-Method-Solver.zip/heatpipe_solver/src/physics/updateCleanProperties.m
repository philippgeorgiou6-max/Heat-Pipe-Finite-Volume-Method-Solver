function fields = updateCleanProperties(fields,mesh,caseData,mat)
%UPDATECLEANPROPERTIES Region-wise property fields used by the energy equation.
%   k      : vapor k_v, wick k_eff (Eq. 9), wall k_w
%   cpConv : specific heat of the convected phase (vapor c_p,v, wick c_p,l, wall 0)
%   rho    : vapor rho_v = p/(R T) (ideal gas), wick rho_l, wall rho_w
ids = caseData.regionIDs;
maskV = mesh.region == ids.vapor;
maskW = mesh.region == ids.wick;
maskS = mesh.region == ids.wall;
fields.k = zeros(mesh.Nr,mesh.Nz);
fields.k(maskV) = mat.vapor.k;
fields.k(maskW) = mat.wick.k_eff;
fields.k(maskS) = mat.wall.k;
fields.cpConv = zeros(mesh.Nr,mesh.Nz);
fields.cpConv(maskV) = mat.vapor.cp;
fields.cpConv(maskW) = mat.liquid.cp;
fields.rho = zeros(mesh.Nr,mesh.Nz);
pAbs = mat.phase.p_o*ones(mesh.Nr,mesh.Nz);
if isfield(fields,'pAbs') && ~isempty(fields.pAbs), pAbs = fields.pAbs; end
fields.rho(maskV) = pAbs(maskV)./(mat.vapor.R*fields.T(maskV));
fields.rho(maskW) = mat.liquid.rho;
fields.rho(maskS) = mat.wall.rho;
end
