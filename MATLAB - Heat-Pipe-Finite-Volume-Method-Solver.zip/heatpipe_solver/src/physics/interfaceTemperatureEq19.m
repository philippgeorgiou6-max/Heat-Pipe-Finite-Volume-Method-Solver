function T = interfaceTemperatureEq19(p,T_o,p_o,hfg_o,R)
%INTERFACETEMPERATUREEQ19 Paper Eq. (19): saturation temperature at the interface.
%   T(z,a) = 1 / ( 1/T_o - (R/h_fg) * ln(p_v(z,a)/p_o) )
%   p, p_o [Pa]; T_o [K]; hfg_o [J/kg] (at T_o); R [J/kg/K].
T = 1 ./ (1./T_o - (R./hfg_o).*log(p./p_o));
end
