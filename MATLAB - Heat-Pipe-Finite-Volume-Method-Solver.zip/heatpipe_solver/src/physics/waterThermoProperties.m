function props = waterThermoProperties(T)
%WATERTHERMOPROPERTIES Saturated water/steam properties for 10-150 degC.
%
%   props = waterThermoProperties(T) returns liquid, vapor and phase-change
%   properties of saturated water at temperature T [K] (scalar or array).
%
%   The correlations were fitted to IAPWS-quality data (IAPWS-95 equation of
%   state, IAPWS-2008 viscosity, IAPWS-2011 conductivity, IAPWS surface
%   tension; evaluated with CoolProp) over 10-150 degC. Maximum relative
%   deviation from IAPWS:
%       10-150 degC : rho_l 0.03%, mu_l 0.6%, k_l 0.13%, cp_l 0.05%,
%                     h_fg 0.006%, mu_v 0.26%, k_v 0.6%, cp_v 0.06%
%       40-120 degC : all liquid properties and h_fg < 0.2%, vapor < 0.3%
%   p_sat uses the Wagner-Pruss equation (waterSaturationPressure.m) and the
%   surface tension uses the IAPWS 1994 formula. Inputs outside 10-150 degC
%   are clamped and flagged in props.inputTemperatureWasBounded.

T = double(T);
if any(~isfinite(T(:)))
    error('waterThermoProperties: temperature must be finite.');
end
Tmin = 283.15; Tmax = 423.15;
props.inputTemperatureWasBounded = (T < Tmin) | (T > Tmax);
Tuse = min(max(T,Tmin),Tmax);
TC = Tuse - 273.15;

% ---- saturated liquid ---------------------------------------------------
props.liquid.rho = ((6.7235081111e-06.*TC - 4.3235878122e-03).*TC - 6.1373589093e-02).*TC + 1.0010098686e+03;
props.liquid.mu  = 2.443279e-05 .* 10.^(248.097461 ./ (Tuse - 139.359247));
props.liquid.k   = ((1.6731526899e-08.*TC - 1.1514636531e-05).*TC + 2.1670239594e-03).*TC + 5.5891567800e-01;
props.liquid.cp  = (((6.0681166457e-07.*TC - 1.8833360749e-04).*TC + 2.9903696786e-02).*TC ...
                    - 1.6235235253e+00).*TC + 4.2071262102e+03;
tau = 1.0 - Tuse./647.096;
props.liquid.surfaceTension_N_m = 0.2358 .* tau.^1.256 .* (1.0 - 0.625.*tau);

% ---- saturated vapor ----------------------------------------------------
props.vapor.R   = 461.52;
props.vapor.mu  = (1.2088481926e-11.*TC + 3.2102224578e-08).*TC + 8.8920851664e-06;
props.vapor.k   = (2.3346733963e-07.*TC + 5.3211803063e-05).*TC + 1.6960756064e-02;
props.vapor.cp  = ((1.5176962224e-04.*TC - 9.4983472075e-03).*TC + 1.4323492739e+00).*TC + 1.8800268568e+03;

% ---- phase change -------------------------------------------------------
props.phase.hfg  = ((-1.4396298251e-02.*TC + 9.0802903026e-01).*TC - 2.3941351136e+03).*TC + 2.5011530280e+06;
props.phase.psat = waterSaturationPressure(Tuse);
props.vapor.rhoIdealGas = props.phase.psat ./ (props.vapor.R .* Tuse);

props.validityNote = ['Fits to IAPWS data (via CoolProp) over 10-150 degC; ', ...
    'inputs outside are clamped and flagged.'];
end
