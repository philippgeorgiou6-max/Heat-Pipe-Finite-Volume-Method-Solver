function p = interfacePressureEq19(T,T_o,p_o,hfg_o,R)
%INTERFACEPRESSUREEQ19 Inverse of paper Eq. (19): p = p_o exp((h_fg/R)(1/T_o - 1/T)).
p = p_o .* exp((hfg_o./R).*(1./T_o - 1./T));
end
