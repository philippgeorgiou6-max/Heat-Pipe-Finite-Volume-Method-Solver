function fields = initializeCleanFields(mesh,caseData,mat)
%INITIALIZECLEANFIELDS Initial temperature, properties and zero flow.
T0 = caseData.T_o_K;
if isfield(caseData,'initialTemperature_K') && isfinite(caseData.initialTemperature_K)
    T0 = caseData.initialTemperature_K;
end
fields.T = T0*ones(mesh.Nr,mesh.Nz);
fields = updateCleanProperties(fields,mesh,caseData,mat);
fields.Fr = zeros(mesh.Nr+1,mesh.Nz);
fields.Fz = zeros(mesh.Nr,mesh.Nz+1);
fields.Sc = zeros(mesh.Nr,mesh.Nz);
end
