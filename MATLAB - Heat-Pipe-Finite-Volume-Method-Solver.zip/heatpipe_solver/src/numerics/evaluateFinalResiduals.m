function F = evaluateFinalResiduals(mesh,fields,caseData,mat,num,bc,T_o,vapor,wick,m,iface)
%EVALUATEFINALRESIDUALS Residuals of the discrete equations on the final fields.
%
% Every discrete equation is assembled again from the final state (velocities,
% pressures, densities, temperatures, interface state) and its residual is
% evaluated without any update, so the numbers describe the fields that are
% returned, not an intermediate iterate:
%   massVapor, massWick : sum|cell continuity imbalance| / total evaporation
%                         (paper Eq. 1; Eq. 26 / div(rho_l eps V) = 0)
%   momVapor, momWick   : [axial radial] sum|a_P u - sum a_nb u_nb - b| / sum|a_P u|
%                         (Eqs. 2-3; Eqs. 5-6)
%   energy              : sum|A T - b| / heat input (prescribed, or from the solution)
%                         (Eqs. 4, 7, 10 with the Eq. 19 interface face)
%   interfaceClosure    : |sum of the uncorrected Eq. (16) mass flows| / total
%                         evaporation, i.e. net heat into r = a over latent heat;
%                         this is also the size of the global correction applied
%   interfaceTi_K       : max |T_i used - T_i from Eq. (19) with the final p_v|

evap = max(m.totalEvaporation, realmin);
subs = {vapor, wick};
mass = zeros(1,2); mom = zeros(2,2);
for s = 1:2
    S = subs{s};
    mf = computeSubdomainMassFlows(S);
    net = (mf.Fz(:,2:end) - mf.Fz(:,1:end-1)) + (mf.Fr(2:end,:) - mf.Fr(1:end-1,:));
    mass(s) = sum(abs(net(:)))/evap;
    div = [];
    if S.compressibleViscous, div = cellDivergence(S); end
    [~,~,cw] = assembleStaggeredMomentumW(S,mf,div,1.0,num.convectionScheme);
    [~,~,cv] = assembleStaggeredMomentumV(S,mf,div,1.0,num.convectionScheme);
    mom(s,:) = [cw.residualAbs/max(cw.residualNorm,realmin), cv.residualAbs/max(cv.residualNorm,realmin)];
end
F.massVapor = mass(1); F.massWick = mass(2);
F.momVapor = mom(1,:); F.momWick = mom(2,:);

% energy: coefficients rebuilt from the final flow field and interface state
fe = flowIntoEnergyFields(fields,mesh,vapor,wick);
ifaceF = computeCleanInterfaceState(mesh,fe,caseData,mat,T_o,vaporInterfacePressure(vapor));
numE = num; numE.alpha_T = 1.0;
[A,b] = assembleCleanEnergyEquation(mesh,fe,ifaceF,bc,numE);
r = A*fields.T(:) - b;
Qref = caseData.totalHeatInput_W;
if ~(isfinite(Qref) && Qref > 0)      % heat input not prescribed: use the solution's input
    hq = computeCleanHeatRates(mesh,fields,bc);
    Qref = hq.Qin;
end
F.energy = sum(abs(r))/max(Qref, realmin);
F.interfaceClosure = m.relImbalance;
F.interfaceTi_K = max(abs(ifaceF.Ti - iface.Ti));
end
