function v = evaluateBCFunction(expr, z, zStart, L)
%EVALUATEBCFUNCTION Evaluate a boundary-condition expression along the outer wall.
%
%   v = evaluateBCFunction(expr, z, zStart, L)
%   expr   : MATLAB expression in
%              z [m]  axial position (z = 0 at the evaporator end cap)
%              s [m]  distance from the start of the zone (s = z - zStart)
%              L [m]  length of the zone
%            e.g. '85 + 3*sin(pi*s/L)' or '2e4*exp(-((s - L/2)/(0.2*L))^2)'
%   z      : axial positions [m]
% The expression is evaluated point by point, so element-wise operators
% (.*, ./, .^) are not required. It must return one finite real number.
if isstring(expr), expr = char(expr); end
if ~ischar(expr) || isempty(strtrim(expr))
    error('A boundary-condition function is empty.');
end
try
    f = str2func(['@(z,s,L) ' expr]);
catch err
    error('The boundary-condition function "%s" is not a valid expression (%s).', expr, err.message);
end
v = zeros(size(z));
for k = 1:numel(z)
    try
        val = f(z(k), z(k) - zStart, L);
    catch err
        error('The boundary-condition function "%s" cannot be evaluated (%s). Use z, s and L as variables.', ...
            expr, err.message);
    end
    if ~isnumeric(val) || ~isscalar(val) || ~isreal(val) || ~isfinite(val)
        error('The boundary-condition function "%s" must return one finite real number (z = %.4g m).', expr, z(k));
    end
    v(k) = double(val);
end
end
