function [A,b,info] = assembleCleanEnergyEquation(mesh,fields,iface,bc,num)
%ASSEMBLECLEANENERGYEQUATION Steady conjugate energy equation, all three regions.
%
% Single matrix in temperature for vapor, wick and wall (paper Eqs. 4, 7, 10
% in the single-domain sense of Eqs. 21-24):
%   sum_faces [ cp*F*T - k*A*dT/dn ] = S
% with
%   vapor : k = k_v, convection by the vapor mass flow, S = pressure work + mu*Phi
%   wick  : k = k_eff, convection by the superficial liquid mass flow rho_l*eps*V
%   wall  : k = k_w, no convection.
% Finite volume, Patankar coefficients with the hybrid (Spalding) or power-law
% scheme. Interior faces use the distance-weighted harmonic conductivity
%   G = A / (dP/kP + dN/kN)
% which is exact for 1-D conduction across a material interface (paper: "exact
% representation of diffusion across an interface"). The vapor-liquid
% interface r = a is a Dirichlet face at the saturation temperature T_i(z)
% (Eq. 19), connected to each side by half-cell conductances; the latent heat
% m''*h_fg is the resulting jump in conductive flux (Eq. 16), so no explicit
% latent source is added.
%
% fields.k (Nr x Nz)      conductivity
% fields.cpConv (Nr x Nz) specific heat of the convected phase (0 in the wall)
% fields.Fr ((Nr+1) x Nz) mass flow through radial faces (+r) [kg/s]
% fields.Fz (Nr x (Nz+1)) mass flow through axial faces (+z) [kg/s]
% fields.Sc (Nr x Nz)     explicit source [W]

Nr = mesh.Nr; Nz = mesh.Nz; N = Nr*Nz; idx = mesh.cellIndex;
k = fields.k; cpC = fields.cpConv; Fr = fields.Fr; Fz = fields.Fz;
scheme = num.convectionScheme;
aP = zeros(Nr,Nz); bP = zeros(Nr,Nz);
I = {}; J = {}; V = {};

% ---- radial interior faces (between rows i and i+1) ----------------------
if Nr > 1
    i = (1:Nr-1)';
    dP = (mesh.r_nodes(i+1) - mesh.r_centers(i))';
    dN = (mesh.r_centers(i+1) - mesh.r_nodes(i+1))';
    dP = dP(:); dN = dN(:);
    Af = mesh.Ar(i+1,:);
    D = Af ./ (dP./k(i,:) + dN./k(i+1,:));
    C = 0.5*(cpC(i,:) + cpC(i+1,:)) .* Fr(i+1,:);
    if mesh.Nv >= 1 && mesh.Nw >= 1      % vapor-liquid interface handled below
        D(mesh.Nv,:) = 0; C(mesh.Nv,:) = 0;
    end
    As = schemeFunction(C,D,scheme);
    aNofS = D.*As + max(-C,0);   % north neighbour coefficient in the south cell equation
    aSofN = D.*As + max( C,0);   % south neighbour coefficient in the north cell equation
    aP(i,:)   = aP(i,:)   + aNofS;
    aP(i+1,:) = aP(i+1,:) + aSofN;
    S = idx(i,:); Q = idx(i+1,:);
    I{end+1} = S(:); J{end+1} = Q(:); V{end+1} = -aNofS(:);
    I{end+1} = Q(:); J{end+1} = S(:); V{end+1} = -aSofN(:);
end

% ---- axial interior faces (between columns j and j+1) --------------------
if Nz > 1
    j = 1:Nz-1;
    dP = mesh.z_nodes(j+1) - mesh.z_centers(j);
    dN = mesh.z_centers(j+1) - mesh.z_nodes(j+1);
    D = mesh.Az ./ (dP./k(:,j) + dN./k(:,j+1));
    C = 0.5*(cpC(:,j) + cpC(:,j+1)) .* Fz(:,j+1);
    As = schemeFunction(C,D,scheme);
    aEofW = D.*As + max(-C,0);
    aWofE = D.*As + max( C,0);
    aP(:,j)   = aP(:,j)   + aEofW;
    aP(:,j+1) = aP(:,j+1) + aWofE;
    W = idx(:,j); E = idx(:,j+1);
    I{end+1} = W(:); J{end+1} = E(:); V{end+1} = -aEofW(:);
    I{end+1} = E(:); J{end+1} = W(:); V{end+1} = -aWofE(:);
end

% ---- vapor-liquid interface r = a: Dirichlet T_i(z) ----------------------
info.aBv = zeros(1,Nz); info.aBw = zeros(1,Nz);
if mesh.Nv >= 1 && mesh.Nw >= 1
    iv = mesh.Nv; iw = mesh.Nv + 1;
    % The face temperature is known (T_i), so the convective flux through the
    % face is C_out*T_i for inflow and outflow alike (liquid evaporates and
    % vapor condenses at T_i). With the continuity residual removed this
    % gives a_B = G - C_out, which keeps the interface energy balance exact.
    Fint = Fr(iv+1,:);                 % +r mass flow through r = a
    Cv = cpC(iv,:).*Fint;              % outward from the vapor cell
    aBv = iface.Gv - Cv;
    Cw = -cpC(iw,:).*Fint;             % outward (-r) from the wick cell
    aBw = iface.Gw - Cw;
    bad = aBv <= 0;                    % only at cell Peclet > 1 (not expected); fall back to upwind
    if any(bad), aBv(bad) = iface.Gv(bad).*schemeFunction(Cv(bad),iface.Gv(bad),scheme) + max(-Cv(bad),0); end
    bad = aBw <= 0;
    if any(bad), aBw(bad) = iface.Gw(bad).*schemeFunction(Cw(bad),iface.Gw(bad),scheme) + max(-Cw(bad),0); end
    aP(iv,:) = aP(iv,:) + aBv;  bP(iv,:) = bP(iv,:) + aBv.*iface.Ti;
    aP(iw,:) = aP(iw,:) + aBw;  bP(iw,:) = bP(iw,:) + aBw.*iface.Ti;
    info.aBv = aBv; info.aBw = aBw;
end

% ---- outer wall r = c (Eq. 20 and non-paper options) ---------------------
bP(Nr,:) = bP(Nr,:) + bc.q.*bc.Aout;
aP(Nr,:) = aP(Nr,:) + bc.robinG;
bP(Nr,:) = bP(Nr,:) + bc.robinG.*bc.robinT;

% ---- explicit sources (vapor pressure work and viscous dissipation) -------
if isfield(fields,'Sc') && ~isempty(fields.Sc)
    bP = bP + fields.Sc;
end

% Axis (r = 0) and end caps (z = 0, L_T): zero area / omitted neighbours give
% dT/dr = 0 and dT/dz = 0 (Eqs. 15, 18).

alpha = 1.0;
if isfield(num,'alpha_T'), alpha = num.alpha_T; end
if alpha < 1
    bP = bP + (1-alpha)/alpha*aP.*fields.T;
    aP = aP/alpha;
end

A = sparse([idx(:); vertcat(I{:})], [idx(:); vertcat(J{:})], [aP(:); vertcat(V{:})], N, N);
b = bP(:);
end

function As = schemeFunction(C,D,scheme)
% Patankar's A(|P|) with P = C/D (cell Peclet number).
As = zeros(size(C));
pos = D > 0;
Pe = abs(C(pos))./D(pos);
switch lower(scheme)
    case 'hybrid'
        As(pos) = max(0, 1 - 0.5*Pe);
    case 'powerlaw'
        As(pos) = max(0, (1 - 0.1*Pe)).^5;
    case 'upwind'
        As(pos) = 1;
    otherwise
        error('Unknown convection scheme "%s".', scheme);
end
end
