function type = normalizeOuterBCType(typeIn)
%NORMALIZEOUTERBCTYPE Canonical names for evaporator/condenser thermal BCs.
%
% Canonical names (and the zones that accept them, see buildOuterThermalBC):
%   'power'                    : total power [W], uniform flux      (evaporator, condenser)
%   'heatFlux'                 : uniform heat flux [W/m2]            (condenser)
%   'temperature'              : uniform wall temperature [K]        (evaporator, condenser)
%   'temperatureFunction'      : wall temperature T(z) [degC]        (evaporator, condenser)
%   'convection'               : q = h (T_inf - T_wall)              (all zones)
%   'heatFluxFunction'         : heat flux q(z) [W/m2]               (evaporator, condenser)
%   'paperEq20UniformHeatFlux' : removes the input, paper Eq. (20)   (condenser)
%   'adiabatic'                : zero heat flux                      (transport section)
% Common spellings (e.g. 'robin', 'dirichlet', 'insulated') are mapped to these.

if isstring(typeIn), typeIn = char(typeIn); end
if ~ischar(typeIn) || isempty(strtrim(typeIn))
    error('Boundary-condition type must be a non-empty character vector or string.');
end
key = lower(strtrim(typeIn));
key = strrep(key,'-','_');
key = strrep(key,' ','_');

switch key
    case {'power','prescribedpower','prescribed_power','totalpower','total_power','q_total'}
        type = 'power';
    case {'heatflux','heat_flux','flux','prescribedheatflux','prescribed_heat_flux','qflux','q_flux'}
        type = 'heatFlux';
    case {'temperature','fixedtemperature','fixed_temperature','walltemperature','wall_temperature','dirichlet','fixedwalltemperature'}
        type = 'temperature';
    case {'convection','convective','robin','htc','heattransfercoefficient','heat_transfer_coefficient'}
        type = 'convection';
    case {'adiabatic','insulated','zeroheatflux','zero_heat_flux','noheatflux','no_heat_flux'}
        type = 'adiabatic';
    case {'temperaturefunction','temperature_function','nonuniformtemperature','non_uniform_temperature'}
        type = 'temperatureFunction';
    case {'heatfluxfunction','heat_flux_function','nonuniformheatflux','non_uniform_heat_flux'}
        type = 'heatFluxFunction';
    case {'paperuniformheatflux','paper_uniform_heat_flux','papereq20uniformheatflux','paper_eq20_uniform_heat_flux'}
        type = 'paperEq20UniformHeatFlux';
    otherwise
        error(['Unknown boundary-condition type "%s". Supported values are: ', ...
            'power, heatFlux, temperature, temperatureFunction, convection, heatFluxFunction, ', ...
            'adiabatic, paperEq20UniformHeatFlux.'],typeIn);
end
end
