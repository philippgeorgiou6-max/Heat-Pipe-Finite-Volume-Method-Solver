function checkFiniteLinearSystem(A,b,name)
%CHECKFINITELINEARSYSTEM Basic matrix safety checks.
if any(~isfinite(b))
    error('Non-finite RHS detected in %s.',name);
end
[i,j,v] = find(A); %#ok<ASGLU>
if any(~isfinite(v))
    error('Non-finite matrix coefficient detected in %s.',name);
end
if size(A,1) ~= size(A,2) || size(A,1) ~= numel(b)
    error('Matrix/RHS size mismatch in %s.',name);
end
end
