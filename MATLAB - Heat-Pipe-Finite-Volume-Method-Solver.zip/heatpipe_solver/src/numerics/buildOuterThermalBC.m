function bc = buildOuterThermalBC(mesh,caseData,mat)
%BUILDOUTERTHERMALBC Outer-wall (r = c) thermal boundary condition per column.
%
% Every axial zone of the outer wall has one BC type (caseData.*BCType):
%   evaporator : 'power' (paper Eq. 20: q = P/A, default), 'temperature',
%                'temperatureFunction', 'convection', 'heatFluxFunction'
%   transport  : 'adiabatic' (paper, default) or 'convection'
%   condenser  : 'paperEq20UniformHeatFlux' (removes the evaporator input,
%                paper Eq. 20, default), 'power', 'heatFlux', 'temperature',
%                'temperatureFunction', 'convection', 'heatFluxFunction'
%   unheated end sections: adiabatic
% Functions are expressions in z, s, L (see evaluateBCFunction); temperatures
% in degC, heat fluxes in W/m^2.
%
% bc.q      : imposed flux into the domain [W/m^2] (flux columns)
% bc.robinG : conductance between the outer wall cell centre and the reference
%             temperature [W/K] (prescribed temperature: half cell; convection:
%             half cell in series with 1/h)
% bc.robinT : reference temperature [K] (prescribed wall T or T_inf)
% bc.levelFixedByAnchor : true when every outer face has a prescribed flux, so
%             the temperature level must come from (T_o, p_o) in Eq. (19).

Nz = mesh.Nz;
Aout = mesh.A_outer;
z = mesh.z_centers;
bc.Aout = Aout;
bc.q = zeros(1,Nz);
bc.robinG = zeros(1,Nz);
bc.robinT = zeros(1,Nz);
drHalf = mesh.r_nodes(end) - mesh.r_centers(end);
bc.drHalfOuter = drHalf;
kw = mat.wall.k;

evap  = mesh.heaterIndex > 0;
cond  = mesh.isCondenser;
trans = mesh.zone == 4;
bc.evapArea = sum(Aout(evap));
bc.condArea = sum(Aout(cond));
z0e = caseData.heaterSegments_m(1,1); Le = caseData.heaterLength;
z0c = caseData.condenserStart;        Lc = caseData.L_cond;

% ---------------------------------------------------------------- evaporator
etype = normalizeOuterBCType(caseData.evaporatorBCType);
bc.evaporatorType = etype;
bc.Qin_nominal = NaN;          % heat input prescribed by flux BCs (NaN: follows from the solution)
switch etype
    case 'power'
        P = caseData.evaporatorPowers_W;
        bc.heaterArea = zeros(1,numel(P));
        for k = 1:numel(P)
            mask = mesh.heaterIndex == k;
            bc.heaterArea(k) = sum(Aout(mask));
            if bc.heaterArea(k) <= 0
                error('buildOuterThermalBC: heater %d has no mesh columns.', k);
            end
            bc.q(mask) = P(k)/bc.heaterArea(k);
        end
        bc.heaterFlux_W_m2 = P./bc.heaterArea;
        bc.Qin_nominal = sum(P);
    case 'heatFluxFunction'
        bc.q(evap) = evaluateBCFunction(caseData.evaporatorHeatFluxFunction, z(evap), z0e, Le);
        bc.Qin_nominal = sum(bc.q(evap).*Aout(evap));
    case 'temperature'
        bc.robinG(evap) = Aout(evap)*kw/drHalf;
        bc.robinT(evap) = caseData.evaporatorTemperature_K;
    case 'temperatureFunction'
        bc.robinG(evap) = Aout(evap)*kw/drHalf;
        bc.robinT(evap) = evaluateBCFunction(caseData.evaporatorTemperatureFunction, z(evap), z0e, Le) + 273.15;
    case 'convection'
        checkPositive(caseData.evaporatorH_W_m2K, 'evaporator heat transfer coefficient');
        bc.robinG(evap) = Aout(evap)./(drHalf/kw + 1/caseData.evaporatorH_W_m2K);
        bc.robinT(evap) = caseData.evaporatorTinf_K;
    otherwise
        error('Evaporator BC "%s" is not supported.', etype);
end

% ---------------------------------------------------------------- transport
ttype = normalizeOuterBCType(caseData.transportBCType);
bc.transportType = ttype;
switch ttype
    case 'adiabatic'
        % zero flux (paper)
    case 'convection'
        checkPositive(caseData.transportH_W_m2K, 'transport heat transfer coefficient');
        bc.robinG(trans) = Aout(trans)./(drHalf/kw + 1/caseData.transportH_W_m2K);
        bc.robinT(trans) = caseData.transportTinf_K;
    otherwise
        error('Transport-section BC "%s" is not supported (adiabatic or convection).', ttype);
end

% ---------------------------------------------------------------- condenser
ctype = normalizeOuterBCType(caseData.condenserBCType);
bc.condenserType = ctype;
switch ctype
    case 'paperEq20UniformHeatFlux'
        if ~isfinite(bc.Qin_nominal)
            error(['The condenser BC "remove the evaporator input (paper Eq. 20)" needs a power or ', ...
                   'heat-flux evaporator BC.']);
        end
        if strcmp(ttype, 'convection')
            error(['With a convective transport section the condenser cannot remove exactly the input ', ...
                   '(paper Eq. 20): the transport section would have to exchange zero net heat and the ', ...
                   'whole pipe would settle at its T_inf. Use a temperature or convection BC at the condenser.']);
        end
        bc.q(cond) = -bc.Qin_nominal/bc.condArea;
    case 'power'
        Pout = caseData.totalHeatOutput_W;
        if ~isfinite(Pout)
            if ~isfinite(bc.Qin_nominal)
                error('Condenser BC ''power'' needs a finite caseData.totalHeatOutput_W.');
            end
            Pout = bc.Qin_nominal;
        end
        bc.q(cond) = -Pout/bc.condArea;
    case 'heatFlux'
        if ~isfinite(caseData.condenserHeatFlux_W_m2)
            error('Condenser BC ''heatFlux'' needs a finite caseData.condenserHeatFlux_W_m2.');
        end
        bc.q(cond) = -caseData.condenserHeatFlux_W_m2;
    case 'heatFluxFunction'
        bc.q(cond) = -evaluateBCFunction(caseData.condenserHeatFluxFunction, z(cond), z0c, Lc);
    case 'temperature'
        bc.robinG(cond) = Aout(cond)*kw/drHalf;
        bc.robinT(cond) = caseData.condenserWallTemperature_K;
    case 'temperatureFunction'
        bc.robinG(cond) = Aout(cond)*kw/drHalf;
        bc.robinT(cond) = evaluateBCFunction(caseData.condenserTemperatureFunction, z(cond), z0c, Lc) + 273.15;
    case 'convection'
        checkPositive(caseData.condenserH_W_m2K, 'condenser heat transfer coefficient');
        bc.robinG(cond) = Aout(cond)./(drHalf/kw + 1/caseData.condenserH_W_m2K);
        bc.robinT(cond) = caseData.condenserTinf_K;
    otherwise
        error('Condenser BC "%s" is not supported.', ctype);
end

% ------------------------------------------------- temperature level / balance
bc.levelFixedByAnchor = ~any(bc.robinG > 0);
bc.condenserScale = 1;
if bc.levelFixedByAnchor
    % Flux-only BCs: a steady state needs zero net heat; the prescribed
    % condenser removal is scaled to the input if necessary.
    Qother = sum(bc.q(~cond).*Aout(~cond));
    Qcond = sum(bc.q(cond).*Aout(cond));            % negative = removed
    if abs(Qother + Qcond) > 1e-9*max(abs(Qother),1)
        if Qother > 0 && Qcond < 0
            bc.condenserScale = -Qother/Qcond;
            bc.q(cond) = bc.q(cond)*bc.condenserScale;
            warning(['Flux-only boundary conditions: the condenser removes %.6g W but %.6g W are put in; ', ...
                     'the condenser heat flux is scaled by %.6g so that a steady state exists.'], ...
                     -Qcond, Qother, bc.condenserScale);
        else
            error(['Flux-only boundary conditions without a net heat input and removal (input %.6g W, ', ...
                   'condenser %.6g W): no steady state exists.'], Qother, Qcond);
        end
    end
end
end

function checkPositive(v, name)
if ~isscalar(v) || ~isfinite(v) || v <= 0
    error('The %s must be a positive number.', name);
end
end
