function assertFiniteField(x,name)
%ASSERTFINITEFIELD Stop on NaN/Inf.
if any(~isfinite(x(:)))
    error('Non-finite values detected in %s.',name);
end
end
