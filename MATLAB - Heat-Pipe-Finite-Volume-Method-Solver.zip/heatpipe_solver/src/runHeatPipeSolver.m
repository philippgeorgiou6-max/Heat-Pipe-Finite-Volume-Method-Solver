function results = runHeatPipeSolver(caseOverrides,gridPreset,numOverrides)
%RUNHEATPIPESOLVER Single-evaporator heat pipe: set up, solve, export.
%
%   results = runHeatPipeSolver()                                   default case and grid
%   results = runHeatPipeSolver(caseOverrides,gridPreset,numOverrides)
%       caseOverrides : struct, see inputCleanHeatPipeCase (e.g. evaporatorPowers_W, T_o_C)
%       gridPreset    : 'default' | 'paper50' | 'paper100'
%       numOverrides  : struct, see inputCleanHeatPipeNumerics

if nargin < 1 || isempty(caseOverrides), caseOverrides = struct(); end
if nargin < 2 || isempty(gridPreset), gridPreset = 'default'; end
if nargin < 3 || isempty(numOverrides), numOverrides = struct(); end

% ---- pre-processing
caseData = inputCleanHeatPipeCase(caseOverrides);
mat = inputCleanHeatPipeMaterials(caseData);
num = inputCleanHeatPipeNumerics(gridPreset, numOverrides);
mesh = createCleanMesh(caseData, num);
mesh = tagCleanRegionsAndBoundaries(mesh, caseData);
if num.verbose
    printCleanConfiguration(caseData, mat, num, mesh);
end

% ---- simulation
results = runPaperModelSolver(caseData, mat, num, mesh);
results.monitor = runMonitor('get');   % Q_in, Q_out, R_total per outer iteration

% ---- post-processing
results.profiles = computeDerivedProfiles(results);
if num.saveResults
    exportResults(results, num.resultsFolder);   % replaces the previous results
    if num.verbose
        fprintf('Results written to %s\n', num.resultsFolder);
    end
end
if num.showFigures && canShowFigures()
    plotHeatPipeResults(results);
end
end
