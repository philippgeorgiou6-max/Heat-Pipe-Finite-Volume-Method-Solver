function mesh = tagCleanRegionsAndBoundaries(mesh,caseData)
%TAGCLEANREGIONSANDBOUNDARIES Material regions, axial zones and heater columns.
%
% mesh.region(i,j)      : 1 vapor, 2 wick, 3 wall (caseData.regionIDs)
% mesh.heaterIndex(j)   : k if column j lies under heater (evaporator) k, else 0
% mesh.isCondenser(j)   : true under the condenser
% mesh.zone(j)          : 1 unheated start, 2 heater, 3 heater gap (none for one heater),
%                         4 transport, 5 condenser, 6 unheated end
ids = caseData.regionIDs;
reg = zeros(mesh.Nr, mesh.Nz);
reg(mesh.rowsVapor,:) = ids.vapor;
reg(mesh.rowsWick,:)  = ids.wick;
reg(mesh.rowsWall,:)  = ids.wall;
mesh.region = reg;

z = mesh.z_centers;
seg = caseData.heaterSegments_m;
mesh.heaterIndex = zeros(1, mesh.Nz);
for k = 1:size(seg,1)
    mesh.heaterIndex(z > seg(k,1) & z < seg(k,2)) = k;
end
mesh.isCondenser = z > caseData.condenserStart & z < caseData.condenserEnd;

zone = zeros(1, mesh.Nz);
zone(z < seg(1,1)) = 1;
zone(mesh.heaterIndex > 0) = 2;
zone(z > seg(1,1) & z < caseData.evaporatorSectionEnd & mesh.heaterIndex == 0) = 3;
zone(z > caseData.transportStart & z < caseData.transportEnd) = 4;
zone(mesh.isCondenser) = 5;
zone(z > caseData.condenserEnd) = 6;
if any(zone == 0)
    error('tagCleanRegionsAndBoundaries: an axial column was not assigned to a zone.');
end
mesh.zone = zone;
mesh.zoneNames = {'unheated start','heater','heater gap','transport','condenser','unheated end'};

mesh.iVaporInterfaceRow = mesh.Nv;        % last vapor row (r < a)
mesh.iWickInterfaceRow  = mesh.Nv + 1;    % first wick row (r > a)
mesh.iWickWallRow       = mesh.Nv + mesh.Nw;
mesh.A_interface = mesh.Ar(mesh.Nv+1, :);  % 2*pi*a*dz
mesh.A_outer     = mesh.Ar(end, :);        % 2*pi*c*dz
end
