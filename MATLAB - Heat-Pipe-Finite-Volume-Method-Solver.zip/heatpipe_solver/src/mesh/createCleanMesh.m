function mesh = createCleanMesh(caseData,num)
%CREATECLEANMESH Block-structured axisymmetric finite-volume mesh.
%
% Radial blocks: vapor [0,a], wick [a,b], wall [b,c] with num.NvaporR,
% num.NwickR, num.NwallR cells ('uniform' or 'cosine' spacing per block).
% Axial: every section/heater edge in caseData.axialBreakpoints_m is a cell
% face. Cells per axial segment come from num.axialMaxCellSize_m (with
% num.axialMinCellsPerSegment) or from a total count num.axialCellsTotal
% (paper grids 50 and 100), allocated in proportion to segment length.

a = caseData.R_vapor; b = caseData.R_wick; c = caseData.R_outer;
rv = spacedNodes(0, a, num.NvaporR, num.radialSpacing{1});
rw = spacedNodes(a, b, num.NwickR,  num.radialSpacing{2});
rs = spacedNodes(b, c, num.NwallR,  num.radialSpacing{3});
r_nodes = [rv, rw(2:end), rs(2:end)];

zb = caseData.axialBreakpoints_m(:)';
counts = axialSegmentCounts(diff(zb), num);
z_nodes = zb(1);
for s = 1:numel(counts)
    seg = linspace(zb(s), zb(s+1), counts(s)+1);
    z_nodes = [z_nodes, seg(2:end)]; %#ok<AGROW>
end
z_nodes(end) = zb(end);

Nr = numel(r_nodes)-1; Nz = numel(z_nodes)-1;
r_centers = 0.5*(r_nodes(1:end-1) + r_nodes(2:end));
z_centers = 0.5*(z_nodes(1:end-1) + z_nodes(2:end));
dr = diff(r_nodes); dz = diff(z_nodes);
if any(dr <= 0) || any(dz <= 0)
    error('createCleanMesh: non-positive cell size.');
end

mesh.type = 'block-structured 2D axisymmetric finite-volume mesh (faces aligned with all section edges)';
mesh.gridPreset = num.gridPreset;
mesh.Nr = Nr; mesh.Nz = Nz; mesh.Ncells = Nr*Nz;
mesh.Nv = num.NvaporR; mesh.Nw = num.NwickR; mesh.Ns = num.NwallR;
mesh.rowsVapor = 1:mesh.Nv;
mesh.rowsWick  = mesh.Nv + (1:mesh.Nw);
mesh.rowsWall  = mesh.Nv + mesh.Nw + (1:mesh.Ns);
mesh.r_nodes = r_nodes; mesh.r_centers = r_centers; mesh.dr = dr;
mesh.z_nodes = z_nodes; mesh.z_centers = z_centers; mesh.dz = dz;
mesh.axialSegmentCounts = counts;
[mesh.Rc, mesh.Zc] = ndgrid(r_centers, z_centers);
mesh.Az  = pi*(r_nodes(2:end).^2 - r_nodes(1:end-1).^2)';   % Nr x 1, axial face area per row
mesh.vol = mesh.Az * dz;                                     % Nr x Nz
mesh.Ar  = 2*pi*r_nodes(:) * dz;                             % (Nr+1) x Nz, radial face areas
mesh.cellIndex = reshape(1:mesh.Ncells, Nr, Nz);
mesh.minDr = min(dr); mesh.maxDr = max(dr); mesh.minDz = min(dz); mesh.maxDz = max(dz);

if ~isfield(num,'verbose') || num.verbose
    fprintf('Mesh (%s): %d axial x (%d vapor + %d wick + %d wall) = %d cells; dr [%.3g, %.3g] mm, dz [%.3g, %.3g] mm\n', ...
        num.gridPreset, Nz, mesh.Nv, mesh.Nw, mesh.Ns, mesh.Ncells, 1e3*mesh.minDr, 1e3*mesh.maxDr, 1e3*mesh.minDz, 1e3*mesh.maxDz);
end
end

function x = spacedNodes(x0, x1, n, spacing)
s = linspace(0,1,n+1);
switch lower(spacing)
    case 'uniform'
        x = x0 + (x1-x0)*s;
    case 'cosine'
        x = x0 + (x1-x0)*(0.5 - 0.5*cos(pi*s));   % clustered toward both ends
    otherwise
        error('Unknown radial spacing "%s".', spacing);
end
x(1) = x0; x(end) = x1;
end

function counts = axialSegmentCounts(L, num)
nmin = num.axialMinCellsPerSegment;
if ~isempty(num.axialMaxCellSize_m)
    counts = max(nmin, ceil(L/num.axialMaxCellSize_m - 1e-9));
    return;
end
N = num.axialCellsTotal;
if N < nmin*numel(L)
    error('axialCellsTotal = %d is too small for %d segments.', N, numel(L));
end
ideal = N*L/sum(L);
counts = max(nmin, round(ideal));
% Largest-remainder correction to hit the exact total.
while sum(counts) > N
    cand = find(counts > nmin);
    [~,k] = max(counts(cand) - ideal(cand));
    counts(cand(k)) = counts(cand(k)) - 1;
end
while sum(counts) < N
    [~,k] = max(ideal - counts);
    counts(k) = counts(k) + 1;
end
end
