function caseData = inputCleanHeatPipeCase(overrides)
%INPUTCLEANHEATPIPECASE Geometry, evaporator and BCs of the single-evaporator heat pipe.
%
%   caseData = inputCleanHeatPipeCase()     -> default case (97 W, T_o = 75.7 degC)
%   caseData = inputCleanHeatPipeCase(s)    -> with field overrides, e.g.
%       s.evaporatorPowers_W = 150; s.T_o_C = 75; s.L_cond = 0.25;
%       s.condenserBCType = 'convection'; s.condenserH_W_m2K = 2000;
%
%   Pipe, wick and physical model of A. Faghri and M. Buchko, "Experimental and
%   Numerical Analysis of Low-Temperature Heat Pipes With Multiple Heat
%   Sources", ASME J. Heat Transfer 113 (1991) 728-733, reduced to a single
%   evaporator: one 63.5 mm heater at the position of the paper's heater 1,
%   followed by an adiabatic transport section up to the condenser.
%
%   Coordinates: z = 0 at the evaporator end cap, z = L_total at the
%   condenser end cap. End caps are boundaries (Eqs. 11, 12, 18), not solid
%   regions. All positions that depend on the lengths and radii below are
%   derived after the overrides are applied (deriveGeometry).

if nargin < 1 || isempty(overrides), overrides = struct(); end

caseData.paperReference = ['A. Faghri and M. Buchko, "Experimental and Numerical Analysis of ', ...
    'Low-Temperature Heat Pipes With Multiple Heat Sources", ASME J. Heat Transfer 113 (1991) 728-733'];
caseData.coordinateSystem = '2D axisymmetric r-z';
caseData.caseId = 'single';
caseData.name = 'Single-evaporator heat pipe (Faghri and Buchko 1991 model)';

% ---------------------------------------------------------------- geometry
% Paper Table 1: o.d. 25.4 mm, i.d. 22.0 mm, screen wick thickness 0.712 mm,
% vapor core diameter 20.5 mm, length 1000 mm. The listed diameters imply a
% 0.75 mm wick, which does not match the listed 0.712 mm. The wick thickness
% sets the dominant (wick) thermal resistance; with 0.712 mm the model
% reproduces the paper's numerical wall temperatures of Fig. 4 (peak and
% condenser within about 0.1-0.4 K), with 0.75 mm the peak is about 0.5 K
% higher. Default is therefore the Table 1 thickness.
caseData.L_total = 1.000;
caseData.R_outer = 0.5*25.4e-3;   % c
caseData.R_wick  = 0.5*22.0e-3;   % b (container inner radius = outer wick radius)
caseData.R_vapor = 0.5*20.5e-3;   % a (vapor-liquid interface), used with 'diameters'
% 'table1'    : a = b - 0.712 mm, wick thickness of Table 1 (default; vapor core
%               diameter 20.576 mm)
% 'diameters' : a = R_vapor as given (10.25 mm from the 20.5 mm vapor core
%               diameter; 0.75 mm wick)
% An explicit override of R_vapor (without wickThicknessSource) is used as given.
caseData.wickThicknessSource = 'table1';
caseData.tableWickThickness_m = 0.712e-3;

% Axial layout: unheated start | evaporator | adiabatic transport |
% condenser | unheated end. Default: 20 | 63.5 | 596.5 | 300 | 20 mm,
% condenser at [0.680, 0.980] m as in the paper.
caseData.L_unheatedStart = 0.020;
caseData.heaterLength    = 0.0635;
caseData.nHeaters        = 1;
caseData.L_cond          = 0.300;
caseData.L_unheatedEnd   = 0.020;

caseData.regionIDs.vapor = 1;
caseData.regionIDs.wick  = 2;
caseData.regionIDs.wall  = 3;
caseData.regionNames = {'vapor core','porous wick','solid wall'};

% ------------------------------------------------------------- wick screen
caseData.wickModel = 'screen';
caseData.screenWick.meshNumber_per_m = 1.97e3;   % 50 mesh (Table 1)
caseData.screenWick.wireDiameter_m   = 0.178e-3; % Table 1
caseData.screenWick.wraps            = 2;

% -------------------------------------------------------- operating point
% Operating (vapor) temperature T_o. With flux-only boundary conditions
% (power / heat flux on evaporator and condenser, adiabatic transport) it
% fixes the temperature level (Eq. 19 anchor). As soon as any zone has a
% temperature or convection BC, T_o is solved for; this value is then the
% start value of that iteration.
caseData.T_o_K = 75.7 + 273.15;
caseData.T_o_source = 'input';
% true : water properties (viscosities, conductivities, densities, c_p,
%        surface tension, k_eff) belong to T_o; when T_o is solved for they
%        follow it during the iteration (default)
% false: fluid properties stay at the values evaluated at the input T_o
caseData.fluidPropertiesFollowT_o = true;

% ------------------------------------------------------ boundary conditions
% The paper's model (and the validated case) uses heat fluxes only: 'power'
% at the evaporator, 'paperEq20UniformHeatFlux' at the condenser, adiabatic
% transport section. All other types are extensions of the paper's model,
% checked for convergence and energy balance but not validated against
% measurements.
% Every zone of the outer wall (r = c) gets ONE type. Each parameter is read
% only by the type named in its comment. Functions are MATLAB expressions in
%   z [m] (axial position), s [m] (distance from the zone start), L [m] (zone length),
% e.g. '85 + 3*sin(pi*s/L)'. Temperatures in degC, heat fluxes in W/m^2.
% The unheated end sections are always adiabatic.
%
% Evaporator types:
%   'power'               : uniform heat flux P/A (paper Eq. 20, default)
%   'temperature'         : uniform wall temperature
%   'temperatureFunction' : wall temperature T(z) [degC]
%   'convection'          : q = h (T_inf - T_wall)
%   'heatFluxFunction'    : heat flux q(z) [W/m^2], positive = into the pipe
caseData.evaporatorBCType = 'power';
caseData.evaporatorPowers_W = 97;                          % 'power'
caseData.evaporatorTemperature_K = 85.0 + 273.15;          % 'temperature'
caseData.evaporatorTemperatureFunction = '85 + 2*sin(pi*s/L)';  % 'temperatureFunction' [degC]
caseData.evaporatorH_W_m2K = 1000.0;                       % 'convection'
caseData.evaporatorTinf_K = 100.0 + 273.15;                % 'convection'
caseData.evaporatorHeatFluxFunction = '2e4*sin(pi*s/L)';   % 'heatFluxFunction' [W/m^2]
%
% Condenser types:
%   'paperEq20UniformHeatFlux' : removes the evaporator input as a uniform heat
%                                flux (paper Eq. 20, validated default)
%   'power'                    : removed power, uniform flux
%   'heatFlux'                 : uniform removal flux [W/m^2]
%   'temperature'              : uniform wall temperature
%   'temperatureFunction'      : wall temperature T(z) [degC]
%   'convection'               : q = h (T_wall - T_inf)
%   'heatFluxFunction'         : removal flux q(z) [W/m^2], positive = out of the pipe
% With flux-only boundary conditions the removed heat must equal the input
% (no steady state otherwise); a prescribed condenser flux is then scaled to
% the input and a warning is issued.
caseData.condenserBCType  = 'paperEq20UniformHeatFlux';
caseData.totalHeatOutput_W = NaN;                     % 'power' (removed power; NaN = evaporator input)
caseData.condenserHeatFlux_W_m2 = NaN;                % 'heatFlux' (positive = removed)
caseData.condenserWallTemperature_K = 71.0 + 273.15;  % 'temperature'
caseData.condenserTemperatureFunction = '71 + 1*cos(pi*s/L)';  % 'temperatureFunction' [degC]
caseData.condenserH_W_m2K = 5000.0;                   % 'convection'
caseData.condenserTinf_K  = 71.0 + 273.15;            % 'convection'
caseData.condenserHeatFluxFunction = '4300';          % 'heatFluxFunction' [W/m^2]
%
% Transport section types: 'adiabatic' (default) or 'convection'.
caseData.transportBCType = 'adiabatic';
caseData.transportH_W_m2K = 10.0;                     % 'convection'
caseData.transportTinf_K = 25.0 + 273.15;             % 'convection'

% Operating-state anchor (T_o, p_o) of Eq. (19). The vapor pressure level is
% pinned so that the area-mean interface pressure equals p_o = p_sat(T_o)
% ('meanInterface') or so that p_v(z = pressureReferencePoint_z, r = a) = p_o
% ('point'). Liquid pressure reference ("wet point"): p_l = p_v at r = a at
% the far end of the condenser (liquidPressureReference_z, derived below).
caseData.pressureReference = 'meanInterface';
caseData.pressureReferencePoint_z = 0.0;

caseData.wallConductivity_W_mK = 339.0;  % UNS C12200 copper
caseData.screenSolidConductivity_W_mK = 390.0;  % copper screen wire

caseData.initialTemperature_K = caseData.T_o_K;   % initial temperature field
caseData.minimumTemperature_K = 283.15;
caseData.maximumTemperature_K = 423.15;

% ------------------------------------------------------------- overrides
caseData = applyOverrides(caseData, overrides);
caseData = deriveGeometry(caseData, overrides);
caseData.evaporatorBCType = normalizeOuterBCType(caseData.evaporatorBCType);
caseData.condenserBCType = normalizeOuterBCType(caseData.condenserBCType);
caseData.transportBCType = normalizeOuterBCType(caseData.transportBCType);
if strcmp(caseData.evaporatorBCType, 'power')
    if ~isscalar(caseData.evaporatorPowers_W) || ~isfinite(caseData.evaporatorPowers_W) || caseData.evaporatorPowers_W < 0
        error('evaporatorPowers_W must be one finite, non-negative value (single evaporator).');
    end
    caseData.totalHeatInput_W = caseData.evaporatorPowers_W;
else
    caseData.totalHeatInput_W = NaN;   % follows from the solution
end
caseData.T_o_C = caseData.T_o_K - 273.15;
end

% ========================================================================
function caseData = applyOverrides(caseData, s)
names = fieldnames(s);
for k = 1:numel(names)
    f = names{k};
    switch f
        case 'T_o_C'
            caseData.T_o_K = s.T_o_C + 273.15;
            caseData.T_o_source = 'user override';
        case 'T_o_K'
            caseData.T_o_K = s.T_o_K;
            caseData.T_o_source = 'user override';
        case 'initialTemperature_C'
            caseData.initialTemperature_K = s.initialTemperature_C + 273.15;
        otherwise
            caseData.(f) = s.(f);
    end
end
% the initial field follows T_o unless it was set explicitly
if (isfield(s,'T_o_C') || isfield(s,'T_o_K')) && ~isfield(s,'initialTemperature_K') && ~isfield(s,'initialTemperature_C')
    caseData.initialTemperature_K = caseData.T_o_K;
end
end

function caseData = deriveGeometry(caseData, overrides)
% Radii, thicknesses and axial positions that depend on the inputs.
if isfield(overrides,'R_vapor') && ~isfield(overrides,'wickThicknessSource')
    caseData.wickThicknessSource = 'diameters';   % an explicit vapor core radius is used as given
end
switch lower(caseData.wickThicknessSource)
    case 'diameters'
        % R_vapor as set (or overridden directly)
    case 'table1'
        caseData.R_vapor = caseData.R_wick - caseData.tableWickThickness_m;
    otherwise
        error('wickThicknessSource must be ''diameters'' or ''table1''.');
end
if ~(caseData.R_vapor > 0 && caseData.R_vapor < caseData.R_wick && caseData.R_wick < caseData.R_outer)
    error('Geometry: the radii must satisfy 0 < vapor core radius < wick outer radius < wall outer radius.');
end
caseData.t_wall = caseData.R_outer - caseData.R_wick;    % 1.7 mm by default
caseData.t_wick = caseData.R_wick - caseData.R_vapor;    % 0.712 mm by default (Table 1)

lengths = [caseData.L_unheatedStart, caseData.heaterLength, caseData.L_cond, caseData.L_unheatedEnd];
if any(~isfinite(lengths)) || any(lengths < 0) || caseData.heaterLength <= 0 || caseData.L_cond <= 0
    error('Geometry: evaporator and condenser lengths must be > 0, unheated lengths >= 0.');
end
caseData.heaterSegments_m = [caseData.L_unheatedStart, caseData.L_unheatedStart + caseData.heaterLength];
caseData.evaporatorSectionEnd = caseData.heaterSegments_m(end,2);
caseData.condenserEnd   = caseData.L_total - caseData.L_unheatedEnd;
caseData.condenserStart = caseData.condenserEnd - caseData.L_cond;
caseData.transportStart = caseData.evaporatorSectionEnd;
caseData.transportEnd   = caseData.condenserStart;
caseData.L_transport    = caseData.transportEnd - caseData.transportStart;
if caseData.L_transport <= 0
    error(['Geometry: the sections do not fit into the total length ', ...
           '(transport section length %.4g m must be > 0).'], caseData.L_transport);
end
caseData.axialBreakpoints_m = unique([0, reshape(caseData.heaterSegments_m',1,[]), ...
    caseData.condenserStart, caseData.condenserEnd, caseData.L_total]);
if ~isfield(overrides,'liquidPressureReference_z')
    caseData.liquidPressureReference_z = caseData.condenserEnd;
end
end
