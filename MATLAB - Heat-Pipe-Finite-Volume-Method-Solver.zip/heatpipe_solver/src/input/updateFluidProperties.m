function mat = updateFluidProperties(mat, T)
%UPDATEFLUIDPROPERTIES Water properties of vapor and liquid at the temperature T [K].
%
%   mat = updateFluidProperties(mat, T)
%
% Used when mat.fluidPropertiesFollowT_o is true (default): the fluid
% properties are those of saturated water at the operating temperature T_o,
% also when T_o is solved for (temperature or convection BCs), where the
% solver calls this function whenever T_o changes.
% Re-evaluated: vapor mu, k, c_p and reference density p_sat/(R T); liquid
% rho, mu, k, c_p and surface tension; h_fg and p_sat; the wick effective
% conductivity (paper Eq. 9, unless it is user-defined) and the Darcy
% coefficient mu_l*eps/K of Eqs. (5)-(6).
% Unchanged: the gas constant, the wick structure (porosity, permeability,
% capillary radius, solid conductivity) and the wall.

w = waterThermoProperties(T);
mat.T_eval_K = T;
mat.vapor.mu = w.vapor.mu;
mat.vapor.k  = w.vapor.k;
mat.vapor.cp = w.vapor.cp;
mat.liquid.rho = w.liquid.rho;
mat.liquid.mu  = w.liquid.mu;
mat.liquid.k   = w.liquid.k;
mat.liquid.cp  = w.liquid.cp;
mat.liquid.surfaceTension_N_m = w.liquid.surfaceTension_N_m;
mat.phase.hfg = w.phase.hfg;
mat.phase.p_o = waterSaturationPressure(T);
mat.vapor.rho_o = mat.phase.p_o/(mat.vapor.R*T);

epsW = mat.wick.porosity;
if ~(isfield(mat.wick, 'k_eff_userDefined') && mat.wick.k_eff_userDefined)
    kl = mat.liquid.k; ks = mat.wick.k_s;
    mat.wick.k_eff = kl*((kl + ks) - (1 - epsW)*(kl - ks)) / ((kl + ks) + (1 - epsW)*(kl - ks));  % Eq. (9)
end
mat.wick.darcyCoefficient = mat.liquid.mu*epsW/mat.wick.permeability_m2;   % mu*eps/K in Eqs. (5)-(6)
end
