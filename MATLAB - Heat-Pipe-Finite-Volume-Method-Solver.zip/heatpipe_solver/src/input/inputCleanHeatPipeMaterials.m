function mat = inputCleanHeatPipeMaterials(caseData)
%INPUTCLEANHEATPIPEMATERIALS Material data (copper-water heat pipe of Faghri & Buchko 1991).
%
% Fluid properties are evaluated at the operating (interface) temperature T_o,
% consistent with the paper's subscript "o" = properties at the liquid-vapor
% interface. The paper does not list property values, wick porosity,
% permeability or the wall conductivity; the closures below are used.
%
% mat.fluidPropertiesFollowT_o (default true, caseData.fluidPropertiesFollowT_o):
% when T_o is solved for (temperature or convection BCs), the solver
% re-evaluates the water properties at the current T_o (updateFluidProperties),
% so they belong to the converged operating temperature. false keeps the
% fluid properties fixed at the values given here or by the user.

To = caseData.T_o_K;
w = waterThermoProperties(To);
mat.propertyEvaluation = 'constant per region, evaluated at T_o';
mat.T_eval_K = To;
mat.fluidPropertiesFollowT_o = true;
if isfield(caseData,'fluidPropertiesFollowT_o') && ~isempty(caseData.fluidPropertiesFollowT_o)
    mat.fluidPropertiesFollowT_o = logical(caseData.fluidPropertiesFollowT_o);
end

% ---- water (saturated, at T_o) -------------------------------------------
mat.liquid.name = 'liquid water (saturated, at T_o)';
mat.liquid.rho = w.liquid.rho;
mat.liquid.mu  = w.liquid.mu;
mat.liquid.k   = w.liquid.k;
mat.liquid.cp  = w.liquid.cp;
mat.liquid.surfaceTension_N_m = w.liquid.surfaceTension_N_m;
mat.liquid.contactAngle_deg = 0.0;   % capillary pressure limit (post-processing)

mat.vapor.name = 'water vapor (ideal gas, Eq. p = rho R T)';
mat.vapor.R  = w.vapor.R;
mat.vapor.mu = w.vapor.mu;
mat.vapor.k  = w.vapor.k;
mat.vapor.cp = w.vapor.cp;
mat.vapor.rho_o = waterSaturationPressure(To)/(w.vapor.R*To);

mat.phase.hfg = w.phase.hfg;   % h_fg(T_o), used in Eq. (19); Eq. (16) uses h_fg(T_i)
mat.phase.p_o = waterSaturationPressure(To);

% ---- wall: UNS C12200 copper (paper) ------------------------------------
mat.wall.name = 'UNS C12200 copper (phosphorus-deoxidized, high residual P)';
mat.wall.k   = caseData.wallConductivity_W_mK;
mat.wall.rho = 8940;
mat.wall.cp  = 385;

% ---- wick: 2 wraps of 50-mesh copper screen, Chi (1976) correlations ------
N = caseData.screenWick.meshNumber_per_m;
d = caseData.screenWick.wireDiameter_m;
mat.wick.name = 'two wraps of 50-mesh copper screen, saturated with water';
mat.wick.model = caseData.wickModel;
mat.wick.crimpingFactor = 1.05;
mat.wick.porosity = 1.0 - mat.wick.crimpingFactor*pi*N*d/4.0;
mat.wick.porosity_model = 'Chi (1976): eps = 1 - 1.05*pi*N*d/4';
mat.wick.permeability_m2 = d^2*mat.wick.porosity^3/(122.0*(1.0 - mat.wick.porosity)^2);
mat.wick.permeability_model = 'Chi (1976) screen wicks: K = d^2 eps^3 / (122 (1-eps)^2)';
mat.wick.capillaryRadius_m = 1.0/(2.0*N);
mat.wick.capillaryRadius_model = 'Chi (1976) screen wicks: r_c = 1/(2N)';
mat.wick.effectivePoreRadius_m = mat.wick.capillaryRadius_m;
mat.wick.k_s = caseData.screenSolidConductivity_W_mK;
epsW = mat.wick.porosity; kl = mat.liquid.k; ks = mat.wick.k_s;
mat.wick.k_eff = kl*((kl + ks) - (1 - epsW)*(kl - ks)) / ((kl + ks) + (1 - epsW)*(kl - ks));  % Eq. (9)
mat.wick.k_eff_model = 'Paper Eq. (9) (Chi 1976) with k_l(T_o) and copper k_s';
mat.wick.k_eff_userDefined = false;
mat.wick.darcyCoefficient = mat.liquid.mu*epsW/mat.wick.permeability_m2;  % mu*eps/K in Eqs. (5)-(6)
mat.wick.brinkmanLength_m = sqrt(mat.wick.permeability_m2/epsW);
mat.wick.computationalThickness_m = caseData.t_wick;
end
