function mat = applyMaterialInputs(mat, in)
%APPLYMATERIALINPUTS Set user material properties and recompute derived values.
%
%   mat = applyMaterialInputs(mat, in)
%   mat : material structure (inputCleanHeatPipeMaterials)
%   in  : struct with any of the fields
%         fluidPropertiesFollowT_o          true: water properties at the operating
%                                           temperature T_o (input or solved); the
%                                           fluid values below are then not used.
%                                           false: the fluid values below are used
%                                           as constants
%         T_eval_K                          property evaluation temperature [K]
%                                           (start value when following T_o)
%         vapor_mu, vapor_k, vapor_cp, vapor_R
%         liquid_rho, liquid_mu, liquid_k, liquid_cp, liquid_sigma
%         wick_porosity, wick_permeability, wick_ks, wick_rc,
%         wick_keff (NaN -> paper Eq. 9 from k_l, k_s and the porosity)
%         wall_k, wall_rho, wall_cp, wall_name
% Derived: vapor density at T_eval (ideal gas at p_sat), Darcy coefficient
% mu_l*eps/K, Brinkman length, effective wick conductivity (Eq. 9).
% Saturation pressure and latent heat follow the built-in water correlations.
set = @(f) isfield(in, f) && ~isempty(in.(f));

% ---- wick structure
if set('wick_porosity')
    if in.wick_porosity <= 0 || in.wick_porosity >= 1
        error('The wick porosity must be between 0 and 1.');
    end
    mat.wick.porosity = in.wick_porosity;
    mat.wick.porosity_model = 'user input';
end
if set('wick_permeability'), mat.wick.permeability_m2 = in.wick_permeability; mat.wick.permeability_model = 'user input'; end
if set('wick_ks'), mat.wick.k_s = in.wick_ks; end
if set('wick_rc')
    mat.wick.capillaryRadius_m = in.wick_rc;
    mat.wick.effectivePoreRadius_m = in.wick_rc;
    mat.wick.capillaryRadius_model = 'user input';
end
if set('wick_keff') && isfinite(in.wick_keff)
    mat.wick.k_eff = in.wick_keff;
    mat.wick.k_eff_model = 'user input';
    mat.wick.k_eff_userDefined = true;
else
    mat.wick.k_eff_model = 'Paper Eq. (9) (Chi 1976)';
    mat.wick.k_eff_userDefined = false;
end

% ---- working fluid
if set('vapor_R'), mat.vapor.R = in.vapor_R; end   % gas constant (not temperature dependent)
if set('fluidPropertiesFollowT_o'), mat.fluidPropertiesFollowT_o = logical(in.fluidPropertiesFollowT_o); end
if ~isfield(mat, 'fluidPropertiesFollowT_o'), mat.fluidPropertiesFollowT_o = true; end
Teval = mat.T_eval_K;
if set('T_eval_K'), Teval = in.T_eval_K; end
if mat.fluidPropertiesFollowT_o
    % water at Teval now; the solver re-evaluates it at T_o (input or solved)
    mat = updateFluidProperties(mat, Teval);
else
    mat.T_eval_K = Teval;
    w = waterThermoProperties(Teval);
    mat.phase.hfg = w.phase.hfg;
    mat.phase.p_o = waterSaturationPressure(Teval);
    if set('vapor_mu'), mat.vapor.mu = in.vapor_mu; end
    if set('vapor_k'),  mat.vapor.k  = in.vapor_k;  end
    if set('vapor_cp'), mat.vapor.cp = in.vapor_cp; end
    mat.vapor.rho_o = mat.phase.p_o/(mat.vapor.R*mat.T_eval_K);
    if set('liquid_rho'),   mat.liquid.rho = in.liquid_rho; end
    if set('liquid_mu'),    mat.liquid.mu  = in.liquid_mu;  end
    if set('liquid_k'),     mat.liquid.k   = in.liquid_k;   end
    if set('liquid_cp'),    mat.liquid.cp  = in.liquid_cp;  end
    if set('liquid_sigma'), mat.liquid.surfaceTension_N_m = in.liquid_sigma; end
end

% ---- derived wick values
epsW = mat.wick.porosity; kl = mat.liquid.k; ks = mat.wick.k_s;
if ~mat.wick.k_eff_userDefined
    mat.wick.k_eff = kl*((kl + ks) - (1 - epsW)*(kl - ks)) / ((kl + ks) + (1 - epsW)*(kl - ks));  % Eq. (9)
end
mat.wick.darcyCoefficient = mat.liquid.mu*epsW/mat.wick.permeability_m2;   % mu*eps/K in Eqs. (5)-(6)
mat.wick.brinkmanLength_m = sqrt(mat.wick.permeability_m2/epsW);

% ---- wall
if set('wall_k'),    mat.wall.k   = in.wall_k;   end
if set('wall_rho'),  mat.wall.rho = in.wall_rho; end
if set('wall_cp'),   mat.wall.cp  = in.wall_cp;  end
if set('wall_name'), mat.wall.name = in.wall_name; end
end
