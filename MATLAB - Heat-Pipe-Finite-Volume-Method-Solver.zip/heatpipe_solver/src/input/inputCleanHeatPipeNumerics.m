function num = inputCleanHeatPipeNumerics(gridPreset, overrides)
%INPUTCLEANHEATPIPENUMERICS Numerical settings.
%
%   num = inputCleanHeatPipeNumerics()            -> default grid
%   num = inputCleanHeatPipeNumerics('paper50')   -> paper grid 50 x (10+5+5)
%   num = inputCleanHeatPipeNumerics('paper100')  -> paper grid 100 x (20+5+10)
%   num = inputCleanHeatPipeNumerics(preset, s)   -> with field overrides
%
% Grid notation of the paper: axial x (radial vapor + radial wick + radial wall).

if nargin < 1 || isempty(gridPreset), gridPreset = 'default'; end
if nargin < 2 || isempty(overrides), overrides = struct(); end

% ------------------------------------------------------------------ grid
num.gridPreset = lower(gridPreset);
switch num.gridPreset
    case 'default'
        num.NvaporR = 24; num.NwickR = 16; num.NwallR = 8;
        num.radialSpacing = {'uniform','cosine','uniform'};  % vapor, wick, wall
        num.axialMaxCellSize_m = 3.0e-3;
        num.axialCellsTotal = [];
        num.axialMinCellsPerSegment = 4;
    case 'paper50'
        num.NvaporR = 10; num.NwickR = 5; num.NwallR = 5;
        num.radialSpacing = {'uniform','uniform','uniform'};
        num.axialMaxCellSize_m = [];
        num.axialCellsTotal = 50;
        num.axialMinCellsPerSegment = 2;
    case 'paper100'
        num.NvaporR = 20; num.NwickR = 5; num.NwallR = 10;
        num.radialSpacing = {'uniform','uniform','uniform'};
        num.axialMaxCellSize_m = [];
        num.axialCellsTotal = 100;
        num.axialMinCellsPerSegment = 2;
    otherwise
        error('Unknown grid preset "%s" (default, paper50, paper100).', gridPreset);
end

% ------------------------------------------------------- flow / coupling
num.pressureVelocityCoupling = 'SIMPLEC';  % 'SIMPLEC' or 'SIMPLE' (paper: SIMPLEST)
% Wick radial momentum: 'vector' = mu*(lap(v) - v/r^2), the radial component
% of the vector form Eq. (25) (default); 'printed' = Eq. (6) exactly as
% printed, without -v/r^2. The term is ~1e-5 of the wick momentum balance.
num.wickRadialMomentumForm = 'vector';
num.convectionScheme = 'hybrid';           % 'hybrid' (Spalding) or 'powerlaw'
num.alpha_u = 0.6;          % vapor momentum under-relaxation (w and v)
num.alpha_u_wick = 0.6;     % wick momentum under-relaxation
num.alpha_p = [];           % [] -> 1.0 for SIMPLEC, 0.3 for SIMPLE
num.alpha_T = 1.0;          % energy
num.alpha_mdot = 0.5;       % interface mass flux (Eq. 16)
num.innerFlowIterations = 5;     % SIMPLE iterations per outer (energy) iteration
num.maxOuterIterations = 4000;
num.startup = 'reduced';    % 'reduced' (conduction start-up) or 'paperOuterFlux' (paper's start-up)
num.startupIterations = 10; % outer iterations with the paper start-up assumption

% ------------------------------------------------------------ convergence
% The flow and energy residuals are also re-evaluated on the final fields
% (evaluateFinalResiduals); the run counts as converged only if those pass too.
num.tolMass = 1.0e-6;          % sum|cell mass residual| / total evaporation rate (paper: <= 1e-6)
num.tolMomentum = 1.0e-6;      % normalized momentum residuals
num.tolTemperature_K = 1.0e-6; % max |dT| per outer iteration
num.tolEnergyResidual = 1.0e-6;   % sum|A T - b| / heater input, final fields
num.tolInterfaceClosure = 1.0e-6; % net Eq. (16) interface mass flow before the global correction / evaporation
num.tolMdotChange = 1.0e-6;    % max |change of the applied interface mass flux| / max |m''| per outer iteration
num.tolEnergy = 1.0e-6;        % |Qin - Qout| / Qin; only used with convective / temperature condenser BCs
                               % (with prescribed fluxes it is fixed by the input)

% ---------------------------------------------------------------- output
num.verbose = true;
num.printEvery = 50;
num.saveResults = true;     % write the results folder at the end (PDF diagrams, TXT data, MAT)
num.showFigures = true;     % open every diagram in its own window at the end (needs a display)
num.livePlots = true;       % live diagnostics during the iteration (needs a display)
num.livePlotEvery = 5;      % outer iterations between live updates
num.resultsFolder = 'heatpipe_results';   % replaced by every new run
num.stopOnNonFinite = true;

names = fieldnames(overrides);
for k = 1:numel(names)
    num.(names{k}) = overrides.(names{k});
end
if isempty(num.alpha_p)
    if strcmpi(num.pressureVelocityCoupling,'SIMPLE'), num.alpha_p = 0.3; else, num.alpha_p = 1.0; end
end
end
