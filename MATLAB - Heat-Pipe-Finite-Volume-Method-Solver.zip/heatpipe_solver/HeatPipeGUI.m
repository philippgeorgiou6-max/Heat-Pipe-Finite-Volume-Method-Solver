function fig = HeatPipeGUI()
%HEATPIPEGUI Graphical user interface of the heat-pipe CFD solver.
%
%   HeatPipeGUI   opens the GUI. The simulation is set up in six steps:
%     1 Geometry            dimensions, "Define geometry" draws the pipe
%     2 Boundary conditions evaporator, transport section and condenser
%     3 Mesh                "Start meshing" builds and draws the mesh
%     4 Materials           vapor core, wick (with liquid) and wall
%     5 Numerics            coupling, schemes, under-relaxation and the
%                           convergence criteria
%     6 Solver              initial temperature, start/stop, live plots
%                           and "Save results"
%   Results are saved to ./heatpipe_results (replaced on every save): all
%   diagrams as PDF, the data of every plot as TXT, and a MAT file.
%
%   Physical model: A. Faghri and M. Buchko, ASME J. Heat Transfer 113 (1991)
%   728-733, with a single evaporator.

root = fileparts(mfilename('fullpath'));
addpath(genpath(fullfile(root, 'src')));

S = struct();
S.caseOverrides = struct();
S.caseData = inputCleanHeatPipeCase();
S.num = inputCleanHeatPipeNumerics('default', struct('verbose', false));
S.mat = inputCleanHeatPipeMaterials(S.caseData);
S.mesh = [];
S.results = [];
S.step = 1;
S.maxStep = 1;
S.ok = struct('geometry', false, 'bc', false, 'mesh', false, 'materials', false, 'numerics', false);
S.materialsLoaded = false;

scr = get(0, 'ScreenSize');
W = min(1500, max(1000, scr(3) - 60)); H = min(900, max(650, scr(4) - 110));
fig = figure('Name', 'Heat pipe CFD  -  Faghri & Buchko (1991) model', 'NumberTitle', 'off', ...
    'MenuBar', 'none', 'ToolBar', 'figure', 'Color', [0.94 0.94 0.94], 'Units', 'pixels', ...
    'Position', [30, max(30, scr(4) - H - 70), W, H], 'CloseRequestFcn', @(src, evt) onClose(src));
setappdata(fig, 'running', false);
setappdata(fig, 'stopRequested', false);

h = struct();
h.title = uicontrol(fig, 'Style', 'text', 'Units', 'normalized', 'Position', [0.01 0.955 0.98 0.035], ...
    'String', 'Heat pipe CFD  -  2D axisymmetric conjugate model of Faghri & Buchko (1991), single evaporator', ...
    'FontSize', 13, 'FontWeight', 'bold', 'HorizontalAlignment', 'left', 'BackgroundColor', [0.94 0.94 0.94]);
stepNames = {'1  Geometry', '2  Boundary conditions', '3  Mesh', '4  Materials', '5  Numerics', ...
             '6  Solver & results'};
fsStep = max(9, min(11, floor(0.158*W/16)));   % smaller font in narrow windows
for k = 1:6
    h.stepButton(k) = uicontrol(fig, 'Style', 'pushbutton', 'Units', 'normalized', ...
        'Position', [0.01 + (k-1)*0.1635, 0.905, 0.158, 0.042], 'String', stepNames{k}, 'FontSize', fsStep, ...
        'Callback', @(src, evt) goToStep(fig, k));
end
for k = 1:6
    h.page(k) = uipanel('Parent', fig, 'Units', 'normalized', 'Position', [0.01 0.065 0.98 0.83], ...
        'BorderType', 'line', 'Visible', 'off');
end
h.status = uicontrol(fig, 'Style', 'text', 'Units', 'normalized', 'Position', [0.01 0.012 0.70 0.04], ...
    'String', '', 'HorizontalAlignment', 'left', 'FontSize', 10, 'BackgroundColor', [0.94 0.94 0.94]);
h.back = uicontrol(fig, 'Style', 'pushbutton', 'Units', 'normalized', 'Position', [0.725 0.012 0.12 0.045], ...
    'String', '<  Back', 'FontSize', 11, 'Callback', @(src, evt) goBack(fig));
h.next = uicontrol(fig, 'Style', 'pushbutton', 'Units', 'normalized', 'Position', [0.855 0.012 0.135 0.045], ...
    'String', 'Next step  >', 'FontSize', 11, 'FontWeight', 'bold', 'Callback', @(src, evt) goNext(fig));
S.h = h;
guidata(fig, S);

buildGeometryPage(fig);
buildBCPage(fig);
buildMeshPage(fig);
buildMaterialsPage(fig);
buildNumericsPage(fig);
buildSolverPage(fig);
showStep(fig, 1);
status(fig, 'Step 1: check the dimensions and press "Define geometry".');
end

% ========================================================================
%                              NAVIGATION
% ========================================================================
function showStep(fig, k)
S = guidata(fig);
S.step = k;
for j = 1:6
    if j == k
        set(S.h.page(j), 'Visible', 'on');
        set(S.h.stepButton(j), 'BackgroundColor', [0.20 0.45 0.80], 'ForegroundColor', 'w', 'FontWeight', 'bold');
    else
        set(S.h.page(j), 'Visible', 'off');
        set(S.h.stepButton(j), 'BackgroundColor', [0.88 0.88 0.88], 'ForegroundColor', 'k', 'FontWeight', 'normal');
    end
    set(S.h.stepButton(j), 'Enable', onOff(j <= S.maxStep));
end
set(S.h.back, 'Enable', onOff(k > 1));
set(S.h.next, 'Visible', onOff(k < 6));
guidata(fig, S);
if k == 2 && S.ok.geometry, previewBC(fig); end
if k == 4, fillMaterialFields(fig, false); end
if k == 6, prepareSolverPage(fig); end
end

function refreshNav(fig)
S = guidata(fig);
for j = 1:6
    set(S.h.stepButton(j), 'Enable', onOff(j <= S.maxStep || j == S.step));
end
end

function goToStep(fig, k)
if getappdata(fig, 'running'), return; end
S = guidata(fig);
if k <= S.maxStep, showStep(fig, k); end
end

function goBack(fig)
if getappdata(fig, 'running'), return; end
S = guidata(fig);
if S.step > 1, showStep(fig, S.step - 1); end
end

function goNext(fig)
if getappdata(fig, 'running'), return; end
S = guidata(fig);
if S.step >= 6, return; end
switch S.step
    case 1
        if ~S.ok.geometry
            status(fig, 'Press "Define geometry" first (the dimensions were changed or not yet defined).', true);
            return;
        end
    case 2
        if ~applyBC(fig), return; end
    case 3
        if ~S.ok.mesh
            status(fig, 'Press "Start meshing" first (the mesh is missing or does not match the geometry).', true);
            return;
        end
    case 4
        if ~applyMaterials(fig), return; end
    case 5
        if ~applyNumerics(fig), return; end
end
S = guidata(fig);
S.maxStep = max(S.maxStep, S.step + 1);
guidata(fig, S);
showStep(fig, S.step + 1);
msgs = {'', 'Step 2: choose the boundary conditions; only the fields of the selected type are shown.', ...
        'Step 3: set the mesh and press "Start meshing".', ...
        'Step 4: check the material properties of the three regions.', ...
        'Step 5: check the numerical settings and the convergence criteria.', ...
        'Step 6: set the initial temperature and press "Start simulation".'};
status(fig, msgs{S.step + 1});
end

% ========================================================================
%                              1  GEOMETRY
% ========================================================================
function buildGeometryPage(fig)
S = guidata(fig);
p = S.h.page(1);
c = S.caseData;
box = uipanel('Parent', p, 'Units', 'normalized', 'Position', [0.005 0.02 0.255 0.96], ...
    'Title', 'Dimensions', 'FontWeight', 'bold', 'FontSize', 11);
rows = {'L_total',         'Total length',                         1e3*c.L_total,         'mm';
        'L_unheatedStart', 'Unheated start section',               1e3*c.L_unheatedStart, 'mm';
        'heaterLength',    'Evaporator length',                    1e3*c.heaterLength,    'mm';
        'L_cond',          'Condenser length',                     1e3*c.L_cond,          'mm';
        'L_unheatedEnd',   'Unheated end section',                 1e3*c.L_unheatedEnd,   'mm';
        'D_outer',         'Outer diameter of the wall',           2e3*c.R_outer,         'mm';
        'D_wick',          'Inner diameter of the wall',           2e3*c.R_wick,          'mm';
        'D_vapor',         'Vapor core diameter',                  2e3*c.R_vapor,         'mm'};
y = 0.92;
for k = 1:size(rows,1)
    if k == 6
        uicontrol(box, 'Style', 'text', 'Units', 'normalized', 'Position', [0.03 y 0.94 0.04], ...
            'String', 'Radial dimensions', 'FontWeight', 'bold', 'HorizontalAlignment', 'left');
        y = y - 0.055;
    end
    S.h.geo.(rows{k,1}) = fieldRow(box, y, rows{k,2}, rows{k,3}, rows{k,4}, @(src, evt) geometryEdited(fig));
    y = y - 0.065;
end
S.h.geo.derived = uicontrol(box, 'Style', 'text', 'Units', 'normalized', 'Position', [0.03 0.16 0.94 0.17], ...
    'String', '', 'HorizontalAlignment', 'left', 'FontSize', 10);
S.h.geo.define = uicontrol(box, 'Style', 'pushbutton', 'Units', 'normalized', 'Position', [0.08 0.04 0.84 0.07], ...
    'String', 'Define geometry', 'FontSize', 12, 'FontWeight', 'bold', 'BackgroundColor', [0.80 0.90 1.00], ...
    'Callback', @(src, evt) defineGeometry(fig));
S.h.geo.ax = axes('Parent', p, 'Units', 'normalized', 'Position', [0.30 0.10 0.685 0.80]);
guidata(fig, S);
updateDerivedGeometryText(fig);
drawGeometry(S.h.geo.ax, S.caseData);
end

function geometryEdited(fig)
S = guidata(fig);
S.ok.geometry = false;
S.maxStep = 1;
guidata(fig, S);
refreshNav(fig);
updateDerivedGeometryText(fig);
status(fig, 'Dimensions changed: press "Define geometry" to apply them.');
end

function updateDerivedGeometryText(fig)
S = guidata(fig);
g = S.h.geo;
v = @(f) str2double(get(g.(f)(2), 'String'));
Ltr = v('L_total') - v('L_unheatedStart') - v('heaterLength') - v('L_cond') - v('L_unheatedEnd');
set(g.derived, 'String', {sprintf('Transport section: %.2f mm', Ltr), ...
    sprintf('Wall thickness: %.3f mm', 0.5*(v('D_outer') - v('D_wick'))), ...
    sprintf('Wick thickness: %.3f mm (wick between the', 0.5*(v('D_wick') - v('D_vapor'))), ...
    'vapor core and the inner wall diameter)'});
end

function defineGeometry(fig)
S = guidata(fig);
g = S.h.geo;
try
    o = S.caseOverrides;
    o.L_total         = 1e-3*readNumber(g.L_total, 'total length', true);
    o.L_unheatedStart = 1e-3*readNumber(g.L_unheatedStart, 'unheated start section', false);
    o.heaterLength    = 1e-3*readNumber(g.heaterLength, 'evaporator length', true);
    o.L_cond          = 1e-3*readNumber(g.L_cond, 'condenser length', true);
    o.L_unheatedEnd   = 1e-3*readNumber(g.L_unheatedEnd, 'unheated end section', false);
    o.R_outer         = 0.5e-3*readNumber(g.D_outer, 'outer diameter', true);
    o.R_wick          = 0.5e-3*readNumber(g.D_wick, 'inner wall diameter', true);
    o.R_vapor         = 0.5e-3*readNumber(g.D_vapor, 'vapor core diameter', true);
    o.wickThicknessSource = 'diameters';
    caseData = inputCleanHeatPipeCase(o);
catch err
    status(fig, ['Geometry not accepted: ' err.message], true);
    return;
end
S.caseOverrides = o;
S.caseData = caseData;
S.ok.geometry = true;
if S.ok.mesh
    S.ok.mesh = false;           % the mesh no longer matches
    S.maxStep = min(S.maxStep, 3);
end
S.ok.bc = false;
S.maxStep = min(S.maxStep, 2);
S.results = [];
guidata(fig, S);
refreshNav(fig);
updateDerivedGeometryText(fig);
drawGeometry(g.ax, caseData);
status(fig, sprintf('Geometry defined: length %.1f mm, transport section %.1f mm. Continue with "Next step".', ...
    1e3*caseData.L_total, 1e3*caseData.L_transport));
end

% ========================================================================
%                          2  BOUNDARY CONDITIONS
% ========================================================================
function buildBCPage(fig)
S = guidata(fig);
p = S.h.page(2);
c = S.caseData;
C = @(T) T - 273.15;
cb = @(src, evt) bcChanged(fig);

% ---- evaporator
pe = uipanel('Parent', p, 'Units', 'normalized', 'Position', [0.005 0.53 0.33 0.46], ...
    'Title', 'Evaporator', 'FontWeight', 'bold', 'FontSize', 11, 'ForegroundColor', [0.75 0.15 0.05]);
e.types = {'power', 'temperature', 'temperatureFunction', 'convection', 'heatFluxFunction'};
e.popup = popupRow(pe, 0.82, 'Type', {'Input power', 'Uniform temperature', 'Non-uniform temperature T(z)', ...
    'Convection', 'Non-uniform heat flux q(z)'}, 1, cb);
e.P    = fieldRow(pe, 0.64, 'Input power', c.evaporatorPowers_W, 'W', cb);
e.T    = fieldRow(pe, 0.64, 'Wall temperature', C(c.evaporatorTemperature_K), 'degC', cb);
e.Tfun = functionRow(pe, 0.64, 'T(z) =', c.evaporatorTemperatureFunction, 'degC', cb);
e.h    = fieldRow(pe, 0.64, 'Heat transfer coeff. h', c.evaporatorH_W_m2K, 'W/m2K', cb);
e.Tinf = fieldRow(pe, 0.50, 'Ambient temp. T_inf', C(c.evaporatorTinf_K), 'degC', cb);
e.qfun = functionRow(pe, 0.64, 'q(z) =', c.evaporatorHeatFluxFunction, 'W/m2', cb);
e.note = noteText(pe, [0.03 0.03 0.94 0.36]);
S.h.bcE = e;

% ---- transport
pt = uipanel('Parent', p, 'Units', 'normalized', 'Position', [0.34 0.53 0.32 0.46], ...
    'Title', 'Transport section', 'FontWeight', 'bold', 'FontSize', 11);
t.types = {'adiabatic', 'convection'};
t.popup = popupRow(pt, 0.82, 'Type', {'Adiabatic', 'Convection'}, 1, cb);
t.h    = fieldRow(pt, 0.64, 'Heat transfer coeff. h', c.transportH_W_m2K, 'W/m2K', cb);
t.Tinf = fieldRow(pt, 0.50, 'Ambient temp. T_inf', C(c.transportTinf_K), 'degC', cb);
t.note = noteText(pt, [0.03 0.03 0.94 0.36]);
S.h.bcT = t;

% ---- condenser
pc = uipanel('Parent', p, 'Units', 'normalized', 'Position', [0.665 0.53 0.33 0.46], ...
    'Title', 'Condenser', 'FontWeight', 'bold', 'FontSize', 11, 'ForegroundColor', [0.05 0.30 0.80]);
k.types = {'paperEq20UniformHeatFlux', 'power', 'temperature', 'temperatureFunction', 'convection', 'heatFluxFunction'};
k.popup = popupRow(pc, 0.82, 'Type', {'Remove the input power (paper Eq. 20)', 'Power removed', ...
    'Uniform temperature', 'Non-uniform temperature T(z)', 'Convection', 'Non-uniform heat flux q(z)'}, 1, cb);
k.P    = fieldRow(pc, 0.64, 'Power removed', c.evaporatorPowers_W, 'W', cb);
k.T    = fieldRow(pc, 0.64, 'Wall temperature', C(c.condenserWallTemperature_K), 'degC', cb);
k.Tfun = functionRow(pc, 0.64, 'T(z) =', c.condenserTemperatureFunction, 'degC', cb);
k.h    = fieldRow(pc, 0.64, 'Heat transfer coeff. h', c.condenserH_W_m2K, 'W/m2K', cb);
k.Tinf = fieldRow(pc, 0.50, 'Ambient temp. T_inf', C(c.condenserTinf_K), 'degC', cb);
k.qfun = functionRow(pc, 0.64, 'q(z) =', c.condenserHeatFluxFunction, 'W/m2', cb);
k.note = noteText(pc, [0.03 0.03 0.94 0.36]);
S.h.bcC = k;

% ---- operating temperature, help, apply
po = uipanel('Parent', p, 'Units', 'normalized', 'Position', [0.005 0.30 0.33 0.22], ...
    'Title', 'Operating (vapor) temperature', 'FontWeight', 'bold', 'FontSize', 11);
S.h.bcTo = fieldRow(po, 0.62, 'Operating temperature T_o', C(c.T_o_K), 'degC', cb);
S.h.bcToNote = noteText(po, [0.03 0.04 0.94 0.50]);
helpTxt = {'T(z) and q(z) are MATLAB expressions in', ...
    '  z [m]: axial position (0 at the evaporator cap)', ...
    '  s [m]: distance from the zone start', ...
    '  L [m]: zone length', ...
    'Example: 85 + 3*sin(pi*s/L)', ...
    'q > 0: into the pipe (evaporator), out (condenser)', ...
    'The unheated end sections are adiabatic.'};
uicontrol(p, 'Style', 'text', 'Units', 'normalized', 'Position', [0.005 0.09 0.33 0.20], 'String', helpTxt, ...
    'HorizontalAlignment', 'left', 'FontSize', 9);
uicontrol(p, 'Style', 'pushbutton', 'Units', 'normalized', 'Position', [0.06 0.015 0.22 0.06], ...
    'String', 'Apply boundary conditions', 'FontSize', 11, 'FontWeight', 'bold', ...
    'BackgroundColor', [0.80 0.90 1.00], 'Callback', @(src, evt) applyBC(fig));
S.h.bcAxQ = axes('Parent', p, 'Units', 'normalized', 'Position', [0.40 0.30 0.585 0.19]);
S.h.bcAxT = axes('Parent', p, 'Units', 'normalized', 'Position', [0.40 0.05 0.585 0.19]);
guidata(fig, S);
updateBCVisibility(fig);
end

function previewBC(fig)
% draw the BC preview with the current settings (state unchanged)
S = guidata(fig);
msg = get(S.h.status, 'String');
okBefore = S.ok.bc;
if applyBC(fig)
    S = guidata(fig); S.ok.bc = okBefore; guidata(fig, S);
    status(fig, msg);
end
end

function bcChanged(fig)
S = guidata(fig);
S.ok.bc = false;
S.maxStep = min(S.maxStep, 2);
guidata(fig, S);
refreshNav(fig);
updateBCVisibility(fig);
end

function updateBCVisibility(fig)
S = guidata(fig);
e = S.h.bcE; t = S.h.bcT; k = S.h.bcC;
eType = e.types{get(e.popup(2), 'Value')};
tType = t.types{get(t.popup(2), 'Value')};
cType = k.types{get(k.popup(2), 'Value')};
showRow(e.P, strcmp(eType, 'power'));
showRow(e.T, strcmp(eType, 'temperature'));
showRow(e.Tfun, strcmp(eType, 'temperatureFunction'));
showRow(e.h, strcmp(eType, 'convection'));
showRow(e.Tinf, strcmp(eType, 'convection'));
showRow(e.qfun, strcmp(eType, 'heatFluxFunction'));
showRow(t.h, strcmp(tType, 'convection'));
showRow(t.Tinf, strcmp(tType, 'convection'));
showRow(k.P, strcmp(cType, 'power'));
showRow(k.T, strcmp(cType, 'temperature'));
showRow(k.Tfun, strcmp(cType, 'temperatureFunction'));
showRow(k.h, strcmp(cType, 'convection'));
showRow(k.Tinf, strcmp(cType, 'convection'));
showRow(k.qfun, strcmp(cType, 'heatFluxFunction'));
ext = ' Extension of the paper''s model, not validated against measurements.';
eNotes = struct('power', 'Uniform heat flux P/A over the evaporator (paper Eq. 20).', ...
    'temperature', ['Prescribed outer-wall temperature; the heat input follows from the solution.' ext], ...
    'temperatureFunction', ['Prescribed outer-wall temperature profile T(z) in degC.' ext], ...
    'convection', ['q = h (T_inf - T_wall) into the pipe.' ext], ...
    'heatFluxFunction', ['Prescribed heat flux q(z) in W/m2 into the pipe.' ext]);
cNotes = struct('paperEq20UniformHeatFlux', 'Removes the evaporator input as a uniform heat flux (paper Eq. 20, validated).', ...
    'power', 'Uniform heat flux P/A out of the pipe (form of paper Eq. 20).', ...
    'temperature', ['Prescribed outer-wall temperature.' ext], ...
    'temperatureFunction', ['Prescribed outer-wall temperature profile T(z) in degC.' ext], ...
    'convection', ['q = h (T_wall - T_inf) out of the pipe.' ext], ...
    'heatFluxFunction', ['Prescribed heat flux q(z) in W/m2 out of the pipe.' ext]);
set(e.note, 'String', wrapText(eNotes.(eType), e.note));
set(k.note, 'String', wrapText(cNotes.(cType), k.note));
if strcmp(tType, 'adiabatic')
    set(t.note, 'String', wrapText('No heat exchange with the surroundings (paper).', t.note));
else
    set(t.note, 'String', wrapText(['Heat loss or gain q = h (T_wall - T_inf) along the transport section. ', ...
        'Use it together with a temperature or convection BC at the condenser.' ext], t.note));
end
fluxOnly = any(strcmp(eType, {'power', 'heatFluxFunction'})) && strcmp(tType, 'adiabatic') && ...
           any(strcmp(cType, {'paperEq20UniformHeatFlux', 'power', 'heatFluxFunction'}));
showRow(S.h.bcTo, fluxOnly);
if fluxOnly
    set(S.h.bcToNote, 'String', wrapText(['Only heat fluxes are prescribed: T_o sets the temperature level. ', ...
        'The condenser must remove the input; a differing condenser flux is scaled.'], S.h.bcToNote));
else
    set(S.h.bcToNote, 'String', wrapText(['A temperature or convection BC sets the temperature level: ', ...
        'T_o is solved for (start value = initial temperature, step 6).'], S.h.bcToNote));
end
if strcmp(cType, 'paperEq20UniformHeatFlux') && ~any(strcmp(eType, {'power', 'heatFluxFunction'}))
    set(k.note, 'String', wrapText('Not possible with this evaporator BC: choose another condenser type.', k.note), ...
        'ForegroundColor', [0.8 0 0]);
else
    set(k.note, 'ForegroundColor', [0 0 0]);
end
end

function tf = applyBC(fig)
tf = false;
S = guidata(fig);
e = S.h.bcE; t = S.h.bcT; k = S.h.bcC;
o = S.caseOverrides;
K = @(x) x + 273.15;
try
    o.evaporatorBCType = e.types{get(e.popup(2), 'Value')};
    o.transportBCType  = t.types{get(t.popup(2), 'Value')};
    o.condenserBCType  = k.types{get(k.popup(2), 'Value')};
    switch o.evaporatorBCType
        case 'power',               o.evaporatorPowers_W = readNumber(e.P(2), 'evaporator power', false);
        case 'temperature',         o.evaporatorTemperature_K = K(readNumber(e.T(2), 'evaporator temperature'));
        case 'temperatureFunction', o.evaporatorTemperatureFunction = strtrim(get(e.Tfun(2), 'String'));
        case 'convection'
            o.evaporatorH_W_m2K = readNumber(e.h(2), 'evaporator h', true);
            o.evaporatorTinf_K = K(readNumber(e.Tinf(2), 'evaporator T_inf'));
        case 'heatFluxFunction',    o.evaporatorHeatFluxFunction = strtrim(get(e.qfun(2), 'String'));
    end
    if strcmp(o.transportBCType, 'convection')
        o.transportH_W_m2K = readNumber(t.h(2), 'transport h', true);
        o.transportTinf_K = K(readNumber(t.Tinf(2), 'transport T_inf'));
    end
    switch o.condenserBCType
        case 'power',               o.totalHeatOutput_W = readNumber(k.P(2), 'condenser power', true);
        case 'temperature',         o.condenserWallTemperature_K = K(readNumber(k.T(2), 'condenser temperature'));
        case 'temperatureFunction', o.condenserTemperatureFunction = strtrim(get(k.Tfun(2), 'String'));
        case 'convection'
            o.condenserH_W_m2K = readNumber(k.h(2), 'condenser h', true);
            o.condenserTinf_K = K(readNumber(k.Tinf(2), 'condenser T_inf'));
        case 'heatFluxFunction',    o.condenserHeatFluxFunction = strtrim(get(k.qfun(2), 'String'));
    end
    o.T_o_K = K(readNumber(S.h.bcTo(2), 'operating temperature'));
    o.initialTemperature_K = o.T_o_K;
    caseData = inputCleanHeatPipeCase(o);
    info = drawBCPreview(S.h.bcAxQ, S.h.bcAxT, caseData);
catch err
    status(fig, ['Boundary conditions not accepted: ' err.message], true);
    return;
end
S.caseOverrides = o;
S.caseData = caseData;
S.ok.bc = true;
S.results = [];
guidata(fig, S);
set(S.h.sv.Tinit(2), 'String', sprintf('%.6g', caseData.T_o_K - 273.15));
msg = 'Boundary conditions applied.';
if info.fluxOnly
    msg = sprintf('%s Flux-only: %.2f W in, %.2f W out; T_o = %.2f degC sets the level.', msg, ...
        info.Qin_W, info.Qout_W, caseData.T_o_K - 273.15);
end
if info.condenserScale ~= 1
    msg = sprintf('%s Condenser flux scaled by %.4g to remove the input.', msg, info.condenserScale);
end
status(fig, msg);
tf = true;
end

% ========================================================================
%                                3  MESH
% ========================================================================
function buildMeshPage(fig)
S = guidata(fig);
p = S.h.page(3);
n = S.num;
box = uipanel('Parent', p, 'Units', 'normalized', 'Position', [0.005 0.02 0.255 0.96], ...
    'Title', 'Mesh settings', 'FontWeight', 'bold', 'FontSize', 11);
cb = @(src, evt) meshEdited(fig);
m.preset = popupRow(box, 0.91, 'Preset', {'Default: 24+16+8, dz 3 mm', ...
    'Paper: 50 x (10+5+5)', 'Paper: 100 x (20+5+10)', 'Custom'}, 1, @(src, evt) meshPresetChanged(fig));
spacing = {'uniform', 'cosine'};
m.Nv = fieldRow(box, 0.80, 'Radial cells, vapor core', n.NvaporR, '', cb);
m.sv = popupRow(box, 0.735, 'spacing', spacing, find(strcmp(spacing, n.radialSpacing{1})), cb);
m.Nw = fieldRow(box, 0.65, 'Radial cells, wick', n.NwickR, '', cb);
m.sw = popupRow(box, 0.585, 'spacing', spacing, find(strcmp(spacing, n.radialSpacing{2})), cb);
m.Ns = fieldRow(box, 0.50, 'Radial cells, wall', n.NwallR, '', cb);
m.ss = popupRow(box, 0.435, 'spacing', spacing, find(strcmp(spacing, n.radialSpacing{3})), cb);
m.dz = fieldRow(box, 0.35, 'Max. axial cell size', 1e3*n.axialMaxCellSize_m, 'mm', cb);
m.Nz = fieldRow(box, 0.285, 'Total axial cells (0: use size)', 0, '', cb);
m.nmin = fieldRow(box, 0.22, 'Min. cells per section', n.axialMinCellsPerSegment, '', cb);
m.go = uicontrol(box, 'Style', 'pushbutton', 'Units', 'normalized', 'Position', [0.08 0.12 0.84 0.07], ...
    'String', 'Start meshing', 'FontSize', 12, 'FontWeight', 'bold', 'BackgroundColor', [0.80 0.90 1.00], ...
    'Callback', @(src, evt) startMeshing(fig));
m.info = uicontrol(box, 'Style', 'text', 'Units', 'normalized', 'Position', [0.03 0.005 0.94 0.105], ...
    'String', '', 'HorizontalAlignment', 'left', 'FontSize', 9);
m.ax1 = axes('Parent', p, 'Units', 'normalized', 'Position', [0.30 0.57 0.685 0.36]);
m.ax2 = axes('Parent', p, 'Units', 'normalized', 'Position', [0.30 0.08 0.685 0.36]);
S.h.mesh = m;
guidata(fig, S);
end

function meshEdited(fig)
S = guidata(fig);
S.ok.mesh = false;
S.maxStep = min(S.maxStep, 3);
set(S.h.mesh.preset(2), 'Value', 4);   % custom
guidata(fig, S);
refreshNav(fig);
status(fig, 'Mesh settings changed: press "Start meshing".');
end

function meshPresetChanged(fig)
S = guidata(fig);
m = S.h.mesh;
presets = {'default', 'paper50', 'paper100'};
v = get(m.preset(2), 'Value');
if v <= 3
    n = inputCleanHeatPipeNumerics(presets{v});
    spacing = {'uniform', 'cosine'};
    set(m.Nv(2), 'String', num2str(n.NvaporR)); set(m.Nw(2), 'String', num2str(n.NwickR));
    set(m.Ns(2), 'String', num2str(n.NwallR));
    set(m.sv(2), 'Value', find(strcmp(spacing, n.radialSpacing{1})));
    set(m.sw(2), 'Value', find(strcmp(spacing, n.radialSpacing{2})));
    set(m.ss(2), 'Value', find(strcmp(spacing, n.radialSpacing{3})));
    if isempty(n.axialMaxCellSize_m)
        set(m.dz(2), 'String', '3'); set(m.Nz(2), 'String', num2str(n.axialCellsTotal));
    else
        set(m.dz(2), 'String', num2str(1e3*n.axialMaxCellSize_m)); set(m.Nz(2), 'String', '0');
    end
    set(m.nmin(2), 'String', num2str(n.axialMinCellsPerSegment));
end
S.ok.mesh = false;
S.maxStep = min(S.maxStep, 3);
guidata(fig, S);
refreshNav(fig);
status(fig, 'Mesh preset selected: press "Start meshing".');
end

function startMeshing(fig)
S = guidata(fig);
m = S.h.mesh;
if ~S.ok.geometry
    status(fig, 'Define the geometry first (step 1).', true);
    return;
end
spacing = {'uniform', 'cosine'};
presets = {'default', 'paper50', 'paper100', 'custom'};
try
    num = S.num;
    num.gridPreset = presets{get(m.preset(2), 'Value')};
    num.NvaporR = readInteger(m.Nv(2), 'vapor core cells');
    num.NwickR  = readInteger(m.Nw(2), 'wick cells');
    num.NwallR  = readInteger(m.Ns(2), 'wall cells');
    num.radialSpacing = {spacing{get(m.sv(2), 'Value')}, spacing{get(m.sw(2), 'Value')}, spacing{get(m.ss(2), 'Value')}};
    Nz = round(readNumber(m.Nz(2), 'total axial cells', false));
    if Nz > 0
        num.axialCellsTotal = Nz; num.axialMaxCellSize_m = [];
    else
        num.axialCellsTotal = []; num.axialMaxCellSize_m = 1e-3*readNumber(m.dz(2), 'axial cell size', true);
    end
    num.axialMinCellsPerSegment = readInteger(m.nmin(2), 'cells per section');
    num.verbose = false;
    status(fig, 'Meshing ...'); drawnow;
    mesh = tagCleanRegionsAndBoundaries(createCleanMesh(S.caseData, num), S.caseData);
catch err
    status(fig, ['Mesh not created: ' err.message], true);
    return;
end
S.num = num;
S.mesh = mesh;
S.ok.mesh = true;
S.results = [];
guidata(fig, S);
c = S.caseData;
drawMesh(m.ax1, mesh, c);
title(m.ax1, sprintf('Mesh: %d axial x (%d vapor + %d wick + %d wall) = %d cells  (radial direction stretched)', ...
    mesh.Nz, mesh.Nv, mesh.Nw, mesh.Ns, mesh.Ncells));
zEnd = min(1e3*c.L_total, 1e3*c.heaterSegments_m(1,2) + 40);
drawMesh(m.ax2, mesh, c, [0 zEnd]);
title(m.ax2, sprintf('Detail: z = 0 - %.0f mm (use the zoom tool for other regions)', zEnd));
set(m.info, 'String', {sprintf('%d x %d = %d cells', mesh.Nz, mesh.Nr, mesh.Ncells), ...
    sprintf('dz = %.3g - %.3g mm', 1e3*mesh.minDz, 1e3*mesh.maxDz), ...
    sprintf('dr = %.3g - %.3g mm', 1e3*mesh.minDr, 1e3*mesh.maxDr)});
status(fig, sprintf('Mesh created: %d cells. Continue with "Next step".', mesh.Ncells));
end

% ========================================================================
%                              4  MATERIALS
% ========================================================================
function buildMaterialsPage(fig)
S = guidata(fig);
p = S.h.page(4);
cb = @(src, evt) materialsEdited(fig);
top = uipanel('Parent', p, 'Units', 'normalized', 'Position', [0.005 0.84 0.99 0.15], ...
    'Title', 'Working fluid: water', 'FontWeight', 'bold', 'FontSize', 11);
mt.follow = uicontrol(top, 'Style', 'checkbox', 'Units', 'normalized', 'Position', [0.01 0.54 0.50 0.40], ...
    'String', 'Water properties follow the operating temperature T_o', 'Value', 1, ...
    'Callback', @(src, evt) followChanged(fig));
mt.TevalLabel = uicontrol(top, 'Style', 'text', 'Units', 'normalized', 'Position', [0.01 0.10 0.20 0.34], ...
    'String', 'Evaluate water at', 'HorizontalAlignment', 'right');
mt.Teval = uicontrol(top, 'Style', 'edit', 'Units', 'normalized', 'Position', [0.215 0.06 0.07 0.42], ...
    'String', sprintf('%.6g', S.mat.T_eval_K - 273.15), 'BackgroundColor', 'w');
uicontrol(top, 'Style', 'text', 'Units', 'normalized', 'Position', [0.29 0.10 0.04 0.34], 'String', 'degC', ...
    'HorizontalAlignment', 'left');
mt.load = uicontrol(top, 'Style', 'pushbutton', 'Units', 'normalized', 'Position', [0.34 0.04 0.16 0.46], ...
    'String', 'Load water properties', 'FontWeight', 'bold', 'Callback', @(src, evt) loadWaterProperties(fig));
mt.followNote = uicontrol(top, 'Style', 'text', 'Units', 'normalized', 'Position', [0.52 0.04 0.47 0.90], ...
    'String', '', 'HorizontalAlignment', 'left', 'FontSize', 9);

pv = uipanel('Parent', p, 'Units', 'normalized', 'Position', [0.005 0.02 0.325 0.81], ...
    'Title', 'Vapor core (water vapor)', 'FontWeight', 'bold', 'FontSize', 11);
mt.mu_v = fieldRow(pv, 0.90, 'Dynamic viscosity', 0, 'Pa s', cb);
mt.k_v  = fieldRow(pv, 0.83, 'Thermal conductivity', 0, 'W/m K', cb);
mt.cp_v = fieldRow(pv, 0.76, 'Specific heat c_p', 0, 'J/kg K', cb);
mt.R_v  = fieldRow(pv, 0.69, 'Gas constant R', 0, 'J/kg K', cb);
mt.vapInfo = uicontrol(pv, 'Style', 'text', 'Units', 'normalized', 'Position', [0.03 0.36 0.94 0.28], ...
    'String', '', 'HorizontalAlignment', 'left', 'FontSize', 9);

pw = uipanel('Parent', p, 'Units', 'normalized', 'Position', [0.335 0.02 0.33 0.81], ...
    'Title', 'Wick (porous structure + liquid water)', 'FontWeight', 'bold', 'FontSize', 11);
uicontrol(pw, 'Style', 'text', 'Units', 'normalized', 'Position', [0.03 0.935 0.94 0.04], ...
    'String', 'Liquid', 'FontWeight', 'bold', 'HorizontalAlignment', 'left');
mt.rho_l = fieldRow(pw, 0.875, 'Density', 0, 'kg/m3', cb);
mt.mu_l  = fieldRow(pw, 0.815, 'Dynamic viscosity', 0, 'Pa s', cb);
mt.k_l   = fieldRow(pw, 0.755, 'Thermal conductivity', 0, 'W/m K', cb);
mt.cp_l  = fieldRow(pw, 0.695, 'Specific heat c_p', 0, 'J/kg K', cb);
mt.sig   = fieldRow(pw, 0.635, 'Surface tension', 0, 'N/m', cb);
uicontrol(pw, 'Style', 'text', 'Units', 'normalized', 'Position', [0.03 0.575 0.94 0.04], ...
    'String', 'Porous structure', 'FontWeight', 'bold', 'HorizontalAlignment', 'left');
mt.eps  = fieldRow(pw, 0.515, 'Porosity', 0, '-', cb);
mt.K    = fieldRow(pw, 0.455, 'Permeability', 0, 'm2', cb);
mt.k_s  = fieldRow(pw, 0.395, 'Solid conductivity', 0, 'W/m K', cb);
mt.r_c  = fieldRow(pw, 0.335, 'Capillary radius', 0, 'mm', cb);
mt.keffAuto = uicontrol(pw, 'Style', 'checkbox', 'Units', 'normalized', 'Position', [0.03 0.27 0.94 0.045], ...
    'String', 'k_eff from Eq. (9) (Chi 1976)', 'Value', 1, ...
    'Callback', @(src, evt) materialsEdited(fig));
mt.k_eff = fieldRow(pw, 0.215, 'Effective conductivity', 0, 'W/m K', cb);
uicontrol(pw, 'Style', 'text', 'Units', 'normalized', 'Position', [0.03 0.155 0.50 0.04], ...
    'String', 'Screen wick data', 'FontWeight', 'bold', 'HorizontalAlignment', 'left');
uicontrol(pw, 'Style', 'pushbutton', 'Units', 'normalized', 'Position', [0.50 0.148 0.47 0.055], ...
    'String', 'Compute eps, K, r_c', 'Callback', @(src, evt) computeScreen(fig));
mt.N = fieldRow(pw, 0.09, 'Mesh number', S.caseData.screenWick.meshNumber_per_m, '1/m', []);
mt.d = fieldRow(pw, 0.025, 'Wire diameter', 1e3*S.caseData.screenWick.wireDiameter_m, 'mm', []);

ps = uipanel('Parent', p, 'Units', 'normalized', 'Position', [0.67 0.02 0.325 0.81], ...
    'Title', 'Wall', 'FontWeight', 'bold', 'FontSize', 11);
mt.wallNames = {'Copper UNS C12200 (paper)', 'Copper, pure', 'Aluminium 6061-T6', 'Stainless steel 304', 'Custom'};
mt.wallData = [339 8940 385; 401 8960 385; 167 2700 896; 16.2 8000 500; NaN NaN NaN];
mt.wall = popupRow(ps, 0.90, 'Material', mt.wallNames, 1, @(src, evt) wallMaterialChanged(fig));
mt.k_w   = fieldRow(ps, 0.82, 'Thermal conductivity', 0, 'W/m K', @(src, evt) wallEdited(fig));
mt.rho_w = fieldRow(ps, 0.75, 'Density', 0, 'kg/m3', @(src, evt) wallEdited(fig));
mt.cp_w  = fieldRow(ps, 0.68, 'Specific heat c_p', 0, 'J/kg K', @(src, evt) wallEdited(fig));
mt.wallNote = uicontrol(ps, 'Style', 'text', 'Units', 'normalized', 'Position', [0.03 0.50 0.94 0.14], ...
    'String', '', 'HorizontalAlignment', 'left', 'FontSize', 9);
set(mt.wallNote, 'String', wrapText(['The steady-state model uses the thermal conductivity; density and ', ...
    'specific heat are listed for reference.'], mt.wallNote));
S.h.mat = mt;
guidata(fig, S);
end

function fillMaterialFields(fig, force)
% fill the fields from S.mat (first visit, or when forced); with "follow T_o"
% the water fields always show the properties at the current T_o
S = guidata(fig);
mt = S.h.mat;
if ~S.materialsLoaded || force
    if ~S.materialsLoaded
        S.mat = inputCleanHeatPipeMaterials(S.caseData);   % water at the current T_o
    end
    m = S.mat;
    setFluidFields(mt, m); setNum(mt.R_v, m.vapor.R);
    setNum(mt.eps, m.wick.porosity); setNum(mt.K, m.wick.permeability_m2); setNum(mt.k_s, m.wick.k_s);
    setNum(mt.r_c, 1e3*m.wick.capillaryRadius_m); setNum(mt.k_eff, m.wick.k_eff);
    setNum(mt.k_w, m.wall.k); setNum(mt.rho_w, m.wall.rho); setNum(mt.cp_w, m.wall.cp);
    set(mt.Teval, 'String', sprintf('%.6g', m.T_eval_K - 273.15));
    set(mt.follow, 'Value', double(m.fluidPropertiesFollowT_o));
    S.materialsLoaded = true;
    guidata(fig, S);
end
updateFollowState(fig);
updateMaterialInfo(fig);
end

function setFluidFields(mt, m)
% water vapor and liquid properties of the material structure m into the fields
setNum(mt.mu_v, m.vapor.mu); setNum(mt.k_v, m.vapor.k); setNum(mt.cp_v, m.vapor.cp);
setNum(mt.rho_l, m.liquid.rho); setNum(mt.mu_l, m.liquid.mu); setNum(mt.k_l, m.liquid.k);
setNum(mt.cp_l, m.liquid.cp); setNum(mt.sig, m.liquid.surfaceTension_N_m);
end

function followChanged(fig)
updateFollowState(fig);
materialsEdited(fig);
end

function updateFollowState(fig)
% "Water properties follow T_o": fluid fields show water at T_o and are locked
S = guidata(fig);
mt = S.h.mat;
follow = get(mt.follow, 'Value') == 1;
fluid = [mt.mu_v(2) mt.k_v(2) mt.cp_v(2) mt.rho_l(2) mt.mu_l(2) mt.k_l(2) mt.cp_l(2) mt.sig(2)];
set(fluid, 'Enable', onOff(~follow));
set([mt.Teval mt.load], 'Enable', onOff(~follow));
if follow
    T = S.caseData.T_o_K;
    setFluidFields(mt, inputCleanHeatPipeMaterials(S.caseData));
    set(mt.Teval, 'String', sprintf('%.6g', T - 273.15));
    if isFluxOnlyBC(S.caseData)
        txt = sprintf(['Recommended. Water at T_o = %.2f degC (step 2); the fluid values below are shown ', ...
            'for information. Uncheck the box to enter fixed values.'], T - 273.15);
    else
        txt = sprintf(['Recommended. T_o is solved for: the water properties follow it during the run ', ...
            '(shown here at %.2f degC). Uncheck the box to enter fixed values.'], T - 273.15);
    end
else
    txt = ['The fluid values below are used as constants (edit them or load water at a temperature). ', ...
        'Saturation pressure and latent heat at the interface always follow the water correlations (Eqs. 16, 19).'];
end
set(mt.followNote, 'String', wrapText(txt, mt.followNote));
end

function materialsEdited(fig)
S = guidata(fig);
S.ok.materials = false;
S.maxStep = min(S.maxStep, 4);
guidata(fig, S);
refreshNav(fig);
updateMaterialInfo(fig);
end

function updateMaterialInfo(fig)
S = guidata(fig);
mt = S.h.mat;
auto = get(mt.keffAuto, 'Value') == 1;
set(mt.k_eff(2), 'Enable', onOff(~auto));
if auto
    kl = str2double(get(mt.k_l(2), 'String')); ks = str2double(get(mt.k_s(2), 'String'));
    ep = str2double(get(mt.eps(2), 'String'));
    if all(isfinite([kl ks ep]))
        setNum(mt.k_eff, kl*((kl + ks) - (1 - ep)*(kl - ks))/((kl + ks) + (1 - ep)*(kl - ks)));
    end
end
T = str2double(get(mt.Teval, 'String')) + 273.15;
R = str2double(get(mt.R_v(2), 'String'));
if isfinite(T) && T > 273.16 && T < 600
    w = waterThermoProperties(T); ps = waterSaturationPressure(T);
    set(mt.vapInfo, 'String', {sprintf('At %.2f degC (built-in water correlations):', T - 273.15), ...
        sprintf('  saturation pressure %.4g kPa', 1e-3*ps), ...
        sprintf('  latent heat h_fg %.5g kJ/kg', 1e-3*w.phase.hfg), ...
        sprintf('  vapor density p_sat/(R T) %.5g kg/m3', ps/(R*T))});
end
end

function loadWaterProperties(fig)
S = guidata(fig);
mt = S.h.mat;
T = str2double(get(mt.Teval, 'String'));
if ~(isfinite(T) && T > 0.01 && T < 300)
    status(fig, 'The water property temperature must be between 0.01 and 300 degC.', true);
    return;
end
c = S.caseData; c.T_o_K = T + 273.15;
w = inputCleanHeatPipeMaterials(c);
setFluidFields(mt, w); setNum(mt.R_v, w.vapor.R);
materialsEdited(fig);
status(fig, sprintf('Water properties at %.2f degC loaded.', T));
end

function computeScreen(fig)
S = guidata(fig);
mt = S.h.mat;
N = str2double(get(mt.N(2), 'String')); d = 1e-3*str2double(get(mt.d(2), 'String'));
if ~(isfinite(N) && N > 0 && isfinite(d) && d > 0)
    status(fig, 'Mesh number and wire diameter must be positive.', true);
    return;
end
ep = 1 - 1.05*pi*N*d/4;
if ep <= 0 || ep >= 1
    status(fig, 'This screen gives no valid porosity (check mesh number and wire diameter).', true);
    return;
end
setNum(mt.eps, ep);
setNum(mt.K, d^2*ep^3/(122*(1 - ep)^2));
setNum(mt.r_c, 1e3/(2*N));
materialsEdited(fig);
status(fig, 'Porosity, permeability and capillary radius computed from the screen data (Chi 1976).');
end

function wallMaterialChanged(fig)
S = guidata(fig);
mt = S.h.mat;
v = get(mt.wall(2), 'Value');
if v < numel(mt.wallNames)
    setNum(mt.k_w, mt.wallData(v,1)); setNum(mt.rho_w, mt.wallData(v,2)); setNum(mt.cp_w, mt.wallData(v,3));
end
materialsEdited(fig);
end

function wallEdited(fig)
S = guidata(fig);
set(S.h.mat.wall(2), 'Value', numel(S.h.mat.wallNames));   % custom
materialsEdited(fig);
end

function tf = applyMaterials(fig)
tf = false;
fillMaterialFields(fig, false);
S = guidata(fig);
mt = S.h.mat;
try
    in.fluidPropertiesFollowT_o = get(mt.follow, 'Value') == 1;
    if in.fluidPropertiesFollowT_o
        in.T_eval_K = S.caseData.T_o_K;    % the solver follows the solved T_o
    else
        in.T_eval_K = readNumber(mt.Teval, 'property temperature') + 273.15;
    end
    in.vapor_mu = readNumber(mt.mu_v(2), 'vapor viscosity', true);
    in.vapor_k = readNumber(mt.k_v(2), 'vapor conductivity', true);
    in.vapor_cp = readNumber(mt.cp_v(2), 'vapor specific heat', true);
    in.vapor_R = readNumber(mt.R_v(2), 'gas constant', true);
    in.liquid_rho = readNumber(mt.rho_l(2), 'liquid density', true);
    in.liquid_mu = readNumber(mt.mu_l(2), 'liquid viscosity', true);
    in.liquid_k = readNumber(mt.k_l(2), 'liquid conductivity', true);
    in.liquid_cp = readNumber(mt.cp_l(2), 'liquid specific heat', true);
    in.liquid_sigma = readNumber(mt.sig(2), 'surface tension', true);
    in.wick_porosity = readNumber(mt.eps(2), 'porosity', true);
    in.wick_permeability = readNumber(mt.K(2), 'permeability', true);
    in.wick_ks = readNumber(mt.k_s(2), 'solid conductivity', true);
    in.wick_rc = 1e-3*readNumber(mt.r_c(2), 'capillary radius', true);
    if get(mt.keffAuto, 'Value') == 1
        in.wick_keff = NaN;                 % Eq. (9)
    else
        in.wick_keff = readNumber(mt.k_eff(2), 'effective conductivity', true);
    end
    in.wall_k = readNumber(mt.k_w(2), 'wall conductivity', true);
    in.wall_rho = readNumber(mt.rho_w(2), 'wall density', true);
    in.wall_cp = readNumber(mt.cp_w(2), 'wall specific heat', true);
    in.wall_name = mt.wallNames{get(mt.wall(2), 'Value')};
    mat = applyMaterialInputs(inputCleanHeatPipeMaterials(S.caseData), in);
catch err
    status(fig, ['Material properties not accepted: ' err.message], true);
    return;
end
S.mat = mat;
S.caseOverrides.wallConductivity_W_mK = mat.wall.k;
S.caseData.wallConductivity_W_mK = mat.wall.k;
S.ok.materials = true;
S.results = [];
guidata(fig, S);
updateMaterialInfo(fig);
tf = true;
end

% ========================================================================
%                             5  NUMERICS
% ========================================================================
function buildNumericsPage(fig)
S = guidata(fig);
p = S.h.page(5);
n = S.num;
cb = @(src, evt) numericsEdited(fig);

% ---- discretization and coupling
pd = uipanel('Parent', p, 'Units', 'normalized', 'Position', [0.005 0.02 0.325 0.96], ...
    'Title', 'Discretization and coupling', 'FontWeight', 'bold', 'FontSize', 11);
nm.coupling = stackedPopup(pd, 0.85, 'Pressure-velocity coupling', {'SIMPLEC (default)', 'SIMPLE'}, 1, ...
    @(src, evt) couplingChanged(fig));
nm.scheme = stackedPopup(pd, 0.75, 'Convection scheme', ...
    {'Hybrid, Spalding (default)', 'Power law, Patankar', 'First-order upwind'}, 1, cb);
nm.wickForm = stackedPopup(pd, 0.65, 'Wick radial momentum', ...
    {'Vector form, Eq. (25) (default)', 'As printed, Eq. (6)'}, 1, cb);
nm.startup = stackedPopup(pd, 0.55, 'Start-up', ...
    {'Conduction solution (default)', 'Paper: interface flux = wall flux'}, 1, @(src, evt) startupChanged(fig));
nm.startupIt = fieldRow(pd, 0.46, 'Paper start-up iterations', n.startupIterations, '', cb);
nm.noteD = noteText(pd, [0.03 0.02 0.94 0.41]);

% ---- iterations and under-relaxation
pit = uipanel('Parent', p, 'Units', 'normalized', 'Position', [0.335 0.02 0.33 0.96], ...
    'Title', 'Iterations and under-relaxation', 'FontWeight', 'bold', 'FontSize', 11);
nm.inner = fieldRow(pit, 0.90, 'Inner flow iterations', n.innerFlowIterations, '', cb);
uicontrol(pit, 'Style', 'text', 'Units', 'normalized', 'Position', [0.03 0.83 0.94 0.04], ...
    'String', 'Under-relaxation factors (0 < alpha <= 1)', 'FontWeight', 'bold', 'HorizontalAlignment', 'left');
nm.au  = fieldRow(pit, 0.77, 'Vapor momentum', n.alpha_u, 'alpha_u', cb);
nm.auw = fieldRow(pit, 0.71, 'Wick momentum', n.alpha_u_wick, 'alpha_u', cb);
nm.ap  = fieldRow(pit, 0.65, 'Pressure correction', n.alpha_p, 'alpha_p', cb);
nm.aT  = fieldRow(pit, 0.59, 'Energy', n.alpha_T, 'alpha_T', cb);
nm.am  = fieldRow(pit, 0.53, 'Interface mass flux', n.alpha_mdot, 'alpha_m', cb);
nm.noteI = noteText(pit, [0.03 0.02 0.94 0.47]);

% ---- convergence criteria
pc = uipanel('Parent', p, 'Units', 'normalized', 'Position', [0.67 0.02 0.325 0.96], ...
    'Title', 'Convergence criteria', 'FontWeight', 'bold', 'FontSize', 11);
nm.maxIt = fieldRow(pc, 0.90,  'Max. outer iterations', n.maxOuterIterations, '', cb);
nm.tMass = fieldRow(pc, 0.835, 'Mass residual', n.tolMass, '', cb);
nm.tMom  = fieldRow(pc, 0.77,  'Momentum residual', n.tolMomentum, '', cb);
nm.tT    = fieldRow(pc, 0.705, 'Temperature change', n.tolTemperature_K, 'K', cb);
nm.tMdot = fieldRow(pc, 0.64,  'Mass-flux change', n.tolMdotChange, '', cb);
nm.tClos = fieldRow(pc, 0.575, 'Interface closure', n.tolInterfaceClosure, '', cb);
nm.tE    = fieldRow(pc, 0.51,  'Energy residual', n.tolEnergyResidual, '', cb);
nm.tQ    = fieldRow(pc, 0.445, 'Heat balance', n.tolEnergy, '', cb);
nm.reset = uicontrol(pc, 'Style', 'pushbutton', 'Units', 'normalized', 'Position', [0.15 0.365 0.70 0.055], ...
    'String', 'Reset to defaults', 'Callback', @(src, evt) resetNumerics(fig));
nm.noteC = noteText(pc, [0.03 0.01 0.94 0.34]);
S.h.nm = nm;
guidata(fig, S);

set(nm.noteD, 'String', wrapText({['SIMPLEC converges faster than SIMPLE (the paper used SIMPLEST). Hybrid ', ...
    'differencing is the paper''s scheme; the power law is slightly more accurate, upwind the most robust ', ...
    'and most diffusive.'], '', ...
    'Vector form: keeps the -mu v/r^2 term that the printed Eq. (6) omits (about 1e-5 of the balance).', '', ...
    ['Start-up: both reach the same solution; the paper''s sets the interface heat flux equal to the ', ...
    'outer-wall flux for the first iterations.']}, nm.noteD));
set(nm.noteI, 'String', wrapText({['One outer iteration = the inner flow iterations in vapor core and wick, ', ...
    'then the energy equation with the interface conditions (Eqs. 16, 19).'], '', ...
    ['Smaller under-relaxation factors are more robust but slower (1 = none). SIMPLEC uses alpha_p = 1, ', ...
    'SIMPLE about 0.3 (set automatically when the coupling is changed).']}, nm.noteI));
set(nm.noteC, 'String', wrapText({['Converged when all criteria hold in one outer iteration; the final ', ...
    'fields are re-checked.'], ...
    'Mass: sum |imbalance| / evaporation', ...
    'Momentum: sum |residual| / sum |a_P u|', ...
    'Temperature: max |T - T_prev| per iteration', ...
    'Mass-flux change: max |dm''''| / max |m''''|', ...
    'Closure: net Eq. (16) mass flow / evaporation', ...
    'Energy: sum |A T - b| / heat input', ...
    'Heat balance: |Q_in - Q_out| / Q_in (T or convection BCs)'}, nm.noteC));
fillNumericsFields(fig, n);
end

function fillNumericsFields(fig, n)
% show the settings of the numerics structure n (grid settings are on the mesh page)
S = guidata(fig);
nm = S.h.nm;
set(nm.coupling(2), 'Value', 1 + strcmpi(n.pressureVelocityCoupling, 'SIMPLE'));
set(nm.scheme(2), 'Value', find(strcmpi(n.convectionScheme, {'hybrid', 'powerlaw', 'upwind'})));
set(nm.wickForm(2), 'Value', 1 + strcmpi(n.wickRadialMomentumForm, 'printed'));
set(nm.startup(2), 'Value', 1 + strcmpi(n.startup, 'paperOuterFlux'));
setNum(nm.startupIt, n.startupIterations);
setNum(nm.inner, n.innerFlowIterations);
setNum(nm.au, n.alpha_u); setNum(nm.auw, n.alpha_u_wick); setNum(nm.ap, n.alpha_p);
setNum(nm.aT, n.alpha_T); setNum(nm.am, n.alpha_mdot);
setNum(nm.maxIt, n.maxOuterIterations);
setNum(nm.tMass, n.tolMass); setNum(nm.tMom, n.tolMomentum); setNum(nm.tT, n.tolTemperature_K);
setNum(nm.tMdot, n.tolMdotChange); setNum(nm.tClos, n.tolInterfaceClosure);
setNum(nm.tE, n.tolEnergyResidual); setNum(nm.tQ, n.tolEnergy);
set(nm.startupIt(2), 'Enable', onOff(get(nm.startup(2), 'Value') == 2));
end

function numericsEdited(fig)
S = guidata(fig);
S.ok.numerics = false;
S.maxStep = min(S.maxStep, 5);
guidata(fig, S);
refreshNav(fig);
status(fig, 'Numerical settings changed: "Next step" checks and applies them.');
end

function couplingChanged(fig)
S = guidata(fig);
nm = S.h.nm;
if get(nm.coupling(2), 'Value') == 2
    setNum(nm.ap, 0.3);
    msg = 'SIMPLE: pressure under-relaxation alpha_p set to 0.3.';
else
    setNum(nm.ap, 1.0);
    msg = 'SIMPLEC: pressure under-relaxation alpha_p set to 1.';
end
numericsEdited(fig);
status(fig, [msg ' "Next step" applies the settings.']);
end

function startupChanged(fig)
S = guidata(fig);
set(S.h.nm.startupIt(2), 'Enable', onOff(get(S.h.nm.startup(2), 'Value') == 2));
numericsEdited(fig);
end

function resetNumerics(fig)
fillNumericsFields(fig, inputCleanHeatPipeNumerics('default'));
numericsEdited(fig);
status(fig, 'Numerical settings reset to the defaults (the mesh is not changed). "Next step" applies them.');
end

function tf = applyNumerics(fig)
tf = false;
S = guidata(fig);
nm = S.h.nm;
couplings = {'SIMPLEC', 'SIMPLE'};
schemes = {'hybrid', 'powerlaw', 'upwind'};
forms = {'vector', 'printed'};
startups = {'reduced', 'paperOuterFlux'};
try
    n = S.num;                                     % keeps the grid settings of step 3
    n.pressureVelocityCoupling = couplings{get(nm.coupling(2), 'Value')};
    n.convectionScheme = schemes{get(nm.scheme(2), 'Value')};
    n.wickRadialMomentumForm = forms{get(nm.wickForm(2), 'Value')};
    n.startup = startups{get(nm.startup(2), 'Value')};
    n.startupIterations = readNumber(nm.startupIt, 'paper start-up iterations', false);
    if n.startupIterations ~= round(n.startupIterations)
        error('"paper start-up iterations" must be a whole number.');
    end
    n.innerFlowIterations = readInteger(nm.inner, 'inner flow iterations');
    n.alpha_u = readFactor(nm.au, 'vapor momentum alpha_u');
    n.alpha_u_wick = readFactor(nm.auw, 'wick momentum alpha_u');
    n.alpha_p = readFactor(nm.ap, 'pressure correction alpha_p');
    n.alpha_T = readFactor(nm.aT, 'energy alpha_T');
    n.alpha_mdot = readFactor(nm.am, 'interface mass flux alpha_m');
    n.maxOuterIterations = readInteger(nm.maxIt, 'max. outer iterations');
    n.tolMass = readNumber(nm.tMass, 'mass residual', true);
    n.tolMomentum = readNumber(nm.tMom, 'momentum residual', true);
    n.tolTemperature_K = readNumber(nm.tT, 'max. temperature change', true);
    n.tolMdotChange = readNumber(nm.tMdot, 'interface mass-flux change', true);
    n.tolInterfaceClosure = readNumber(nm.tClos, 'interface closure', true);
    n.tolEnergyResidual = readNumber(nm.tE, 'energy residual', true);
    n.tolEnergy = readNumber(nm.tQ, 'heat balance', true);
    if n.startupIterations >= n.maxOuterIterations && strcmp(n.startup, 'paperOuterFlux')
        error('The paper start-up iterations must be fewer than the max. outer iterations.');
    end
catch err
    status(fig, ['Numerical settings not accepted: ' err.message], true);
    return;
end
S.num = n;
S.ok.numerics = true;
S.results = [];
guidata(fig, S);
tf = true;
end

% ========================================================================
%                             6  SOLVER
% ========================================================================
function buildSolverPage(fig)
S = guidata(fig);
p = S.h.page(6);
box = uipanel('Parent', p, 'Units', 'normalized', 'Position', [0.003 0.01 0.235 0.98], ...
    'Title', 'Solver', 'FontWeight', 'bold', 'FontSize', 11);
sv.Tinit = fieldRow(box, 0.92, 'Initial temperature', S.caseData.T_o_K - 273.15, 'degC', []);
sv.every = fieldRow(box, 0.86, 'Live plot every', S.num.livePlotEvery, 'its', []);
sv.Tnote = uicontrol(box, 'Style', 'text', 'Units', 'normalized', 'Position', [0.03 0.76 0.94 0.085], ...
    'String', '', 'HorizontalAlignment', 'left', 'FontSize', 8);
sv.windows = uicontrol(box, 'Style', 'checkbox', 'Units', 'normalized', 'Position', [0.03 0.715 0.94 0.04], ...
    'String', 'Open plot windows at the end', 'Value', 1, 'FontSize', 9);
sv.start = uicontrol(box, 'Style', 'pushbutton', 'Units', 'normalized', 'Position', [0.06 0.625 0.88 0.07], ...
    'String', 'Start simulation', 'FontSize', 12, 'FontWeight', 'bold', 'BackgroundColor', [0.70 0.90 0.70], ...
    'Callback', @(src, evt) startSimulation(fig));
sv.stop = uicontrol(box, 'Style', 'pushbutton', 'Units', 'normalized', 'Position', [0.06 0.545 0.88 0.065], ...
    'String', 'Stop', 'FontSize', 12, 'FontWeight', 'bold', 'BackgroundColor', [0.95 0.70 0.70], ...
    'Enable', 'off', 'Callback', @(src, evt) requestStop(fig));
sv.save = uicontrol(box, 'Style', 'pushbutton', 'Units', 'normalized', 'Position', [0.06 0.465 0.88 0.065], ...
    'String', 'Save results', 'FontSize', 12, 'FontWeight', 'bold', 'BackgroundColor', [0.80 0.90 1.00], ...
    'Enable', 'off', 'Callback', @(src, evt) saveResults(fig));
sv.info = uicontrol(box, 'Style', 'text', 'Units', 'normalized', 'Position', [0.03 0.01 0.94 0.43], ...
    'String', '', 'HorizontalAlignment', 'left', 'FontSize', 9);
sv.live = uipanel('Parent', p, 'Units', 'normalized', 'Position', [0.242 0.01 0.755 0.98], ...
    'Title', 'Live plots', 'FontWeight', 'bold', 'FontSize', 11, 'BackgroundColor', 'w');
S.h.sv = sv;
guidata(fig, S);
end

function prepareSolverPage(fig)
S = guidata(fig);
sv = S.h.sv;
if isFluxOnlyBC(S.caseData)
    set(sv.Tnote, 'String', wrapText(sprintf(['Initial temperature field. The level is set by T_o = %.2f degC ', ...
        '(step 2).'], S.caseData.T_o_K - 273.15), sv.Tnote));
else
    set(sv.Tnote, 'String', wrapText('Initial temperature field and start value of the solved operating temperature T_o.', sv.Tnote));
end
if isempty(S.results)
    set(sv.save, 'Enable', 'off');
    set(sv.info, 'String', wrapText([{'Ready.'}, describeSetup(S)], sv.info));
end
end

function txt = describeSetup(S)
c = S.caseData; m = S.mesh; n = S.num;
txt = {sprintf('Geometry: L = %.1f mm, o.d. %.2f mm', 1e3*c.L_total, 2e3*c.R_outer), ...
       ['Evaporator: ' describeZoneBC(c, 'evaporator')], ['Transport: ' describeZoneBC(c, 'transport')], ...
       ['Condenser: ' describeZoneBC(c, 'condenser')], ...
       sprintf('Wall: %s, k = %.4g W/m K', S.mat.wall.name, S.mat.wall.k), ...
       sprintf('Mesh %d cells; %s, %s, max. %d its; %s', m.Ncells, n.pressureVelocityCoupling, ...
               n.convectionScheme, n.maxOuterIterations, toleranceSummary(n))};
end

function txt = toleranceSummary(n)
tol = [n.tolMass n.tolMomentum n.tolTemperature_K n.tolMdotChange n.tolInterfaceClosure n.tolEnergyResidual n.tolEnergy];
if all(tol == tol(1))
    txt = sprintf('tolerance %.0e', tol(1));
else
    txt = sprintf('tolerances %.0e to %.0e', min(tol), max(tol));
end
end

function startSimulation(fig)
if getappdata(fig, 'running'), return; end
S = guidata(fig);
sv = S.h.sv;
if ~(S.ok.geometry && S.ok.bc && S.ok.mesh && S.ok.materials && S.ok.numerics)
    status(fig, 'Complete steps 1-5 first.', true);
    return;
end
try
    Tinit = readNumber(sv.Tinit(2), 'initial temperature') + 273.15;
    every = readInteger(sv.every(2), 'live plot interval');
catch err
    status(fig, err.message, true);
    return;
end
caseData = S.caseData;
caseData.initialTemperature_K = Tinit;
if ~isFluxOnlyBC(caseData)
    caseData.T_o_K = Tinit;          % start value of the solved operating temperature
    caseData.T_o_C = Tinit - 273.15;
end
num = S.num;                     % numerics and convergence criteria of step 5
num.livePlots = true;
num.livePlotEvery = every;
num.verbose = true;
num.saveResults = false;
num.showFigures = false;
num.liveCallback = @(r, label) liveUpdate(fig, r, label);
num.stopRequestFcn = @() stopRequested(fig);

setappdata(fig, 'stopRequested', false);
setappdata(fig, 'running', true);
setRunning(fig, true);
set(sv.info, 'String', {'Running ...'});
status(fig, 'Simulation running. Press "Stop" to end it after the current iteration.');
drawnow;
try
    results = runPaperModelSolver(caseData, S.mat, num, S.mesh);
    results.monitor = runMonitor('get');
    results.profiles = computeDerivedProfiles(results);
catch err
    setappdata(fig, 'running', false);
    setRunning(fig, false);
    status(fig, ['Simulation failed: ' err.message], true);
    set(sv.info, 'String', {'Simulation failed:', err.message});
    closeIfRequested(fig);
    return;
end
setappdata(fig, 'running', false);
S = guidata(fig);
S.results = results;
guidata(fig, S);
setRunning(fig, false);
if ~ishandle(fig), return; end
plotDiagnostics(results, sv.live, finalLabel(results));
P = results.profiles; h = results.heat;
set(sv.info, 'String', wrapText({finalLabel(results), sprintf('Wall time %.1f s', results.wallTime_s), '', ...
    sprintf('T_o = %.3f degC', results.T_o - 273.15), sprintf('Peak wall %.3f degC', P.peakWall_K - 273.15), ...
    sprintf('Q_in %.3f W, Q_out %.3f W', h.Qin, h.Qout), sprintf('R_total %.5f K/W', P.R_total_KW), '', ...
    '"Save results" writes the PDF diagrams and TXT data to ./heatpipe_results (previous results are replaced).'}, sv.info));
set(sv.save, 'Enable', 'on');
status(fig, [finalLabel(results) '. Press "Save results" to write the result files.']);
if get(sv.windows, 'Value') == 1
    openSeparateWindows(results);
end
closeIfRequested(fig);
end

function liveUpdate(fig, r, label)
if ~ishandle(fig), return; end
S = guidata(fig);
plotDiagnostics(r, S.h.sv.live, label);
H = r.history;
set(S.h.sv.info, 'String', {sprintf('Running: iteration %d', r.iterations), '', ...
    sprintf('mass residual vapor %.2e', H.massVapor(end)), sprintf('max dT %.2e K', H.maxDeltaT(end)), ...
    sprintf('T_o = %.3f degC', r.T_o - 273.15), sprintf('Q_in %.3f W, Q_out %.3f W', r.heat.Qin, r.heat.Qout)});
drawnow;
end

function tf = stopRequested(fig)
drawnow;                       % process the Stop button
tf = ~ishandle(fig) || getappdata(fig, 'stopRequested');
end

function requestStop(fig)
setappdata(fig, 'stopRequested', true);
status(fig, 'Stopping after the current iteration ...');
end

function setRunning(fig, running)
if ~ishandle(fig), return; end
S = guidata(fig);
sv = S.h.sv;
set(sv.start, 'Enable', onOff(~running));
set(sv.stop, 'Enable', onOff(running));
set(sv.save, 'Enable', 'off');
set([sv.Tinit(2) sv.every(2)], 'Enable', onOff(~running));
set(S.h.back, 'Enable', onOff(~running));
for k = 1:6
    set(S.h.stepButton(k), 'Enable', onOff(~running && k <= S.maxStep));
end
end

function saveResults(fig)
S = guidata(fig);
if isempty(S.results)
    status(fig, 'No results to save.', true);
    return;
end
folder = fullfile(pwd, 'heatpipe_results');
status(fig, 'Saving results ...'); drawnow;
try
    exportResults(S.results, folder);
catch err
    status(fig, ['Saving failed: ' err.message], true);
    return;
end
status(fig, sprintf('Results saved to %s (PDF diagrams, TXT data, MAT file).', folder));
end

function openSeparateWindows(results)
label = finalLabel(results);
panels = resultPanels();
for k = 1:size(panels,1)
    sz = panels{k,3};
    f = figure('Name', panels{k,4}, 'NumberTitle', 'off', 'Color', 'w', ...
        'Position', [60 + 30*(k-1), 60 + 20*(k-1), sz]);
    drawPanel(panels{k,1}, results, f, label);
end
end

function onClose(fig)
if getappdata(fig, 'running')
    setappdata(fig, 'stopRequested', true);
    setappdata(fig, 'closeRequested', true);
    status(fig, 'Stopping the simulation; the window closes afterwards.');
    return;
end
delete(fig);
end

function closeIfRequested(fig)
if ishandle(fig) && isappdata(fig, 'closeRequested') && getappdata(fig, 'closeRequested')
    delete(fig);
end
end

% ========================================================================
%                              UI HELPERS
% ========================================================================
function h = fieldRow(parent, y, label, value, unit, callback)
% [label, edit, unit] in one row; h(2) is the edit field
[hE, hT] = rowHeights(parent);
str = sprintf('%.6g', value);
h(1) = uicontrol(parent, 'Style', 'text', 'Units', 'normalized', 'Position', [0.03 y+(hE-hT)/2 0.52 hT], ...
    'String', label, 'HorizontalAlignment', 'left');
h(2) = uicontrol(parent, 'Style', 'edit', 'Units', 'normalized', 'Position', [0.56 y 0.25 hE], ...
    'String', str, 'BackgroundColor', 'w', 'UserData', struct('value', value, 'str', str));
h(3) = uicontrol(parent, 'Style', 'text', 'Units', 'normalized', 'Position', [0.82 y+(hE-hT)/2 0.17 hT], ...
    'String', unit, 'HorizontalAlignment', 'left');
if ~isempty(callback), set(h(2), 'Callback', callback); end
end

function h = functionRow(parent, y, label, expr, unit, callback)
[hE, hT] = rowHeights(parent);
h(1) = uicontrol(parent, 'Style', 'text', 'Units', 'normalized', 'Position', [0.03 y+(hE-hT)/2 0.13 hT], ...
    'String', label, 'HorizontalAlignment', 'left');
h(2) = uicontrol(parent, 'Style', 'edit', 'Units', 'normalized', 'Position', [0.17 y 0.64 hE], ...
    'String', expr, 'BackgroundColor', 'w', 'HorizontalAlignment', 'left');
h(3) = uicontrol(parent, 'Style', 'text', 'Units', 'normalized', 'Position', [0.82 y+(hE-hT)/2 0.17 hT], ...
    'String', unit, 'HorizontalAlignment', 'left');
if ~isempty(callback), set(h(2), 'Callback', callback); end
end

function h = popupRow(parent, y, label, items, value, callback)
[hE, hT] = rowHeights(parent);
h(1) = uicontrol(parent, 'Style', 'text', 'Units', 'normalized', 'Position', [0.03 y+(hE-hT)/2 0.20 hT], ...
    'String', label, 'HorizontalAlignment', 'left');
h(2) = uicontrol(parent, 'Style', 'popupmenu', 'Units', 'normalized', 'Position', [0.24 y 0.73 hE], ...
    'String', items, 'Value', value, 'BackgroundColor', 'w');
if ~isempty(callback), set(h(2), 'Callback', callback); end
end

function h = stackedPopup(parent, y, label, items, value, callback)
% label on its own line above a full-width popup menu; h(2) is the popup
[hE, hT] = rowHeights(parent);
h(1) = uicontrol(parent, 'Style', 'text', 'Units', 'normalized', 'Position', [0.03 y+hE+0.004 0.94 hT], ...
    'String', label, 'HorizontalAlignment', 'left');
h(2) = uicontrol(parent, 'Style', 'popupmenu', 'Units', 'normalized', 'Position', [0.03 y 0.94 hE], ...
    'String', items, 'Value', value, 'BackgroundColor', 'w');
if ~isempty(callback), set(h(2), 'Callback', callback); end
end

function [hE, hT] = rowHeights(parent)
% 26 px edit fields and 22 px labels, in units of the parent height
% (no smaller caps: short labels would be clipped in small panels)
sz = pixelSize(parent);
hE = min(0.45, 26/max(sz(2), 1));
hT = min(0.40, 22/max(sz(2), 1));
end

function sz = pixelSize(h)
old = get(h, 'Units');
set(h, 'Units', 'pixels');
p = get(h, 'Position');
set(h, 'Units', old);
sz = p(3:4);
end

function lines = wrapText(str, h)
% wrap text to the width of the text control h (cell array of lines)
sz = pixelSize(h);
n = max(20, floor(sz(1)/6.5));
if ischar(str), str = {str}; end
lines = {};
for p = 1:numel(str)
    words = strsplit(str{p}, ' ');
    line = '';
    for k = 1:numel(words)
        if isempty(line), cand = words{k}; else, cand = [line ' ' words{k}]; end
        if numel(cand) > n && ~isempty(line)
            lines{end+1} = line; %#ok<AGROW>
            line = words{k};
        else
            line = cand;
        end
    end
    lines{end+1} = line; %#ok<AGROW>
end
end

function h = noteText(parent, pos)
h = uicontrol(parent, 'Style', 'text', 'Units', 'normalized', 'Position', pos, 'String', '', ...
    'HorizontalAlignment', 'left', 'FontSize', 9);
end

function showRow(h, visible)
set(h, 'Visible', onOff(visible));
end

function setNum(h, v)
% display with 6 digits, keep the exact value for unchanged fields
if numel(h) > 1, h = h(2); end
str = sprintf('%.6g', v);
set(h, 'String', str, 'UserData', struct('value', v, 'str', str));
end

function v = readNumber(h, name, positive)
if nargin < 3, positive = []; end
if numel(h) > 1, h = h(2); end
str = strtrim(get(h, 'String'));
ud = get(h, 'UserData');
if isstruct(ud) && isfield(ud, 'str') && strcmp(str, ud.str)
    v = ud.value;                 % unchanged: exact value
else
    v = str2double(str);
end
if ~isfinite(v)
    error('"%s" is not a number.', name);
end
if isequal(positive, true) && v <= 0
    error('"%s" must be positive.', name);
elseif isequal(positive, false) && v < 0
    error('"%s" must not be negative.', name);
end
end

function v = readInteger(h, name)
v = readNumber(h, name, true);
if v ~= round(v)
    error('"%s" must be a whole number.', name);
end
end

function v = readFactor(h, name)
% under-relaxation factor: 0 < v <= 1
v = readNumber(h, name, true);
if v > 1
    error('"%s" must be between 0 and 1.', name);
end
end

function s = onOff(tf)
if tf, s = 'on'; else, s = 'off'; end
end

function status(fig, msg, isError)
if nargin < 3, isError = false; end
if ~ishandle(fig), return; end
S = guidata(fig);
if isError
    set(S.h.status, 'String', msg, 'ForegroundColor', [0.8 0 0]);
else
    set(S.h.status, 'String', msg, 'ForegroundColor', [0 0 0]);
end
end
